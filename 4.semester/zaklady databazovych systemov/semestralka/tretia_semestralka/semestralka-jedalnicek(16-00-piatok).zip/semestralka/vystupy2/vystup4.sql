select tuky, bielkoviny, sacharidy from surovina
where nazov_suroviny = 'vajce';