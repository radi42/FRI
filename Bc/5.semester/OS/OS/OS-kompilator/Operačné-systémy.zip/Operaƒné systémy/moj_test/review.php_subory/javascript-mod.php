// Javascript from Moodle modules
