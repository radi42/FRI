#include <stdio.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/sem.h> 

int bingo;

void * vygenerujCislo(){

	
}



int main(int argc, char * argv[]) {
	
	int i, pocetHracov=10;
	key_t klucSadySemaforov = 123;
	
	if( ( (sem_id = semget(klucSadySemaforov, 15, 0666 | IPC_CREAT)) < 0){ //0666 - pristupove prava, ipc_creat - vytvori iba jeden a ostatny sa pripoja
		printf("semget error\n");
	}

}