#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>

int main(int argc, char *argv[]){
	int socketID = 0, connectionID = 0, portNo = 80; //vynulovanie socketID a connectionID, a nastavenie cisla portu
	struct sockaddr_in adresaServera, adresaKlienta;
	char readBuff[256]; //buffer na prijimanie dat cez socket
	char sendBuff[256]; //buffer na odosielanie cez socket

	//vytvorenie socketa
	socketID = socket(PF_INET, SOCK_STREAM, 0);
		//kotrola vytvorenia socketa
		if (socketID < 0){
			perror("ERROR opening socket");
		}

	//portno = atoi(argv[1]); //nacitanie cisla portu z parametrov - konverzia zo string na int

	memset(&adresaServera, '0', sizeof(adresaServera)); //vymazanie struktury adresa servera
	//definovanie adresyServera
	adresaServera.sin_family = PF_INET;
    adresaServera.sin_addr.s_addr = htonl(INADDR_ANY);
    adresaServera.sin_port = htons(portNo);

    //previazanie descriptora stranky s adresou hosta
	if (bind(socketID, (struct sockaddr *) &adresaServera, sizeof(adresaServera)) < 0){
		perror("ERROR on binding");
		exit(1);
	}

	listen(socketID, 5);

	connectionID = accept(socketID,  (struct sockaddr *) &adresaKlienta, sizeof(adresaKlienta));
		//kontrola pripojenia - connection
		if (connectionID < 0){
			perror("ERROR on accept");
			exit(1);
		}

    memset(readBuff, '0', sizeof(readBuff)); //vynulovanie read buferea

    n = read(connectionID, readBuff, 255);
    if (n < 0) perror("CHYBA pri citani zo schranky ");
    printf("Sprava: %s\n   ", readBuff);

    //memset(sendBuff, '0', sizeof(sendBuff)); //vymazanie buffera na poslanie





	/*
	while(1){
		connectionID = accept(socketID, )
	}*/
}
