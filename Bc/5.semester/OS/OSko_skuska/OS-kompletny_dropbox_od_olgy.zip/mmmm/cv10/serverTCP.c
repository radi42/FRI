#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>

int main(int argc, char *argv[]){
	int socketID = 0, portNo = 5000, connectionID = 0;
	struct sockaddr_in adresaServera, adresaKlienta;
	char sendBuff[256];

	//vytvorenie socketa
	socketID = socket(AF_INET, SOCK_STREAM, 0);
		//kotrola vytvorenia socketa
		if (sockfd < 0){
			perror("ERROR opening socket");
		}
	
	portno = atoi(argv[1]); //nacitanie cisla portu z parametrov - konverzia zo string na int
	memset(&adresaServera, '0', sizeof(adresaServera)); //vymazanie struktury adresa servera	
	//definovanie adresyServera
	adresaServera.sin_family = AF_INET;
    adresaServera.sin_addr.s_addr = htonl(INADDR_ANY);
    adresaServera.sin_port = htons(portNo); 


	if (bind(socketID, (struct sockaddr *) &adresaServera, sizeof(adresaServera)) < 0){
		perror("ERROR on binding");
		exit(1);	
	}

	listen(socketID, 5);

	connectionID = accept(socketID,  (struct sockaddr *) adresaKlienta, sizeof(adresaKlienta));
		//kontrola pripojenia - connection
		if (newsockfd < 0){
			perror("ERROR on accept");
			exit(1);
		}
	
    memset(sendBuff, '0', sizeof(sendBuff)); //vymazanie buffera na poslanie





	/*
	while(1){
		connectionID = accept(socketID, )
	}*/
}