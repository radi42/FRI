#include <stdio.h>
#include <sys/types.h> 
#include <sys/ipc.h> 
#include <sys/sem.h>
#include <stdlib.h>

/**
* aplikacia vypise hodnotu semafora so zadanym id
* @param char *argv[] hodnota parametrov
* @param int argc zadane parametre
* @return uspesnost vykonania prikazu 
*/
int main (int argc, char *argv[]) {
	
	int idSemafora = atoi(argv[1]);

	printf("%d\n", semctl(idSemafora, 0, GETVAL));
	return 0;
}