#include <stdio.h>
#include <sys/types.h> 
#include <sys/ipc.h> 
#include <sys/sem.h>
#include <stdlib.h>

/** 
* aplikacia zmaze semafor so zadanym id
* @param char *argv[] hodnota parametrov
* @param int argc zadane parametre
* @return uspesnost vykonania prikazu
*/
int main(int argc, char *argv[]) {

	int idSemafora = atoi(argv[1]);
	if(semctl(idSemafora, 0, IPC_RMID) == -1)
	{
	perror("Zmazanie neuspesne");
	exit(1);	
	}
	return 0;
}	
