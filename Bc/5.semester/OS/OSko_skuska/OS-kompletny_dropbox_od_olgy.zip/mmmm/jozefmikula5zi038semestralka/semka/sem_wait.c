#include <stdio.h>
#include <sys/types.h> 
#include <sys/ipc.h> 
#include <sys/sem.h>
#include <stdlib.h>

/** 
* znizi hodnotu semafora so zadanym id o 1
* @param char *argv[] hodnota parametrov
* @param int argc zadane parametre
* @return uspesnost vykonania prikazu 
*/
int main (int argc, char *argv[]) {
	
	int idSemafora = atoi(argv[1]);
	int op = atoi(argv[2]);
	struct sembuf sops;
	sops.sem_num = 0;
	sops.sem_op = -op;
	sops.sem_flg = 0;
	if (semop(idSemafora, &sops, 1) == -1)
		{
		perror("Neuspesne wait");
		return 1;
		}	
		else 
		{
		return 0;
		}
}