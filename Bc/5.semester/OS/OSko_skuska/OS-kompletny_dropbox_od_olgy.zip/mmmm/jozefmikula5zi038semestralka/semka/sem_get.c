#include <stdio.h>
#include <sys/types.h> 
#include <sys/ipc.h> 
#include <sys/sem.h>
#include <stdlib.h>
#include <time.h>


union semun{
	int val;
	struct semid_ds *buf;
	unsigned short *array;
	struct seminfo *__buf;
};

/** 
* aplikacia vytvori novy semafor so zadanou hodnotou, priradi mu id a vypise ho
* @param char *argv[] hodnota parametrov
* @param int argc zadane parametre
* @return uspesnost vykonania prikazu 
*/
int main (int argc, char *argv[]) {

	int hodnota = atoi(argv[1]);
	int id;
	srand((unsigned)time(NULL));
	int kluc;

	union semun sem_union;
	sem_union.val = hodnota;
	
	do{
	kluc = rand() % 100000;
	id = semget((key_t)kluc, 1, 0666 | IPC_CREAT | IPC_EXCL);
	}while (id == -1);
 
	if (semctl(id, 0, SETVAL, sem_union) == -1)
		{
		perror("Neuspesne nastavenie hodnoty");
		exit(1);
		return 1;
		}
	printf("%d\n", id);
	return 0;	
}