#!/bin/bash


function vypisMeno(){
	printf "\n"
	printf "%s\n\n" "Matej Mahút 5ZI038"
}

# funkcia vypise zadanie a cislo semestralnej prace
function vypisZadanie(){
	printf "%s\n" "Zadanie semestrálnej práce č.9"
    printf "%s\n" "Webový server s podporou skriptovania v Bash-i."
	printf "\n"
}

# funkcia vypise cele zadanie semestralnej prace
function zobrazenieCelehoZadania(){
    echo "--------------------======PODROBNE ZADANIE SEMESTRALNEJ PRACE======--------------------"
    echo "Implementujte v jazyku C, s pomocou soketov a vlákien jednoduchý webový server, ktorý umožní obsluhu viacerých klientov súčasne  a ktorý bude podporovať generovanie dynamického HTML pomocou  skriptov v Bash-i.

Server musí podporovať aspoň metódu GET:

GET <specifikacia_suboru> HTTP/1.0\n\n

Server musí vedieť odoslať ľubovoľný súbor, statické .html, obrázky  (.png, .jpg, ...), atd. V prípade, že príde od klienta požiadavka na  súbor s príponou .bash a takýto skript existuje, server mu odovzdá prípadné parametre, spustí ho a výstup tohto skriptu odošle  klientovi.

Súčasťou semestrálnej práce, musia byť aspoň tri rôzne skripty  (aj s parametrami), a niekoľko statických .html dokumentov, ktoré budú demonštrovať funkčnosť servera.

Funkčnosť servera bude overená pomocou webového prehliadača."
    printf "%s\n" "Ak chcete ukoncit vypis stlacte enter."
    read X
}

# zobrazenie zdrojovych kodov v c
function zobrazenieKoduServera(){
	echo "--------------------======Zdrojovy kod servera======--------------------"
	    cat Server.c
        printf "%s\n" "Ak chcete ukoncit vypis stlacte enter."
        read X
        echo "-----------------=====================---------------"
        echo "Koniec zdrojoveho kodu pre server"
        echo "-----------------=====================---------------"
}

# funkcia pre generovanie dokumentacie
function dokumentacia(){
	echo "--------------------======Dokumentacia======--------------------" 
        doxygen Doxyfile Server.c
	    printf "%s\n" "Dokumentacia bola vygenerovana pre pokracovanie stlacte enter."
	    read X	
}

# funkcia na prelozenie c.programov
function preloz(){
    echo "Prekladam .c programy"
    make
}

echo "--------------------======SEMESTRALNA PRACA======--------------------"

vypisMeno
vypisZadanie

while true; do
printf "%s\n" "Zadajte volbu:"
printf "%s\n" "Zobrazenie celeho zadania -------------> 1"
printf "%s\n" "Zobrazenie zdrojoveho kodu servera ----> 2"
printf "%s\n" "Prelozenie .c programov ---------------> 3"
printf "%s\n" "Generovanie dokumentacie --------------> 4"
printf "%s\n" "Spustenie servera ---------------------> 5"
printf "%s\n" "Koniec programu -----------------------> 6"
read ACTION

if [ "$ACTION" = "1" ]; then
    zobrazenieCelehoZadania
fi

if [ "$ACTION" = "2" ]; then
    zobrazenieKoduServera
fi

if [ "$ACTION" = "3" ]; then
    preloz
fi

if [ "$ACTION" = "4" ]; then
    dokumentacia
fi

if [ "$ACTION" = "5" ]; then
    echo "Spustanie servera:"
    echo "Zadajte port pre server [doporucene 46745]:"
    read PORT
    echo "Zadajte adresar servera:"
    read ADRESAR

    ./Server echo "$PORT" "$ADRESAR"
fi

if [ "$ACTION" = "6" ]; then
    break
fi
done


echo "--------------------======KONIEC SEMESTRALNEJ PRACE======--------------------"
