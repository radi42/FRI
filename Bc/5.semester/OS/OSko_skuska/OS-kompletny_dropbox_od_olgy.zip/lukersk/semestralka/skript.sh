#!/bin/bash

function main_menu {
    if [ -x ./semestralka ]; then
        COMPILED=1
    else
        COMPILED=0
    fi

    MAIN_DONE=0
    while [ $MAIN_DONE -lt 1 ]
    do
        echo ''
        echo 'Hlavné menu:' 
        echo '  1 Vypíš zadanie'
        echo '  2 Pozri dokumentáciu'
        echo '  3 Skompiluj program'
        echo '  4 Spusti program'
        echo '  5 Vypíš nápovedu pre parametre programu'
        echo '  6 Ukonči skript'
        echo -n 'Zadaj možnosť: '
        read CHOICE
        echo ''
        case "$CHOICE" in
            1)
                echo 'Zadanie:'
                cat ./bash/zadanie
                echo -e "\nStručný popis:"
                cat ./bash/popis
                ;;
            2)
                echo 'Pre prezretie dokumentácie otvorte nasledujúci link vo svojom webovom prehliadači:'
                echo "file://$(pwd)/doc/html/index.html"
                ;;
            3)
                echo "Čistím adresáre:"
                make clean
                echo "Kompilujem:"
                make && COMPILED=1
                ;;
            4) 
                if [[ $COMPILED -gt 0 ]]; then
                    PRIKAZ='./semestralka 20 -w 101 -h 101 -o mazes/maze'
                    echo 'Bude vygenerovaných 20 bludísk s rozmermi 101x101 v adresári ./mazes'
                    echo 's názvami maze_0.svg až maze_19.svg'
                    echo "Tvar prikazu: $PRIKAZ"

                    echo 'Stlač ľubovolnú klávesu pre pokračovanie.'
                    read -n 1 ANY_KEY

                    rm -f mazes/*.svg
                    rm -f out.txt
                    $PRIKAZ | tee out.txt | less

                    echo 'Výstup programu je uložený v súbore out.txt'
                    echo -e '\rVytvorené súbory:'
                    ls ./mazes
                else
                    echo "Program treba najskôr skompilovať."
                fi
                ;;
            5)
                if [[ $COMPILED -gt 0 ]]; then
                    ./semestralka --help
                else
                    echo "Program treba najskôr skompilovať."
                fi
                ;;
            6)
                MAIN_DONE=1
                ;;
            *)
                echo "Chybny vstup: $CHOICE"
        esac
    done
}

##
cat bash/meno
main_menu





















































N=$RANDOM
let "N %= 100"
if [[ $N == 42 ]]; then
    echo 'ヽ(´∇｀)ﾉ'
fi

exit 0
