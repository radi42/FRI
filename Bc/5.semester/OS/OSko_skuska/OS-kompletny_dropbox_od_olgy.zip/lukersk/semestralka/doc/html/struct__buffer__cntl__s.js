var struct__buffer__cntl__s =
[
    [ "buffer", "struct__buffer__cntl__s.html#a1e1f3ea4e632c63a5e827ce3e3221bc7", null ],
    [ "child_pids", "struct__buffer__cntl__s.html#a47c36e12ea3448d223eac1719f598817", null ],
    [ "handlers", "struct__buffer__cntl__s.html#ab4c0f2bac5eea734455e93f02c3ffbbe", null ],
    [ "length", "struct__buffer__cntl__s.html#ae809d5359ac030c60a30a8f0b2294b82", null ],
    [ "prepare", "struct__buffer__cntl__s.html#a416be41c0fee6767441331766527e3dd", null ],
    [ "prepare_arguments", "struct__buffer__cntl__s.html#a27bc29761012beb0207f6c77884b8a0a", null ]
];