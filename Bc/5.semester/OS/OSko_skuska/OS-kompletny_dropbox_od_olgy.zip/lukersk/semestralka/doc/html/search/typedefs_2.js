var searchData=
[
  ['prepare_5fhandler',['prepare_handler',['../buffer_8h.html#a042d5f45a147c61c0a0aed27e3f7afd4',1,'buffer.h']]]
];
