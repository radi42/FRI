var searchData=
[
  ['holds',['Holds',['../struct_holds.html',1,'']]]
];
