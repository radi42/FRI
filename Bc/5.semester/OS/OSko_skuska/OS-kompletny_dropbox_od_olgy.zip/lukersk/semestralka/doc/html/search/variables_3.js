var searchData=
[
  ['child_5fpids',['child_pids',['../struct__buffer__cntl__s.html#a47c36e12ea3448d223eac1719f598817',1,'_buffer_cntl_s']]],
  ['count',['count',['../struct__maze__arguments__s.html#a76d971a3c552bc58ba9f0d5fceae9806',1,'_maze_arguments_s']]]
];
