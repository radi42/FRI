var struct__maze__arguments__s =
[
    [ "count", "struct__maze__arguments__s.html#a76d971a3c552bc58ba9f0d5fceae9806", null ],
    [ "height", "struct__maze__arguments__s.html#a6ad4f820ce4e75cda0686fcaad5168be", null ],
    [ "output", "struct__maze__arguments__s.html#a47866494eb84961e021291efbea9b569", null ],
    [ "size", "struct__maze__arguments__s.html#a854352f53b148adc24983a58a1866d66", null ],
    [ "width", "struct__maze__arguments__s.html#a325272ddd9a962f05deb905101d25cbd", null ]
];