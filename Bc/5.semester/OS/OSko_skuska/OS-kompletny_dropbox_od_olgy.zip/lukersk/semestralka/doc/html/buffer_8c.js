var buffer_8c =
[
    [ "Buffer_Lock", "buffer_8c.html#aea9f1fbacfe685c8d95aa15902426c95", null ],
    [ "Buffer_Unlock", "buffer_8c.html#a4faa0022ab55661936ac0ef9508d6928", null ],
    [ "BufferCntl_DataDestroy", "buffer_8c.html#ad074d8e9130c4d41c1349416c0c1283a", null ],
    [ "BufferCntl_DataPrepare", "buffer_8c.html#a378360549d49c810a6d7e59af4bab754", null ],
    [ "BufferCntl_DataProcess", "buffer_8c.html#a93936f8fbe6695af5aebf1c3cdc9df1d", null ],
    [ "BufferCntl_Initialize", "buffer_8c.html#ab0fb0b23f7c3ae6c36416d89059afc11", null ],
    [ "BufferCntl_Quit", "buffer_8c.html#a512a2c22c186a450d64fe256a984b35b", null ],
    [ "BufferCntl_Start", "buffer_8c.html#aea10f5e51de7d6b5291a36fd74b9bf37", null ]
];