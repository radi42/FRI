var annotated =
[
    [ "_buffer_cntl_s", "struct__buffer__cntl__s.html", "struct__buffer__cntl__s" ],
    [ "_buffer_s", "struct__buffer__s.html", "struct__buffer__s" ],
    [ "_maze_arguments_s", "struct__maze__arguments__s.html", "struct__maze__arguments__s" ],
    [ "_maze_buffer_data_s", "struct__maze__buffer__data__s.html", "struct__maze__buffer__data__s" ],
    [ "_maze_s", "struct__maze__s.html", "struct__maze__s" ],
    [ "_tile_s", "struct__tile__s.html", "struct__tile__s" ],
    [ "Contains", "struct_contains.html", null ],
    [ "Holds", "struct_holds.html", null ]
];