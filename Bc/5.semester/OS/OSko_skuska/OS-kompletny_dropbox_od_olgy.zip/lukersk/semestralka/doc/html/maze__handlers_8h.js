var maze__handlers_8h =
[
    [ "_maze_buffer_data_s", "struct__maze__buffer__data__s.html", "struct__maze__buffer__data__s" ],
    [ "MAZE_H_LOG_FILENAME", "maze__handlers_8h.html#abc447f62486e99551e56906b7f286400", null ],
    [ "MAZE_H_SVG_FILEBASE", "maze__handlers_8h.html#ac8f5b1fb28d832026edbe7fc90519624", null ],
    [ "STATE_USER_GEN", "maze__handlers_8h.html#a0b20da02bb6ad58c26ac76e9dd9cb59e", null ],
    [ "STATE_USER_PRINT", "maze__handlers_8h.html#a885048e7eabfb712a19fea5eeec1ae24", null ],
    [ "STATE_USER_SOLVE", "maze__handlers_8h.html#ace9cf691e7e87efcb41a9137d467af92", null ],
    [ "maze_buffer_data_s", "maze__handlers_8h.html#a301e33bc5cce33ba7329646c434b3cd6", null ],
    [ "MazeBuffer_Destroy", "maze__handlers_8h.html#a8574c1ced22ef2e3ec8208f6e530a1a3", null ],
    [ "MazeBuffer_Generate", "maze__handlers_8h.html#ac70fb15b3155f95554979c5a2bbc064b", null ],
    [ "MazeBuffer_Prepare", "maze__handlers_8h.html#aaf286f924f663deb31c5b823aeac59ba", null ],
    [ "MazeBuffer_Print", "maze__handlers_8h.html#aee669d2ac7d22e912a0dc54b5b14170f", null ],
    [ "MazeBuffer_Solve", "maze__handlers_8h.html#ac93223dff7dd085e14564b48183d66c1", null ]
];