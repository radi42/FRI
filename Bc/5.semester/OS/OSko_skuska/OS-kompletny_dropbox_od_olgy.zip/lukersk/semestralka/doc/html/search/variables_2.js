var searchData=
[
  ['buffer',['buffer',['../struct__buffer__cntl__s.html#a1e1f3ea4e632c63a5e827ce3e3221bc7',1,'_buffer_cntl_s']]]
];
