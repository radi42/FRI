var struct__tile__s =
[
    [ "distance", "struct__tile__s.html#a7ea92f38c276646af2b67107f23c47e3", null ],
    [ "type", "struct__tile__s.html#a1d127017fb298b889f4ba24752d08b8e", null ]
];