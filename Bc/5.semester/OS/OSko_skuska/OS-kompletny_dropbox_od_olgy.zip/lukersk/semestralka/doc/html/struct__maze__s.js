var struct__maze__s =
[
    [ "_flags", "struct__maze__s.html#a5629227e4392e5086f50519e78e4c973", null ],
    [ "allocated_height", "struct__maze__s.html#ab82229c93811aeb2417aaa70bb2150ec", null ],
    [ "allocated_width", "struct__maze__s.html#a247d6f4e8ba8d89e73417a9297f38371", null ],
    [ "height", "struct__maze__s.html#a6ad4f820ce4e75cda0686fcaad5168be", null ],
    [ "path_length", "struct__maze__s.html#a2de28ba2d09cba3fddd834d2d174a539", null ],
    [ "tile", "struct__maze__s.html#a6da00230251a62053b5f57cae0e61d0e", null ],
    [ "width", "struct__maze__s.html#a325272ddd9a962f05deb905101d25cbd", null ]
];