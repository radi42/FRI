var struct__maze__buffer__data__s =
[
    [ "arguments", "struct__maze__buffer__data__s.html#a0b8bb242a7b3f38512da54deb19060d5", null ],
    [ "log", "struct__maze__buffer__data__s.html#ad033d05e078fa433531dcadea106749f", null ],
    [ "maze", "struct__maze__buffer__data__s.html#a4d1f7651479412ee1f4e0ec8ff1d60ef", null ]
];