var maze__handlers_8c =
[
    [ "MazeBuffer_Destroy", "maze__handlers_8c.html#a8574c1ced22ef2e3ec8208f6e530a1a3", null ],
    [ "MazeBuffer_Generate", "maze__handlers_8c.html#ac70fb15b3155f95554979c5a2bbc064b", null ],
    [ "MazeBuffer_Prepare", "maze__handlers_8c.html#aaf286f924f663deb31c5b823aeac59ba", null ],
    [ "MazeBuffer_Print", "maze__handlers_8c.html#aee669d2ac7d22e912a0dc54b5b14170f", null ],
    [ "MazeBuffer_Solve", "maze__handlers_8c.html#ac93223dff7dd085e14564b48183d66c1", null ],
    [ "MazeLog_Process", "maze__handlers_8c.html#aec363d321342e2538b499b0d418b844f", null ]
];