var searchData=
[
  ['buffer',['buffer',['../struct__buffer__cntl__s.html#a1e1f3ea4e632c63a5e827ce3e3221bc7',1,'_buffer_cntl_s']]],
  ['buffer_2ec',['buffer.c',['../buffer_8c.html',1,'']]],
  ['buffer_2eh',['buffer.h',['../buffer_8h.html',1,'']]],
  ['buffer_5fcntl_5fs',['buffer_cntl_s',['../buffer_8h.html#af612a5181c755f2992f631f2a2f3629a',1,'buffer.h']]],
  ['buffer_5fhandler',['buffer_handler',['../buffer_8h.html#a24279de06ee3128f1d5f7faf69f2fb5c',1,'buffer.h']]],
  ['buffer_5flock',['Buffer_Lock',['../buffer_8c.html#aea9f1fbacfe685c8d95aa15902426c95',1,'Buffer_Lock(buffer_s *buffer):&#160;buffer.h'],['../buffer_8h.html#aea9f1fbacfe685c8d95aa15902426c95',1,'Buffer_Lock(buffer_s *buffer):&#160;buffer.h']]],
  ['buffer_5fs',['buffer_s',['../buffer_8h.html#a5a3456bbfe0c871bbb9f47ad1059e5f9',1,'buffer.h']]],
  ['buffer_5funlock',['Buffer_Unlock',['../buffer_8c.html#a4faa0022ab55661936ac0ef9508d6928',1,'Buffer_Unlock(buffer_s *buffer):&#160;buffer.h'],['../buffer_8h.html#a4faa0022ab55661936ac0ef9508d6928',1,'Buffer_Unlock(buffer_s *buffer):&#160;buffer.h']]],
  ['buffercntl_5fdatadestroy',['BufferCntl_DataDestroy',['../buffer_8c.html#ad074d8e9130c4d41c1349416c0c1283a',1,'BufferCntl_DataDestroy(buffer_cntl_s *cntl, buffer_handler destroy_handler):&#160;buffer.c'],['../buffer_8h.html#ad074d8e9130c4d41c1349416c0c1283a',1,'BufferCntl_DataDestroy(buffer_cntl_s *cntl, buffer_handler destroy_handler):&#160;buffer.c']]],
  ['buffercntl_5fdataprepare',['BufferCntl_DataPrepare',['../buffer_8c.html#a378360549d49c810a6d7e59af4bab754',1,'BufferCntl_DataPrepare(buffer_cntl_s *cntl, prepare_handler prepare_handler, void *arguments):&#160;buffer.c'],['../buffer_8h.html#a378360549d49c810a6d7e59af4bab754',1,'BufferCntl_DataPrepare(buffer_cntl_s *cntl, prepare_handler prepare_handler, void *arguments):&#160;buffer.c']]],
  ['buffercntl_5fdataprocess',['BufferCntl_DataProcess',['../buffer_8c.html#a93936f8fbe6695af5aebf1c3cdc9df1d',1,'BufferCntl_DataProcess(buffer_cntl_s *cntl, const size_t stage, buffer_handler handler):&#160;buffer.c'],['../buffer_8h.html#a93936f8fbe6695af5aebf1c3cdc9df1d',1,'BufferCntl_DataProcess(buffer_cntl_s *cntl, const size_t stage, buffer_handler handler):&#160;buffer.c']]],
  ['buffercntl_5finitialize',['BufferCntl_Initialize',['../buffer_8c.html#ab0fb0b23f7c3ae6c36416d89059afc11',1,'BufferCntl_Initialize(buffer_cntl_s *cntl, const size_t length):&#160;buffer.c'],['../buffer_8h.html#ab0fb0b23f7c3ae6c36416d89059afc11',1,'BufferCntl_Initialize(buffer_cntl_s *cntl, const size_t length):&#160;buffer.c']]],
  ['buffercntl_5fquit',['BufferCntl_Quit',['../buffer_8c.html#a512a2c22c186a450d64fe256a984b35b',1,'BufferCntl_Quit(buffer_cntl_s *cntl, size_t is_parent):&#160;buffer.c'],['../buffer_8h.html#a512a2c22c186a450d64fe256a984b35b',1,'BufferCntl_Quit(buffer_cntl_s *cntl, size_t is_parent):&#160;buffer.c']]],
  ['buffercntl_5fstart',['BufferCntl_Start',['../buffer_8c.html#aea10f5e51de7d6b5291a36fd74b9bf37',1,'BufferCntl_Start(buffer_cntl_s *cntl):&#160;buffer.c'],['../buffer_8h.html#aea10f5e51de7d6b5291a36fd74b9bf37',1,'BufferCntl_Start(buffer_cntl_s *cntl):&#160;buffer.c']]]
];
