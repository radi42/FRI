var files =
[
    [ "arguments.c", "arguments_8c.html", "arguments_8c" ],
    [ "arguments.h", "arguments_8h.html", "arguments_8h" ],
    [ "buffer.c", "buffer_8c.html", "buffer_8c" ],
    [ "buffer.h", "buffer_8h.html", "buffer_8h" ],
    [ "config.h", "config_8h.html", "config_8h" ],
    [ "main.c", "main_8c.html", "main_8c" ],
    [ "maze.c", "maze_8c.html", "maze_8c" ],
    [ "maze.h", "maze_8h.html", "maze_8h" ],
    [ "maze_handlers.c", "maze__handlers_8c.html", "maze__handlers_8c" ],
    [ "maze_handlers.h", "maze__handlers_8h.html", "maze__handlers_8h" ],
    [ "sandbox.c", "sandbox_8c.html", "sandbox_8c" ]
];