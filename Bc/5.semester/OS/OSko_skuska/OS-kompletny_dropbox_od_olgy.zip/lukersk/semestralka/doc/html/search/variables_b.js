var searchData=
[
  ['tile',['tile',['../struct__maze__s.html#a6da00230251a62053b5f57cae0e61d0e',1,'_maze_s']]],
  ['type',['type',['../struct__tile__s.html#a1d127017fb298b889f4ba24752d08b8e',1,'_tile_s']]]
];
