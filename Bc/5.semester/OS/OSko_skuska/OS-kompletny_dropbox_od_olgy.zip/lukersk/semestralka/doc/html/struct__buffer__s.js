var struct__buffer__s =
[
    [ "data", "struct__buffer__s.html#a735984d41155bc1032e09bece8f8d66d", null ],
    [ "lock", "struct__buffer__s.html#aba802d8d2b71c239efa908634be36cc8", null ],
    [ "lock_name", "struct__buffer__s.html#a8a2825c4be6d6aec705ac68a6465fee4", null ],
    [ "state", "struct__buffer__s.html#a1b0c7bd4d79798ef4e0ce23894c9aeb2", null ]
];