var searchData=
[
  ['size',['size',['../struct__maze__arguments__s.html#a854352f53b148adc24983a58a1866d66',1,'_maze_arguments_s']]],
  ['state',['state',['../struct__buffer__s.html#a1b0c7bd4d79798ef4e0ce23894c9aeb2',1,'_buffer_s']]]
];
