#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include <sys/mman.h>

#include "config.h"

#include "maze.h"
#include "maze_handlers.h"
#include "arguments.h"

#ifdef PRINT_DEBUG_MESSAGES
#include <unistd.h>
#endif // PRINT_DEBUG_MESSAGES

//#define LOCK_DELAY      (100)


static void MazeBuffer_LogMsg(FILE* log, size_t buffer, char* msg)
{
    fflush(log);
    fprintf(log, "%u:%lu %s\n", getpid(), buffer, msg);
    fflush(log);
}


/** \brief Allocates shared memory used by mazes.
 *
 *  Opens maze log file.
 *  Allocates shared maze data structures.
 *  Allocates shared maze matrix for each buffer.
 *  Initializes meze data structure witf M_SHARED flag.
 *
 *  \param length Number of created buffers given by BufferCntl.
 *  \param buffers Pointer to array of buffers given by BufferCntl.
 *  \param arguments User defined initialization arguments.
 */
void MazeBuffer_Prepare(const size_t length, buffer_s* buffers, void* arguments)
{
    size_t i, j;
    FILE* log;
    maze_arguments_s* args;
    maze_buffer_data_s* data;

    #ifdef PRINT_DEBUG_MESSAGES
    printf("%u: Preparing shared data.\n", getpid() );
    #endif // PRINT_DEBUG_MESSAGES

    args = (maze_arguments_s*) arguments;

    log = fopen(MAZE_H_LOG_FILENAME, "w");
    if(log == NULL) {
        fprintf(stderr, "Error while opening shared log file");
        perror("");
        exit(EXIT_FAILURE);
    }

    for(i=0; i<length; i++) {
        /* shared memory for buffer data structure */
        buffers[i].data = mmap(NULL, sizeof(maze_buffer_data_s), PROT_READ|PROT_WRITE, MAP_SHARED|MAP_ANON, -1, 0);
        if(buffers[i].data == MAP_FAILED) {
            fputs("Error occured: Failed to map buffers data.", stderr);
            exit(EXIT_FAILURE);
        }
        data = (maze_buffer_data_s*) buffers[i].data;

        data->log = log;
        data->arguments = args;

        /* shared memory for maze */
        data->maze.tile = mmap(NULL, args->height*sizeof(tile_s*), PROT_WRITE|PROT_READ, MAP_SHARED|MAP_ANON, -1, 0);
        if(data->maze.tile == MAP_FAILED) {
            fputs("Error occured: Failed to map tile data. (1)", stderr);
            exit(EXIT_FAILURE);
        }

        /* shared memory for maze */
        for(j=0; j<data->arguments->height; j++) {
            data->maze.tile[j] = mmap(NULL, args->width*sizeof(tile_s), PROT_WRITE|PROT_READ, MAP_SHARED|MAP_ANON, -1, 0);
            if(data->maze.tile[j] == MAP_FAILED) {
                fputs("Error occured: Failed to map tile data. (2)", stderr);
                exit(EXIT_FAILURE);
            }
        }

        data->maze.allocated_height = args->height;
        data->maze.allocated_width = args->width;
        data->maze._flags = M_SHARED;
    }

    #ifdef PRINT_DEBUG_MESSAGES
    printf("%u: Done preparing shared data.\n", getpid() );
    #endif // PRINT_DEBUG_MESSAGES
}

/** \brief Cleans up shared memory allocated by MazeBuffer_Prepare()
 *
 *  \param length Number of created buffers given by BufferCntl.
 *  \param buffers Pointer to array of buffers given by BufferCntl.
 */
void MazeBuffer_Destroy(const size_t length, buffer_s* buffers)
{
    size_t i, j;
    maze_buffer_data_s* data;

    #ifdef PRINT_DEBUG_MESSAGES
    printf("%u: Destroying shared data.\n", getpid() );
    #endif // PRINT_DEBUG_MESSAGES

    /* close log file */
    data = (maze_buffer_data_s*) buffers[0].data;
    fclose(data->log);

    for(i=0; i<length; i++) {
        data = (maze_buffer_data_s*) buffers[i].data;

        /* unmap shared memory for maze */
        for(j=0; j<data->maze.allocated_height; j++) {
            munmap(data->maze.tile[j], data->maze.allocated_width*sizeof(tile_s) );
        }
        munmap(data->maze.tile, data->maze.allocated_height*sizeof(tile_s*) );

        /* unmap shared memory for buffer data structure */
        munmap(buffers[i].data, sizeof(maze_buffer_data_s) );
        buffers[i].data = NULL;
    }

    #ifdef PRINT_DEBUG_MESSAGES
    printf("%u: Done destroying shared data.\n", getpid() );
    #endif // PRINT_DEBUG_MESSAGES
}

/** \brief Callback function used to generate mazes.
 *
 *  
 *
 *
 *  \param length Number of created buffers given by BufferCntl.
 *  \param buffers Pointer to array of buffers given by BufferCntl.
 */
void MazeBuffer_Generate(const size_t length, buffer_s* buffers)
{
    maze_buffer_data_s* data;
    FILE* log;
    size_t next;
    size_t count;

    #ifdef PRINT_DEBUG_MESSAGES
    fflush(stdout);
    printf("%u: Entering maze generation process. (stage 1)\n", getpid() );
    fflush(stdout);
    #endif // PRINT_DEBUG_MESSAGES

    log   = ((maze_buffer_data_s*) buffers[0].data)->log;
    count = ((maze_buffer_data_s*) buffers[0].data)->arguments->count;

    next = 0;
    while(1) {
        if(!count) {
            #ifdef PRINT_DEBUG_MESSAGES
            fflush(stdout);
            printf("%u: Exiting generation loop.\n", getpid());
            fflush(stdout);
            #endif // PRINT_DEBUG_MESSAGES
            return;
        }

        Buffer_Lock(&buffers[next]);

        if( (buffers[next].state&STATE_USER_BITS) != STATE_USER_GEN) {
            Buffer_Unlock(&buffers[next]);
            //usleep(LOCK_DELAY);
            continue;
        }

        MazeBuffer_LogMsg(log, next, "G");

        buffers[next].state += 0x0100;

        #ifdef PRINT_DEBUG_MESSAGES
        fflush(stdout);
        printf("%u: Generating buffer %lu with count %lu.\n", getpid(), next, count);
        fflush(stdout);
        #endif // PRINT_DEBUG_MESSAGES

        /******/

        data = (maze_buffer_data_s*) buffers[next].data;
        Maze_Initialize(&data->maze, data->arguments->height, data->arguments->width, M_INIT_SHARED);
        Maze_Generate(&data->maze);

        /******/

        MazeBuffer_LogMsg(log, next, "f");

        #ifdef PRINT_DEBUG_MESSAGES
        fflush(stdout);
        printf("%u: Done generating buffer %lu.\n", getpid(), next);
        fflush(stdout);
        #endif // PRINT_DEBUG_MESSAGES

        Buffer_Unlock(&buffers[next]);
        next = (next+1)%length;
        count -= 1;
    }
}

/** \brief
 *
 *
 *
 *
 *  \param length Number of created buffers given by BufferCntl.
 *  \param buffers Pointer to array of buffers given by BufferCntl.
 */
void MazeBuffer_Solve(const size_t length, buffer_s* buffers)
{
    maze_buffer_data_s* data;
    FILE* log;
    size_t next;
    size_t count;

    #ifdef PRINT_DEBUG_MESSAGES
    fflush(stdout);
    printf("%u: Entering maze solving process. (stage 2)\n", getpid() );
    fflush(stdout);
    #endif // PRINT_DEBUG_MESSAGES

    log = ((maze_buffer_data_s*) buffers[0].data)->log;
    count = ((maze_buffer_data_s*) buffers[0].data)->arguments->count;

    next = 0;
    while(1) {
        if(!count) {
            #ifdef PRINT_DEBUG_MESSAGES
            fflush(stdout);
            printf("%u: Exiting solving loop.\n", getpid());
            fflush(stdout);
            #endif // PRINT_DEBUG_MESSAGES
            return;
        }

        Buffer_Lock(&buffers[next]);

        if( (buffers[next].state&STATE_USER_BITS) != STATE_USER_SOLVE) {
            Buffer_Unlock(&buffers[next]);
            //usleep(LOCK_DELAY);
            continue;
        }

        MazeBuffer_LogMsg(log, next, "S");

        buffers[next].state += 0x0100;

        #ifdef PRINT_DEBUG_MESSAGES
        fflush(stdout);
        printf("%u: Solving buffer %lu with count %lu.\n", getpid(), next, count);
        fflush(stdout);
        #endif // PRINT_DEBUG_MESSAGES

        data = (maze_buffer_data_s*) buffers[next].data;
        Maze_Solve( &data->maze);

        MazeBuffer_LogMsg(log, next, "f");

        #ifdef PRINT_DEBUG_MESSAGES
        fflush(stdout);
        printf("%u: Done solving buffer %lu.\n", getpid(), next);
        fflush(stdout);
        #endif // PRINT_DEBUG_MESSAGES

        Buffer_Unlock(&buffers[next]);
        next = (next+1)%length;
        count -= 1;
    }
}

/** \brief
 *
 *
 *
 *
 *  \param length Number of created buffers given by BufferCntl.
 *  \param buffers Pointer to array of buffers given by BufferCntl.
 */
void MazeBuffer_Print(const size_t length, buffer_s* buffers)
{
    maze_buffer_data_s* data;
    FILE* log;
    size_t next;
    size_t count;
    char name[256];


    #ifdef PRINT_DEBUG_MESSAGES
    fflush(stdout);
    printf("%u: Entering maze svg printing process. (stage 3)\n", getpid() );
    fflush(stdout);
    #endif // PRINT_DEBUG_MESSAGES

    log = ((maze_buffer_data_s*) buffers[0].data)->log;
    count = ((maze_buffer_data_s*) buffers[0].data)->arguments->count;

    next = 0;
    while(1) {
        if(!count) {
            #ifdef PRINT_DEBUG_MESSAGES
            fflush(stdout);
            printf("%u: Exiting printing loop.\n", getpid());
            fflush(stdout);
            #endif // PRINT_DEBUG_MESSAGES
            return;
        }

        Buffer_Lock(&buffers[next]);

        if( (buffers[next].state&STATE_USER_BITS) != STATE_USER_PRINT) {
            Buffer_Unlock(&buffers[next]);
            //usleep(LOCK_DELAY);
            continue;
        }

        MazeBuffer_LogMsg(log, next, "P");

        buffers[next].state &= ~STATE_USER_BITS;


        #ifdef PRINT_DEBUG_MESSAGES
        fflush(stdout);
        printf("%u: Printing buffer %lu with count %lu.\n", getpid(), next, count);
        fflush(stdout);
        #endif // PRINT_DEBUG_MESSAGES

        /******/

        data = (maze_buffer_data_s*) buffers[next].data;

        if(data->arguments->output != NULL) {
            sprintf(name, "%s_%lu", data->arguments->output, data->arguments->count-count);
        }
        else {
            sprintf(name, "%s_%lu", MAZE_H_SVG_FILEBASE, data->arguments->count-count);
        }

        Maze_PrintSvg( &data->maze, name, M_P_SVG_SEPARATE, data->arguments->size);

        /******/

        MazeBuffer_LogMsg(log, next, "f");

        #ifdef PRINT_DEBUG_MESSAGES
        fflush(stdout);
        printf("%u: Done printing buffer %lu.\n", getpid(), next);
        fflush(stdout);
        #endif // PRINT_DEBUG_MESSAGES

        Buffer_Unlock(&buffers[next]);
        next = (next+1)%length;
        count -= 1;
    }
}

/** \brief Not implemented */
void MazeLog_Process(char* filename)
{
    FILE* log;
    FILE* out;
    char* out_name;

    size_t i;
    size_t length;
    pid_t* pids;

    pid_t pid;
    char type;
    size_t buffer;
    char* state;

    log = fopen(filename, "r");
    if(log == NULL) {
        fprintf(stderr, "Error while opnening %s: ", filename);
        perror("");
        return;
    }

    out_name = malloc( strlen(filename)+11);
    sprintf(out_name, "proccesed_%s", filename);

    out = fopen(out_name, "w");
    if(out == NULL) {
        fprintf(stderr, "Error while opnening %s: ", out_name);
        perror("");
    }

    /*  */
    fscanf(log, "%lu", &length);
    pids = malloc( length*sizeof(char));
    if(pids == NULL) {
        perror("Error occured");
        return;
    }
    for(i=0; i<length; i++) {
        fscanf(log, "%d ", &pids[i]);
        fprintf(out, "%d\t", pids[i]);
    }
    fputs("\n", out);

    state = malloc( length*sizeof(size_t));
    if(state == NULL) {
        perror("Error occured");
        return;
    }
    for(i=0; i<length; i++) {
        state[i] = 'f';
    }

    fscanf(log, "%d %c %lu\n", &pid, &type, &buffer);
    while(!feof(log)) {
        fscanf(log, "%d %c %lu\n", &pid, &type, &buffer);


    }

    free(out_name);
    free(pids);
    free(state);

    fclose(log);
    fclose(out);
}
