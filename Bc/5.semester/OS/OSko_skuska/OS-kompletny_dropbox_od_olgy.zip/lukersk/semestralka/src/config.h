#ifndef _CONFIG_H_
#define _CONFIG_H_


#define PRINT_DEBUG_MESSAGES    (1)


#ifdef PRINT_DEBUG_MESSAGES
#include <unistd.h>
#endif // PRINT_DEBUG_MESSAGES


#endif /* _CONFIG_H_ */
