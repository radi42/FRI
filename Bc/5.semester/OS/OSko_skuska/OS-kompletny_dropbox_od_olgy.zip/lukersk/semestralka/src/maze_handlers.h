#ifndef _MAZE_HANDLERS_H_
#define _MAZE_HANDLERS_H_

#include "buffer.h"
#include "arguments.h"
#include "maze.h"

#include "config.h"

#ifndef MAZE_H_SVG_FILEBASE
#define MAZE_H_SVG_FILEBASE     "out"
#endif // MAZE_H_SVG_FILEBASE

#ifndef MAZE_H_LOG_FILENAME
#define MAZE_H_LOG_FILENAME		"log.txt"
#endif // MAZE_H_LOG_FILENAME


/* Additional user defined buffer_s.state bits */
#define STATE_USER_GEN          (0x0000)
#define STATE_USER_SOLVE        (0x0100)
#define STATE_USER_PRINT        (0x0200)


struct _maze_buffer_data_s
{
    FILE* log;
    maze_arguments_s* arguments;

    maze_s maze;
};

typedef struct _maze_buffer_data_s maze_buffer_data_s;


void MazeBuffer_Prepare(const size_t length, buffer_s* buffers, void* arguments);

void MazeBuffer_Destroy(const size_t length, buffer_s* buffers);

void MazeBuffer_Generate(const size_t length, buffer_s* buffers);

void MazeBuffer_Solve(const size_t length, buffer_s* buffers);

void MazeBuffer_Print(const size_t length, buffer_s* buffers);


// void MazeLog_Process(char* filename);


#endif /* _MAZE_HANDLERS_H_ */
