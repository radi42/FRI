#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include <unistd.h>
#include <sys/mman.h>

#include "buffer.h"


void Prepare(const size_t length, buffer_s* buffers);
void Destroy(const size_t length, buffer_s* buffers);
void Task1(const size_t length, buffer_s* buffers);


int main()
{
    buffer_cntl_s cntl;
    int status;

    srand(time(NULL));

    status = BufferCntl_Initialize(&cntl, 3);
    if(status != 0) {
        exit(EXIT_FAILURE);
    }

    BufferCntl_DataPrepare(&cntl, &Prepare);
    BufferCntl_DataDestroy(&cntl, &Destroy);

    BufferCntl_DataProcess(&cntl, 0, &Task1);
    BufferCntl_DataProcess(&cntl, 1, &Task1);
    BufferCntl_DataProcess(&cntl, 2, &Task1);

    status = BufferCntl_Start(&cntl);
    if(status != 0) {
        exit(EXIT_FAILURE);
    }

    BufferCntl_Quit(&cntl);

    exit(EXIT_SUCCESS);
}

void Prepare(const size_t length, buffer_s* buffers)
{
    size_t i, j;
    size_t* data;

    printf("Preparing... ");

    for(i=0; i<length; i++) {
        buffers[i].data = mmap(NULL, 5*sizeof(size_t), PROT_READ|PROT_WRITE, MAP_SHARED|MAP_ANON, -1, 0);
        if(buffers[i].data == MAP_FAILED) {
            fputs("Error occured: Failed to map shared memory.\n", stderr);
            exit(EXIT_FAILURE);
        }

        data = (size_t*) buffers[i].data;
        for(j=0; j<5; j++) {
            data[j] = j;
        }
    }

    printf("Done.\n");
}

void Destroy(const size_t length, buffer_s* buffers)
{
    size_t i;

    printf("Destroying... ");

    for(i=0; i<length; i++) {
        munmap(buffers[i].data, 5*sizeof(size_t));
    }

    printf("Done.\n");
}

void Task1(const size_t length, buffer_s* buffers)
{
    size_t i;
    size_t* data;

    pthread_mutex_lock(&buffers[0].lock);

    printf("Child %d: Locked.\nData: ", getpid());

    data = (size_t*) buffers[0].data;
    for(i=0; i<5; i++) {
        printf("%lu ", data[i]);
        data[i] += 1;
    }
    puts("\n");

    printf("Child %d: Unlocking.\n", getpid());
    pthread_mutex_unlock(&buffers[0].lock);
}







