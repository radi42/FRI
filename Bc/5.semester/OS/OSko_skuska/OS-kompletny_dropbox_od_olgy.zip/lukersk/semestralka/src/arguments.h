/* \file arguments.h */
#ifndef _ARGUMENTS_H_
#define _ARGUMENTS_H_

#include <stdint.h>


#define MAZE_ARG_DEFAULT_HEIGHT     (25)    /**< Default value for maze height. */
#define MAZE_ARG_DEFAULT_WIDTH      (25)    /**< Default value for maze width. */
#define MAZE_ARG_DEFAULT_COUNT      (1)     /**< Default value for the count of generated mazes. */
#define MAZE_ARG_DEFAULT_SIZE       (10)    /**< Default value for maze tile in svg images in pixels. */


/** \struct Holds information about parameters used to generate mazes.
 *
 */
struct _maze_arguments_s
{
    uint32_t height; /**< \brief Height of generated mazes. */
    uint32_t width; /**< \brief Width of generated mazes. */
    size_t   count; /**< \brief Count of mazes to be generated. */
    size_t   size; /**< \brief Size of one maze tile in svg images. */
    char*    output; /**< \brief Basename for output files. */
};

typedef struct _maze_arguments_s maze_arguments_s;


int Maze_ParseArgumets(maze_arguments_s* arguments, int argc, char **argv);



#endif // _ARGUMENTS_H_
