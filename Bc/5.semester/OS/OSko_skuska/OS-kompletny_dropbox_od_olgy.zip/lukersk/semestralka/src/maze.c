/** \file maze.c 
 *  \brief Contains implementation of the maze library. 
 *  \author Lukáš Mandák
 */
#include <stddef.h>
#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#include <unistd.h>

#include "maze.h"


/** \brief Initializes the maze_s structure.
 *
 *  Width and height of the maze should be an odd number larger or equall to 5.
 *  If any dimension is less than 5 it will be corrected to 5.
 *  If any dimension is not an odd number it will be corrected by adding 1 to it.
 *
 *  By default memory large enough to fit the maze is allocated on heap. 
 *  Any memory previously allocated to pointer tile** is not freed and should be handled by Maze_Free() first.
 *
 *  If flag M_INIT_SHARED is set no memory will be allocated. Allocation should be handled externally with preffered shared memory device.
 *  In this case maze_s members allocated_height, allocated_width and tile** must be set correctly beforehand.
 *  If desired size defined by parameters height and witth will not fit in allocated shared memory proces will be terminated.
 *
 *  \param maze Pointer to structure that will be initialized.
 *  \param height Height of the maze.
 *  \param width Width of the maze.
 *  \param flags additional initialization options. (M_INIT_SHARED)
 *  \return Returns 0 on succes or -1 on failure.
 *
 */
int Maze_Initialize(maze_s* maze, uint32_t height, uint32_t width, uint32_t flags)
{
    uint32_t i;

    if(maze == NULL) {
        fputs("Error occured: Invalid maze pointer.\n", stderr);
        return -1;
    }

    if(width < 5) {
        fputs("Warning: Maze width is too small. Correcting value to 5.\n", stderr);
        width = 5;
    }
    if(height < 5) {
        fputs("Warning: Maze height is too small. Correcting value to 5.\n", stderr);
        height = 5;
    }

    if(!(width%2) ) {
        fprintf(stderr, "Warning: Maze dimensions must be an odd number. Correcting width from %u to %u.\n", width, width+1);
        width += 1;
    }
    if(!(height%2) ) {
        fprintf(stderr, "Warning: Maze dimensions must be an odd number. Correcting height from %u to %u.\n", height, height+1);
        height += 1;
    }

    if(flags&M_INIT_SHARED) {
        if(maze->allocated_height < height || maze->allocated_width < width) {
            fputs("Error occured: Allocated shared memory for maze is not large enough.\n", stderr);
            exit(EXIT_FAILURE);
        }
        if(maze->tile == NULL) {
            fputs("Error occured: Maze flagged as M_SHARED but tiles are not allocated.\n", stderr);
            exit(EXIT_FAILURE);
        }
        maze->_flags |= M_SHARED;
    }
    else {
        maze->tile = malloc(height * sizeof(tile_s*) );
        if(maze->tile == NULL) {
            fputs("Error occured: Failed to allocate space for maze. (1)\n", stderr);
            return -1;
        }

        for(i=0; i<height; i++) {
            maze->tile[i] = calloc(width, sizeof(tile_s) );
            if(maze->tile[i] == NULL) {
                fputs("Error occured: Failed to allocate space for maze. (2)\n", stderr);
                return -1;
            }
        }
        maze->allocated_height = height;
        maze->allocated_width = width;
    }

    maze->_flags &= M_SHARED;
    maze->width = width;
    maze->height = height;
    maze->path_length = 0;

    return 0;
}

int Maze_Write(maze_s* maze, FILE* file)
{
    uint32_t i;
    size_t count;

    if(maze == NULL) {
        fputs("Error occured: Invalid maze pointer.\n", stderr);
        return -1;
    }

    if(maze->tile == NULL) {
        fputs("Error occured: Maze is not initialized.\n", stderr);
        return -1;
    }

    if(file == NULL) {
        fputs("Error occured: Invalid file descriptior.\n", stderr);
    }

    count = fwrite(maze, sizeof(maze_s)-sizeof(tile_s**), 1, file);
    if(count != 1) {
        perror("Failed to write maze into file. (1)\n");
        return -1;
    }
    for(i=0; i<maze->height; i++) {
        count = fwrite(maze->tile[i], sizeof(tile_s), maze->width, file);
        if(count != maze->width) {
            perror("Failed to write maze into file. (2)\n");
            return -1;
        }
    }

    return 0;
}

int Maze_Read(maze_s* maze, FILE* file)
{
    uint32_t i;
    size_t count;
    maze_s tmp;

    if(maze == NULL) {
        fputs("Error occured: Invalid maze pointer.\n", stderr);
        return -1;
    }

    if(maze->tile != NULL && maze->height && maze->width) {
        Maze_Free(maze);
    }

    count = fread(&tmp, sizeof(maze_s)-sizeof(tile_s**), 1, file);
    if(count != 1) {
        perror("Failed to read maze from file. (1)\n");
        return -1;
    }

    Maze_Initialize(maze, tmp.height, tmp.width, 0);
    maze->_flags = tmp._flags;
    maze->path_length = tmp.path_length;

    for(i=0; i<maze->height; i++) {
        count = fread(maze->tile[i], sizeof(tile_s), maze->width, file);
        if(count != maze->width) {
            perror("Failed to read maze file file. (2)\n");
            return -1;
        }
    }

    return 0;
}

/** \brief Deallocates memory used for tiles.
 *
 *  Should not be called on mazes initialized with the M_INIT_SHARED flag.
 *
 * \param maze Pointer to maze_s structure previously allocated by Maze_Initialize().
 * \return none
 *
 */
void Maze_Free(maze_s* maze)
{
    uint32_t i;

    if(maze == NULL) {
        return;
    }

    if(maze->tile == NULL) {
        return;
    }

    if(maze->_flags&M_SHARED) {
        fputs("Error occured: Maze_Free() cannot free maze allocated in shared memory.\n", stderr);
        return;
    }

    for(i=0; i<maze->allocated_height; i++) {
        free(maze->tile[i]);
    }
    free(maze->tile);

    maze->_flags = 0;
    maze->allocated_height = 0;
    maze->allocated_width = 0;
    maze->width = 0;
    maze->height = 0;
    maze->path_length = 0;
    maze->tile = NULL;

    return;
}


/** \brief Generates pseudo random maze.
 *
 *  A random maze with exactly one path between any two points in the maze will be generated.
 *
 *  \param maze Initialized maze structure.
 *  \return Returns 0 on succes or -1 on failure.
 *
 */
int Maze_Generate(maze_s* maze)
{
    uint32_t i, j;
    uint32_t base_cnt;
    uint32_t direction;

    if(maze == NULL) {
        fputs("Error occured: Invalid maze pointer.\n", stderr);
        return -1;
    }

    if(maze->tile == NULL) {
        fputs("Error occured: Maze is not initialized.\n", stderr);
        return -1;
    }

    /* Clear maze */
    //if(maze->_flags & M_GENERATED) {
        for(i=1; i<maze->height-1; i++) {
            for (j=1; j<maze->width-1; j++) {
                maze->tile[i][j].type = M_TT_EMPTY;
            }
        }
    //}
    //else {
        /* Create basic outline */
        for(i=0; i<maze->width; i++) {
            maze->tile[0][i].type = M_TT_WALL;
        }
        for(i=0; i<maze->width; i++) {
            maze->tile[maze->height-1][i].type = M_TT_WALL;
        }
        for(i=1; i<maze->height-1; i++) {
            maze->tile[i][0].type = M_TT_WALL;
            maze->tile[i][maze->width-1].type = M_TT_WALL;
        }
    //}

    /* Place base points */
    for(i=2; i<maze->height-2; i+=2) {
        for(j=2; j<maze->width-2; j+=2) {
            maze->tile[i][j].type = M_TT_BASE;
        }
    }

    /* Create walls */
    base_cnt = ((maze->width-3)/2) * ((maze->height-3)/2);
    while(base_cnt) {
        i = 2 + 2*(rand()%((maze->height-3)/2));
        j = 2 + 2*(rand()%((maze->width-3)/2));

        if(maze->tile[i][j].type == M_TT_BASE) {
            maze->tile[i][j].type = M_TT_WALL;
            base_cnt -= 1;

            direction = rand()%4;
            while(1) {
                switch(direction) {
                    case 0:
                        i -= 1;
                        break;
                    case 1:
                        i += 1;
                        break;
                    case 2:
                        j -= 1;
                        break;
                    case 3:
                        j += 1;
                        break;
                }

                if(maze->tile[i][j].type == M_TT_BASE) {
                    base_cnt -= 1;
                }

                if(maze->tile[i][j].type != M_TT_WALL) {
                    maze->tile[i][j].type = M_TT_WALL;
                }
                else {
                    break;
                }
            }
        }
    }

    maze->_flags |= M_GENERATED;
    maze->_flags &= ~(M_SOLVED);

    return 0;
}

/** \brief Finds path between top left and bottom right corners of the maze.
 *  
 *  Implemented method: Dead end filler. Is good enough for mazes generated with Maze_Generate().
 *
 *  \param maze Generated maze structure.
 *  \return Returns 0 on succes or -1 on failure.
 */
int Maze_Solve(maze_s* maze)
{
    uint32_t i, j;
    uint8_t change;
    uint8_t wall_cnt;
    uint32_t path_length;

    if(maze == NULL) {
        fputs("Error occured: Invalid maze pointer.\n", stderr);
        return -1;
    }

    if(maze->tile == NULL) {
        fputs("Error occured: Maze is not initialized.\n", stderr);
        return -1;
    }

    if(!(maze->_flags & M_GENERATED)) {
        fputs("Error occured: Maze was not generated yet.\n", stderr);
        return -1;
    }

    if(maze->_flags & M_SOLVED) {
        return 0;
    }

    for(i=0; i<maze->height; i++) {
        for(j=0; j<maze->width; j++) {
            if(TILE_TYPE(maze->tile[i][j].type) == M_TT_WALL) {
                maze->tile[i][j].distance = M_TD_WALL;
            }
            else {
                maze->tile[i][j].distance = M_TD_MAX;
            }
        }
    }

    /* Dead end filler */
    maze->tile[1][1].distance = 0;
    maze->tile[maze->height-2][maze->width-2].distance = 0;
    change = 1;
    while(change) {
        change = 0;
        for(i=1; i<maze->height-1; i++) {
            for(j=1; j<maze->width-1; j++) {
                if(maze->tile[i][j].distance == M_TD_MAX) {
                    wall_cnt = 0;
                    if(maze->tile[i-1][j].distance == M_TD_WALL) {
                        wall_cnt += 1;
                    }
                    if(maze->tile[i+1][j].distance == M_TD_WALL) {
                        wall_cnt += 1;
                    }
                    if(maze->tile[i][j-1].distance == M_TD_WALL) {
                        wall_cnt += 1;
                    }
                    if(maze->tile[i][j+1].distance == M_TD_WALL) {
                        wall_cnt += 1;
                    }

                    if(wall_cnt >= 3) {
                        maze->tile[i][j].distance = M_TD_WALL;
                        change = 1;
                    }
                }
            }
        }
    }
    maze->tile[1][1].distance = M_TD_MAX;
    maze->tile[maze->height-2][maze->width-2].distance = M_TD_MAX;

    //Maze_Print(maze, NULL, M_P_INFO|M_P_DEBUG);

    path_length = 0;
    for(i=1; i<maze->height-1; i++) {
        for(j=1; j<maze->width-1; j++) {
            if(maze->tile[i][j].distance == M_TD_MAX) {
                maze->tile[i][j].type = M_TT_PATH;
                path_length += 1;
            }
        }
    }

    maze->tile[1][1].type = M_TT_START;
    maze->tile[maze->height-2][maze->width-2].type = M_TT_FINISH;

    maze->path_length = path_length-1;
    maze->_flags |= M_SOLVED;

    return 0;
}

/** \brief Prints maze in text format to file.
 *
 *  \param maze Maze structure.
 *  \param file A valid file descriptor (stdout). 
 *  \param flags For printing more information (M_P_TEXT_INFO, M_P_TEXT_PATH, M_P_TEXT_DEBUG).
 *  \return none
 */
void Maze_Print(maze_s* maze, FILE* file, maze_print_t flags)
{
    uint32_t i, j;
    char path_fmt[] = _M_P_TYPE_PATH;
    char base_fmt[] = _M_P_DBG_BASE;

    if(maze == NULL) {
        fputs("Error occured: Invalid maze pointer.\n", stderr);
        return;
    }

    if(maze->tile == NULL) {
        fputs("Error occured: Maze is not initialized.\n", stderr);
        return;
    }

    if(file == NULL) {
        file = stdout;
    }

    if(flags & M_P_TEXT_INFO) {
        fprintf(file, "Height: %u\n", maze->height);
        fprintf(file, "Width:  %u\n", maze->width);
        if(maze->_flags&M_SOLVED) {
            fprintf(file, "Length: %u\n", maze->path_length);
        }
        else {
            fputs("Length: -\n", file);
        }
    }

    if( !(flags & M_P_TEXT_PATH) ) {
        path_fmt[0] = ' ';
    }

    if( !(flags & M_P_TEXT_DEBUG) ) {
        base_fmt[0] = ' ';
    }

    for(i=0; i<maze->height; i++) {
        for(j=0; j<maze->width; j++) {
            switch(TILE_TYPE(maze->tile[i][j].type)) {
                case M_TT_EMPTY:
                    if( !(flags & M_P_TEXT_DEBUG) ) {
                        fputs(_M_P_TYPE_EMPTY, file);
                    }
                    else {
                        if(maze->tile[i][j].distance == M_TD_WALL) {
                            fputs(_M_P_DBG_DEAD_END, file);
                        }
                        else {
                            if(maze->tile[i][j].distance == M_TD_MAX) {
                                fputs(_M_P_DBG_MAX_DIST, file);
                            }
                            else {
                                fputs(_M_P_TYPE_EMPTY, file);
                            }
                        }
                    }
                    break;
                case M_TT_WALL:
                    fputs(_M_P_TYPE_WALL, file);
                    break;
                case M_TT_PATH:
                    fputs(path_fmt, file);
                    break;
                case M_TT_START:
                    if(flags & M_P_TEXT_PATH) {
                        fputs(_M_P_TYPE_START, file);
                    }
                    else {
                        fputs(_M_P_TYPE_EMPTY, file);
                    }
                    break;
                case M_TT_FINISH:
                    if(flags & M_P_TEXT_PATH) {
                        fputs(_M_P_TYPE_FINISH, file);
                    }
                    else {
                        fputs(_M_P_TYPE_EMPTY, file);
                    }
                    break;
                case M_TT_BASE:
                    fputs(base_fmt, file);
                    break;
            }
        }
        fputc('\n', file);
    }
    fputc('\n', file);

    return;
}

static void Maze_PrintTileType(maze_s* maze, FILE* file, const uint8_t type, const uint32_t size)
{
    uint32_t i, j;
    uint32_t length;

    fputs("<g fill=\"", file);
    switch(type) {
        case M_TT_WALL:
            fputs("black", file);
            break;
        case M_TT_PATH:
            fputs("rgb(210, 0, 0)", file);
            break;
        default:
            fputs("rgb(128, 128, 128)", file);
            break;
    }
    fputs("\" >\n", file);

    for(i=0; i<maze->height; i++) {
        for(j=0; j<maze->width; j++) {
            if(maze->tile[i][j].type == type) {
                maze->tile[i][j].type |= M_TT_SVG_USED;

                fprintf(file, "<rect x=\"%upx\" y=\"%upx\" height=\"", j*size, i*size);

                length = 1;
                if(j+1 < maze->width && maze->tile[i][j+1].type == type) {
                    while(j+length < maze->width && maze->tile[i][j+length].type == type) {
                        maze->tile[i][j+length].type |= M_TT_SVG_USED;
                        length += 1;
                    }
                    fprintf(file, "%upx\" width=\"%upx\"", size, length*size);
                }
                else {
                    if(i+1 < maze->height && maze->tile[i+1][j].type == type) {
                        while(i+length < maze->height && maze->tile[i+length][j].type == type) {
                            maze->tile[i+length][j].type |= M_TT_SVG_USED;
                            length += 1;
                        }
                        fprintf(file, "%upx\" width=\"%upx\"", length*size, size);
                    }
                    else {
                        fprintf(file, "%upx\" width=\"%upx\"", size, size);
                    }
                }
                fputs(" />\n", file);
            }
        }
    }
    fputs("</g>\n", file);

    /* clean */
    for(i=0; i<maze->height; i++) {
        for(j=0; j<maze->width; j++) {
            maze->tile[i][j].type &= M_TT_MASK;
        }
    }

    return;
}

/** \brief Prints svg image of maze.
 *
 * \param maze Generated maze structure.
 * \param filename Basename of output file. A filename "maze" will generate file "maze.svg" or "maze_solved.svg".
 * \param flags Flags defining what to print. (M_P_SVG_PATH, M_P_SVG_SEPARATE)
 *
 */
void Maze_PrintSvg(maze_s* maze, char* filename, const maze_print_t flags, const uint32_t size)
{
    FILE* file;
    char* name;
    char* name_solved;
    char* cp = NULL;

    if(maze == NULL) {
        fputs("Error occured: Invalid maze pointer.\n", stderr);
        return;
    }

    if(maze->tile == NULL) {
        fputs("Error occured: Maze is not initialized.\n", stderr);
        return;
    }

    if(filename == NULL || !strlen(filename) ) {
        fputs("Error occured: Output filename is invalid.\n", stderr);
        return;
    }

    name = malloc( (strlen(filename)+7)*sizeof(char) );
    sprintf(name, "%s.svg", filename);

    name_solved = malloc( (strlen(filename)+13)*sizeof(char) );
    sprintf(name_solved, "%s_solved.svg", filename);

    if( !(flags&M_P_SVG_PATH) || flags&M_P_SVG_SEPARATE ) {
        file = fopen(name, "w");
        if(file == NULL) {
            fprintf(stderr, "Error while opening file %s: ", name);
            perror("");
            return;
        }
    }
    else {
        file = fopen(name_solved, "w");
        if(file == NULL) {
            fprintf(stderr, "Error while opening file %s", name_solved);
            perror("");
            return;
        }
    }

    /* header */
    fputs("<?xml version=\"1.0\" encoding=\"ISO-8859-1\" standalone=\"no\"?>\n"
          "<!DOCTYPE svg PUBLIC \"-//W3C//DTD SVG 20010904//EN\" "
          "\"http://www.w3.org/TR/2001/REC-SVG-20010904/DTD/svg10.dtd\"> "
          "<svg xmlns=\"http://www.w3.org/2000/svg\" "
          "xmlns:xlink=\"http://www.w3.org/1999/xlink\" xml:space=\"preserve\"\n",
          file);
    fprintf(file, " width=\"%upx\" height=\"%upx\"\n", maze->width*size, maze->height*size);
    fprintf(file, " viewBox=\"0px 0px %upx %upx\"\n", maze->width*size, maze->height*size);
    //fputs(" zoomAndPan=\"disable\" >\n", file);
    fputs(" >\n", file);
    /* bg */
    fprintf(file, "<rect id=\"bg\" x=\"0px\" y=\"0px\" width=\"%upx\" height=\"%upx\" fill=\"white\"/>\n", maze->width*size, maze->height*size);
    /* walls */
    Maze_PrintTileType(maze, file, M_TT_WALL, size);
    /* path */
    if(!(flags&M_P_SVG_SEPARATE) ) {
        if(flags&M_P_SVG_PATH) {
            Maze_PrintTileType(maze, file, M_TT_PATH, size);
        }
        fputs("</svg>\n", file);
        fclose(file);
    }
    else {
        fclose(file);

        cp = malloc( (2*strlen(name)+32)*sizeof(char) );
        sprintf(cp, "cp %s %s", name, name_solved);
        system(cp);
        free(cp);
        cp = NULL;

        file = fopen(name, "a");
        if(file == NULL) {
            perror("Error while opening file");
            return;
        }
        fputs("</svg>\n", file);
        fclose(file);

        file = fopen(name_solved, "a");
        if(file == NULL) {
            perror("Error while opening file");
            return;
        }
        Maze_PrintTileType(maze, file, M_TT_PATH, size);
        fputs("</svg>\n", file);
        fclose(file);
    }

    free(name);
    free(name_solved);

    return;
}
