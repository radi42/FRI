/** \file maze.c */
#ifndef _MAZE_H_
#define _MAZE_H_

#include <stdint.h>


/* Tile type definitions */
#define M_TT_EMPTY          (0x00)
#define M_TT_WALL           (0x01)
#define M_TT_PATH           (0x02)
#define M_TT_START          (0x03)
#define M_TT_FINISH         (0x04)
#define M_TT_BASE           (0x05)

#define M_TT_SVG_USED       (0x10)

#define M_TT_MASK           (0x0F)

/* Tile distance definitions */
#define M_TD_MAX            (UINT32_MAX-1)
#define M_TD_WALL           (UINT32_MAX)
#define M_TD_UNDEFINED      (UINT32_MIN)

struct _tile_s
{
    uint8_t  type;
    uint32_t distance;
};

typedef struct _tile_s tile_s;

#define TILE_TYPE(x) ((x)&(M_TT_MASK))


/* Maze flags definitions */
#define M_GENERATED         (0x01)
#define M_SOLVED            (0x02)
#define M_SHARED            (0x04)

struct _maze_s
{
    uint8_t  _flags;

    uint32_t allocated_height;
    uint32_t allocated_width;

    uint32_t height;
    uint32_t width;

    uint32_t path_length;

    tile_s** tile;
};

typedef struct _maze_s maze_s;


#define M_INIT_SHARED			(0x0001)
/* Allocates memory for maze of given size. (only odd numbers) */
int Maze_Initialize(maze_s* maze, uint32_t height, uint32_t width, uint32_t flags);

/* Loads maze from file in binary format. */
int Maze_Read(maze_s* maze, FILE* file);

/* Writes maze into file in binary format. */
int Maze_Write(maze_s* maze, FILE* file);

/* Frees all memory allocated by Maze_Initialize(). */
void Maze_Free(maze_s* maze);

/* Creates pseudo-random maze in an initialized maze structure. */
int Maze_Generate(maze_s* maze);

/* Finds shortest path in generated maze.*/
int Maze_Solve(maze_s* maze);


/* Text printing flags definitions */
#define M_P_TEXT_INFO       (0x01)
#define M_P_TEXT_PATH       (0x02)
#define M_P_TEXT_DEBUG      (0x04)

/* ASCI strings for tile types */
#define _M_P_TYPE_EMPTY     "  "
#define _M_P_TYPE_WALL      "O "
#define _M_P_TYPE_PATH      ". "
#define _M_P_TYPE_START     "S "
#define _M_P_TYPE_FINISH    "F "
#define _M_P_DBG_BASE       "b "
#define _M_P_DBG_DEAD_END   "x "
#define _M_P_DBG_MAX_DIST   "m "

typedef uint8_t maze_print_t;

/* Prints maze into given stream (stdout if NULL) in ASCII format.*/
void Maze_Print(maze_s* maze, FILE* file, maze_print_t flags);


/* Svg printing flags definition */
#define M_P_SVG_PATH        (0x10) /**< \brief Show shortest path in the image. */
#define M_P_SVG_SEPARATE    (0x20) /**< \brief Create separate files for image with and without path. */

/* Creates a scalable vector graphic image of given maze. */
void Maze_PrintSvg(maze_s* maze, char* filename, const maze_print_t flags, const uint32_t size);


#endif /* _MAZE_H_ */
