/** \file buffer.h */
#ifndef _BUFFER_H_
#define _BUFFER_H_

#include <stddef.h>
#include <stdint.h>

#include <unistd.h>
#include <semaphore.h>


/* buffer_s state bit definitions */
#define STATE_READY             (0x0001)
#define STATE_CLOSED            (0x0002)
//#define STATE_RESERVED_BITS     (0x00FC)
#define STATE_USER_BITS         (0xFF00)


/** \struct Contains data required by buffer.
 *
 *  
 */
struct _buffer_s
{
    sem_t* lock;            /**< \brief Pointer to semaphore used to lock the buffer. */
    char lock_name[255];    /**< \brief Name of semaphore needed to unlink it when program ends. */

    uint32_t state;         /**< \brief Current state of the buffer. */

    void* data;             /**< \brief Pointer to shared user data is stored here. */
};

typedef struct _buffer_s buffer_s;


typedef void (*buffer_handler)(const size_t, buffer_s*); /**< \brief Prototype for user function that will be proccessing user data. */

/** \brief Prototype for function that will initialize shared user data of every buffer based on provided arguments. */
typedef void (*prepare_handler)(const size_t, buffer_s*, void* arguments);


/** \struct 
 *
 */
struct _buffer_cntl_s
{
    size_t length;              /**< \brief Number of buffers to be created. */

    pid_t* child_pids;          /**< \brief Array of all child processes that are created. */

    prepare_handler prepare;    /**< \brief Pointer to funcion, which will allocate shared data for every buffer. */
    void* prepare_arguments;    /**< \brief Pointer to arguments structure that will be used by prepare handler. */

    buffer_handler* handlers;   /**< \brief Array of functions that will process date data in each step. */

    buffer_s* buffer;           /**< */
};

typedef struct _buffer_cntl_s buffer_cntl_s;


int BufferCntl_Initialize(buffer_cntl_s* cntl, const size_t length);

void BufferCntl_Quit(buffer_cntl_s* cntl, size_t is_parent);

void BufferCntl_DataPrepare(buffer_cntl_s* cntl, prepare_handler prepare_handler, void* arguments);

void BufferCntl_DataDestroy(buffer_cntl_s* cntl, buffer_handler destroy_handler);

void BufferCntl_DataProcess(buffer_cntl_s* cntl, const size_t stage, buffer_handler handler);

int BufferCntl_Start(buffer_cntl_s* cntl);

inline void Buffer_Lock(buffer_s* buffer) { sem_wait(buffer->lock); }

inline void Buffer_Unlock(buffer_s* buffer) { sem_post(buffer->lock); }


#endif /* _BUFFER_H_ */
