#include <stdlib.h>
#include <stdint.h>
#include <argp.h>

#include <unistd.h>

#include "config.h"
#include "arguments.h"

const char *argp_program_version = "os-16-mandak-RC-2";
const char *argp_program_bug_address = "<lukas.mandak@yandex.com>";

static char doc[] = "Operačné systémy, semestrálka, zadanie 16.\nLukáš Mandák, 5ZP031";
static char args_doc[] = "COUNT";

/** \brief The command line options we understand. */
static struct argp_option options[] = {
    {"height", 'h', "value",    0, "Height of generated mazes\nMust be an ODD number equal or greather than 5", 0 },
    {"width",  'w', "value",    0, "Width of generated mazes\nMust be an ODD number equal or greather than 5", 0 },
    {"output", 'o', "filename", 0, "Specify output name to filename_n.svg or filename_n_solved.svg respectively", 0},
    {"size",   's', "value",    0, "Size of one tile in maze in pixels", 0},
    { 0 }
};


/** \brief Parse a single option. 
 *
 **/
static error_t parse_opt(int key, char *arg, struct argp_state *state)
{
    maze_arguments_s* arguments = (maze_arguments_s*) state->input;
    int32_t val;

    switch (key) {
        case 'h':
            val = atoi(arg);
            if(val < 5 || !(val%2) ) {
                argp_usage(state);
            }
            arguments->height = val;
            break;

        case 'w':
            val = atoi(arg);
            if(val < 5 || !(val%2) ) {
                argp_usage(state);
            }
            arguments->width = val;
            break;

        case 'o':
            arguments->output = arg;
            break;

        case 's':
            val = atoi(arg);
            if(val <= 0) {
                argp_usage(state);
            }
            arguments->size = val;
            break;

        case ARGP_KEY_ARG:
            if (state->arg_num >= 1)
                argp_usage(state);

            val = atoi(arg);
            if(val <= 0) {
                argp_usage(state);
            }
            arguments->count = atoi(arg);
            break;

        case ARGP_KEY_END:
            if (state->arg_num < 1)
                argp_usage(state);
            break;

        default:
          return ARGP_ERR_UNKNOWN;
    }
    return 0;
}

/** \brief Parse command line arguments used for maze generation
 *
 *  Given arguments structure will be initialized to default values and then modified by argp according to programs input.
 *  
 *  \param arguments Structure to be filled.
 *  \param argc Arguments count from main.
 *  \param argv Arguments vector from main.
 *
 *  \return 0 on success.
 */
int Maze_ParseArgumets(maze_arguments_s* arguments, int argc, char **argv)
{
    arguments->height = MAZE_ARG_DEFAULT_HEIGHT;
    arguments->width = MAZE_ARG_DEFAULT_WIDTH;
    arguments->count = MAZE_ARG_DEFAULT_COUNT;
    arguments->output = NULL;
    arguments->size = MAZE_ARG_DEFAULT_SIZE;

    struct argp argp = {options, parse_opt, args_doc, doc, NULL, 0, 0};

    argp_parse (&argp, argc, argv, 0, 0, arguments);

    #ifdef PRINT_DEBUG_MESSAGES
    printf("%u Parsed arguments:\n%u: height = %u\n%u: width = %u\n%u: count = %lu\n%u: output = %s\n%u: size=%lu\n", getpid(),
        getpid(), arguments->height, getpid(),arguments->width, 
        getpid(), arguments->count, 
        getpid(), arguments->output!=NULL?arguments->output:"NULL",
        getpid(), arguments->size
        );
    #endif

    return 0;
}
