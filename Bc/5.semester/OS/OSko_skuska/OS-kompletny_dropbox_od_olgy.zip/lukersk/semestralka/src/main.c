#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include <unistd.h>

#include "config.h"

#include "arguments.h"
#include "buffer.h"
#include "maze_handlers.h"


int main(int argc, char** argv)
{
    maze_arguments_s arguments;
    buffer_cntl_s cntl;
    int status;

    srand(time(NULL));

    Maze_ParseArgumets(&arguments, argc, argv);

    status = BufferCntl_Initialize(&cntl, 3);
    if(status != 0) {
        exit(EXIT_FAILURE);
    }

    BufferCntl_DataPrepare(&cntl, &MazeBuffer_Prepare, &arguments);
    BufferCntl_DataDestroy(&cntl, &MazeBuffer_Destroy);

    BufferCntl_DataProcess(&cntl, 0, &MazeBuffer_Generate);
    BufferCntl_DataProcess(&cntl, 1, &MazeBuffer_Solve);
    BufferCntl_DataProcess(&cntl, 2, &MazeBuffer_Print);

    status = BufferCntl_Start(&cntl);
    switch(status) {
        case 0: // parent
            //MazeLog_Process(BUFFER_LOG_FILENAME);
            BufferCntl_Quit(&cntl, 1);
            break;
        case 1: // child
            BufferCntl_Quit(&cntl, 0);
            break;
        default:
            exit(EXIT_FAILURE);
    }
    

    #ifdef PRINT_DEBUG_MESSAGES
    fflush(stdout);
    printf("%u: Exiting process: SUCCESS\n", getpid() );
    fflush(stdout);
    #endif // PRINT_DEBUG_MESSAGES

    exit(EXIT_SUCCESS);
}
