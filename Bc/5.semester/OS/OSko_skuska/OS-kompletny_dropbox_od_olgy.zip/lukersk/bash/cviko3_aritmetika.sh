#!/usr/bin/bash

## Aritmeticke operacie
jeden=1
dva=2
let tri=jeden+dva
echo "$tri"
let a=(dva+jeden)*tri
echo "$a"
let "b=dva>jeden"
echo "$b"
c=$((dva>5))
echo "$c"
echo $((1+1))
echo $[1+1]
