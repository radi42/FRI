#!/bin/bash

NAME[1]='Prvy'
NAME[2]='Druhy'
NAME[3]=${NAME[2]}

echo ${NAME[3]}

echo ${NAME[*]}
