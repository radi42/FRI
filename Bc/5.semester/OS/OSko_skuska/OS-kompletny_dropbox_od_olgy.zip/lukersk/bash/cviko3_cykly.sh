#!/usr/bin/bash

## for
echo "for:"
for num in 1 2 3 4 5 6
do
    echo $num
done

## while
echo "while:"
i=0
while [ $i -lt 4 ]
do
    echo "$i"
    i=$(($i+1))
done
