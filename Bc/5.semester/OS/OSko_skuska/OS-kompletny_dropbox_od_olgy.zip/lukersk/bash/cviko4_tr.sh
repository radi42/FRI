#!/bin/bash

echo 'BlaBol' | tr l u
echo 'lowercase' | tr a-z A-Z

echo 'This is Spartaaaaaaaaaaaaaaaaaaaaaa!!!!!!!!!!!' | tr -s a!

echo 'Toto je veta.' | tr -d 'je'

