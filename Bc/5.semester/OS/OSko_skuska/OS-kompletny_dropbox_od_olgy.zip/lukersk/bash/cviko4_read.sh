#!/bin/bash

#read A B C
echo $A
echo $B
echo $C

## Nacita iba jeden znak (necaka na enter)
#read -n 1 A
echo $A

## Nezobrazuje napisane znaky
#read -s HESLO
echo $HESLO

## Defaultna hodnota
#read H
echo $H
echo ${H:-Default}
echo ${#H}

R='Ako sa mas'
echo ${R%%sa*}
