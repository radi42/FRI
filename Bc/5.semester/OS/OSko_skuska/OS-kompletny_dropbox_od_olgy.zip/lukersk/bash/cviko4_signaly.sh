#!/bin/bash

trap 'echo Blabool' EXIT

function trololo()
{
    echo "Hodnota"
}

R="${trololo}"
echo $R
