#!/usr/bin/bash

## man expr
STR1="Retazec"
echo `expr length $STR1`
echo `expr index $STR1 t`

## man test
## zamenitelne za [...]
ret1="blabol"
ret2="blabol"
ret3="blabel"

if [ $ret1 = $ret2 ]; then echo "Su rovnake"; fi
if [ $ret1 = $ret3 ]; then
    echo "Su rovnake"
else
    echo "Nie su rovnake"
fi

cislo1=25
cislo2=6
if [ $cislo1 -gt $cislo2 ]; then echo "$cislo1 je vacsie ako $cislo2"; fi

if [ -d ~/Documents ]; then echo "Je to priecinok"; fi
if [ -w ./cviko3_aritmetika.sh ]; then echo "Dokaze zapisovat"; fi
if [ -w ./etc/slim.conf ]; then
    echo "Dokaze zapisovat"
else
    echo "Nedokaze zapisovat"
fi

## case
prem="h"
case $prem in
    [aA])
        echo "A"
        ;;
    [dD])
        echo "D"
        ;;
    *)
        echo "zvysok"
        ;;
esac

