#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>

int main(int argc, char *argv[]){
	int socketID = 0, connectionID = 0, clilen = 0, poc_precitanych_bytov = 0, pocetPoslanychBytov = 0; //vynulovanie socketID a connectionID...
	int portNo = 46745;  //nastavenie cisla portu
	int n, len;
	struct sockaddr_in adresaServera, adresaKlienta;
	char readBuff[256]; //buffer na prijimanie dat cez socket
	char response[256]; //buffer na odosielanie cez socket
    char fileExt[256]; //nazov suboru na odoslanie
    char* token; //casti poziadavky

	//vytvorenie socketa
	socketID = socket(AF_INET, SOCK_STREAM, 0);
        printf("Socket created sucessfuly\n");
		//kontrola vytvorenia socketa
		if (socketID < 0){
			perror("Chyba otvaranie socketa!");
		}

	//portno = atoi(argv[1]); //nacitanie cisla portu z parametrov - konverzia zo string na int

	memset(&adresaServera, '0', sizeof(adresaServera)); //vymazanie struktury adresa servera
	//definovanie adresyServera
	adresaServera.sin_family = AF_INET;
    adresaServera.sin_addr.s_addr = htonl(INADDR_ANY);
    adresaServera.sin_port = htons(portNo);

    //previazanie descriptora socketu s adresou hosta
	if (bind(socketID, (struct sockaddr *) &adresaServera, sizeof(adresaServera)) < 0){
		perror("Chyba pri binde!");
		close(socketID);
		exit(1);
	}
        printf("Binding sucessful\n");

	listen(socketID, 5);

    while (1){ //hlavny serverovy loop
        clilen = sizeof(adresaKlienta);
        connectionID = accept(socketID,  (struct sockaddr *) &adresaKlienta, &clilen);
            printf("Connection established\n");
            //kontrola pripojenia - connection
            if (connectionID < 0){
                perror("Chyba pri accepte!");
                close(connectionID);
                exit(1);
            }

        //printf("\nConnect from host %s\n",inet_ntoa(adresaKlienta.sin_addr));
        //printf("\nConnect from host %s, port %d\n",inet_ntoa(adresaKlienta.sin_addr), ntohs(adresaKlienta.sin_port) );

        memset(readBuff, '0', sizeof(readBuff)); //vynulovanie read buferea

        recv( connectionID, readBuff, sizeof( readBuff ), 0 )
            if ( strstr(readBuff,"GET") ) { //nastavi pointer readBufera na zaciatok GET
                token = strtok(readBuff," "); //vrati co je pred najblizsiou medzerov -> "GET"
                token = strtok(NULL," "); //vrati to co je za GET -> adresu suboru
                    printf("Subor: %s\n", token); //kontrolny vypis

                sprintf(fileExt,".%s",token);
                    printf("Meno suboru: %s\n", fileExt); //kontrolny vypis
                FILE *fp; //deklaracia suboru, file pointer
                fp = fopen(fileExt, "r"); //otvorenie suboru

                if (fp != NULL) {
                        printf("Sending response...\n"); //kontrolny vypis
                    pocetPoslanychBytov = send( connectionID, "HTTP/1.0 200 OK\r\n\r\n", 23, 0);

                    while( poc_precitanych_bytov = fread(response, 1, sizeof(response), fp) ) {
                        printf("Start sending file...");
                        int length = strlen(response)-1;
                        if(response[length] == '\n') {
                            response[length] = 0;
                        } //end if response length
                        pocetPoslanychBytov += send(connectionID, response, poc_precitanych_bytov, 0 );
                        fclose(fp); //zatvorenie suboru

                        printf("Sending sucessful, number of send bytes: %d\n", pocetPoslanychBytov);
                    } //end fread
                } else { //end if (fp!=NULL)
                    printf("file do NOT exists\n"); //kontrolny vypis
                    send(connectionID, "HTTP/1.0 404 Not Found\r\n\r\n", 30, 0);
                }// end else fp!=NULL

            }// end if strstr
        //close(connectionID); //zatvorenie spojenia
        printf("Koniec spracovania poziadaviek\n");
    } // end while 1 - hlavny serverovy loop
    printf("Koniec hlavneho loop\n");
}
