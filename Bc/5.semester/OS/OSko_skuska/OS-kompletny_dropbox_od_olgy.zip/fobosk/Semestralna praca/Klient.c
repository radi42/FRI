#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <stdlib.h>
#include <Lunistd.h>

int main(int argc, char *argv[]){
    int sock;
    struct sockaddr_in server;
    struct hostent *hp;
    char buff[1024];


    /*Vytvor socket*/
    //AF_INET ipv4 domena
    //SCOK_STREAM spolahlive prudove bajtove spojenie, zarucuje poradie sprav, full dupex
    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0){
        perror("KLIENT: Chyba pri vytvarani socketu");
        exit(1);
    }

    server.sin_family = AF_INET;
    server.sin_port = htons(5000);

    memset()


    if(connect(sock, (struct sockaddr *)&server, sizeof(server)) < 0)
    {
       printf("KLIENT: Chyba pri pripojeni \n");
       return 1;
    }


    return(0);
}
