#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <errno.h>
#include <string.h>
#include <sys/types.h>
#include <time.h>

int vytvorSocket(int port);

int main(int argc, char *argv[])
{
    /* premenne pre spojenie (socket) */
    int listenfd = 0, connfd = 0; //subory
    char buffer[256];

    /* premenne servera */
    //pojde potom ako paramater ./SocketServer $ADRESAR $PORT
    int cisloPort = 8000;
    char korenAdresar[] = "./AdresarServera";

    // korenAdresar = argv[1];
    // cisloPort = atoi(argv[2]);

    /* zaciatok kodu */
    printf("Server bol pusteny!\n");

    listenfd = vytvorSocket(cisloPort);
    
    //10 odmietnute pripojenie
    listen(listenfd, 10);

    while(1)
    {	//adrese clienta sockaddr
        connfd = accept(listenfd, (struct sockaddr*)NULL, NULL);

        /* KOD OBSLUHY SERVERA */

        // nacitaj poziadavku do vstupneho buffera ('GET ...\r\n')
        // read(connfd, ..);
		memset(&buffer, 0, 256);
		int n = read(connfd, buffer, 255);
		if (n < 0){
			perror("Chyba pri nacitavani poziadavky");
		}
		
		printf("Poziadavka od klienta: %s\n", buffer);


        // spracuj buffer (zisti, aky subor GET chce a ci ho mozes poslat (osetrenie chyb) )

        // otvor subor a cely ho odosli
        // file = fopen(nazovPozadovanehoSuboru, "r");
        // write(connfd, ..);
        // fclose(file);


        // char sendBuff[1024];
        // ticks = time(NULL);
        // snprintf(sendBuff, sizeof(sendBuff), "Toto je casova odpoved servra: %.24s\r\n", ctime(&ticks));
        // write(connfd, sendBuhff, strlen(sendBuff));

        /* KONIEC KODU OBSLUHY SERVERA */

        close(connfd);
        sleep(1);
     }

     close(listenfd);
}

int vytvorSocket(int port)
{
    int listenfd = 0;
    struct sockaddr_in serv_addr;

    //PF_INET ipv4 domena
    //SCOK_STREAM spolahlive prudove bajtove spojenie, zarucuje poradie sprav, full dupex
    listenfd = socket(AF_INET, SOCK_STREAM, 0); //int socket(int domain, int type, int protocol)
    
    memset(&serv_addr, '0', sizeof(serv_addr));

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_addr.s_addr = htonl(INADDR_ANY);
    serv_addr.sin_port = htons(port);

    bind(listenfd, (struct sockaddr*)&serv_addr, sizeof(serv_addr));

    return listenfd;
}
