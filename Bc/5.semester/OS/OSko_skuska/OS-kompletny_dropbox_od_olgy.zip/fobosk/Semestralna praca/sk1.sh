#!/bin/bash
echo $PAR1
echo $PAR2
echo $PAR3
