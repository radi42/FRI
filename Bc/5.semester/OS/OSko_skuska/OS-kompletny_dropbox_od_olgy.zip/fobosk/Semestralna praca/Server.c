#include <stdio.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string.h>
#include <stdlib.h>

int main(int argc, char *argv[]){
    /*Premenne*/
    int sock;
    struct sockaddr_in adresaServera, adresaKlienta;
    int mySock;
    char buff[1024]; //buffer ktory bude drzat data
    int rval; //return value
    int dlzkaAdresy; //dlzka adresy klienta
    //int cisloPortu = atoi(argv[2]);//46745
    int cisloPortu = 46745;//46745

    char adresarServera[1024];//Dropbox/FRI/5.\ semester/OS/FoBoSK/Semestralna\ praca/AdresarServera
    memset(&adresarServera, 0, sizeof(adresarServera));
    strcpy(adresarServera,"Dropbox/OSsem");
    //strcpy(adresarServera,argv[3]);

    /*Zakladny vypis*/
    printf("[SERVER]: Server bol spusteny.\n");
    printf("[SERVER]: Dohodnute cislo portu: %d\n",cisloPortu);
    printf("[SERVER]: Dohodnuty domovsky adresar: %s\n", adresarServera);
//-------------------------------------------------------------------------------------------
    /*Vytvor socket*/
    //AF_INET ipv4 domena
    //SCOK_STREAM spolahlive prudove bajtove spojenie, zarucuje poradie sprav, full dupex
    sock = socket(AF_INET, SOCK_STREAM, 0);
    if (sock < 0){
        perror("[SERVER]: Chyba pri vytvarani socketu.\n");
        exit(1);
    } else {
        printf("[SERVER]: Socket bol vytvoreny.\n");
    }

    memset(&adresaServera, 0, sizeof(adresaServera));
    adresaServera.sin_family = AF_INET;
    adresaServera.sin_addr.s_addr = htonl(INADDR_ANY);
    adresaServera.sin_port = htons(cisloPortu);

    /*Zavolaj bind*/
    //previazanie socketu s adresou servera
    if (bind(sock, (struct sockaddr *) &adresaServera, sizeof(adresaServera))){ //ak je 0
        perror("[SERVER]: Chyba bindu.\n");
        exit(1);
    } else {
        printf("[SERVER]: Blind uspesne previazal socket s adresou servera.\n");
    }

    /*Pocuvaj*/
    listen(sock, 5); //max 5 pripojeni
    printf("[SERVER]: Cakam na poziadavku...\n");

    /*Akceptuj*/
    while(1){
        dlzkaAdresy = sizeof(adresaKlienta);
        mySock = accept(sock, (struct sockaddr *) &adresaKlienta, &dlzkaAdresy);
        if(mySock == -1){
            perror("[SERVER]: Chyba acceptu");
        } else {
            memset(buff, 0, sizeof(buff));

            if((rval = recv(mySock, buff, sizeof(buff), 0)) < 0){
                perror("[SERVER]: Nepodarilo sa nacitat spravu.\n");
            } else {
                printf("[SERVER]: Dostal som spravu. rval = (%d).\n", rval);

                //odoslanie spravy na rozparsovanie a osetrenie
                char first[4096];
                memset(first, 0, sizeof(first));
                strcpy(first,"./skript.sh ");
                strncat(first, adresarServera, sizeof(adresarServera));
                strncat(first, buff, sizeof(buff));
                printf("%s", first);
                system(first);

                if(rval == 0){
                    printf("[SERVER]: Koniec spojenia s klientom.\n");
                }
                //printf("[SERVER] Sprava:\n%s\n", buff);
            }
            close(mySock);
        }
    }

    return 0;
}




