#!/bin/bash


function vypisMeno(){
	printf "\n"
	printf "%s\n\n" "Lukas Machut 5ZI038"
}

# funkcia vypise zadanie a cislo semestralnej prace
function vypisZadanie(){
	printf "%s\n" "Zadanie semestralnej prace cislo 8."
    printf "%s\n" "Jednoduchy web server podporujuci podmnozinu protokolu HTTP/1.0"
	printf "\n"
}

# funkcia vypise cele zadanie semestralnej prace
function zobrazenieCelehoZadania(){
    echo "--------------------======PODROBNE ZADANIE SEMESTRALNEJ PRACE======--------------------"
    echo "Server musí implementovať minimálne metódu GET. Požiadavky môžu prichádzať z rôznych WEB klientov, server preto musí podporovať obsluhu viacerých klientov súčasne.

GET <specifikacia_suboru> HTTP/1.0\n\n

Ak je špecifikácia súboru zadaný iba znak lomky, potom server odošle súbor index.html, ak taký
 existuje v koreňovom adresári servera.
 
Špecifikácia súboru má tvar:

/<adresar>/<adresar>/…/<subor>

Pri spustení servera sa na príkazovom riadku špecifikuje port, na ktorom bude server prijímať požiadavky, ako aj adresár slúžiaci ako koreňový adresár serveru. Server nesmie umožniť prístup mimo podstromu, koreňového adresára (napr. Pomocou cesty obsahujúcej /../).

Funkčnosť servera bude overená pomocou webového prehliadača.

Implementácia servera bude pozostávať z dvoch častí:

1) Implementácia programu, ktorý bude funkčnosťou ekvivalentný programu netcat  (do miery vyžadovanej pre implementáciu servera) v jazyku C s použitím socketov.

2) Implementácia samotného servera s využitím programu z bodu 1)  Táto časť bude implementovaná v Bash-i a bude zabezpečovať  spustenie servera, cyklickú obsluhu prichádzajúcich požiadaviek (parsovanie, ošetrenie prípadných chýb, nájdenie požadovaného,
 dokumentu a jeho odoslanie klientov) a korektné ukončenie servera."
    printf "%s\n" "Ak chcete ukoncit vypis stlacte enter."
    read X
}

# zobrazenie zdrojovych kodov v c
function zobrazenieKoduServera(){
	echo "--------------------======Zdrojovy kod servera======--------------------"
	    cat Server.c
        printf "%s\n" "Ak chcete ukoncit vypis stlacte enter."
        read X
        echo "-----------------=====================---------------"
        echo "Koniec zdrojoveho kodu pre server"
        echo "-----------------=====================---------------"
}

# funkcia pre zobrazenie dokumentacie
function dokumentacia(){
	echo "--------------------======Dokumentacia======--------------------" 
	    cat dokumentacia.txt
	    printf "%s\n" "Ak chcete ukoncit vypis stlacte enter."
	    read X	
}

# funkcia na prelozenie c.programov
function preloz(){
    echo "Prekladam .c programy"
    make
}

echo "--------------------======SEMESTRALNA PRACA======--------------------"

vypisMeno
vypisZadanie

while true; do
printf "%s\n" "Zadajte volbu:"
printf "%s\n" "Zobrazenie celeho zadania -------------> 1"
printf "%s\n" "Zobrazenie zdrojoveho kodu servera ----> 2"
printf "%s\n" "Prelozenie .c programov ---------------> 3"
printf "%s\n" "Zobrazenie dokumentacie ---------------> 4"
printf "%s\n" "Spustenie servera ---------------------> 5"
printf "%s\n" "Koniec programu -----------------------> 6"
read ACTION

if [ "$ACTION" = "1" ]; then
    zobrazenieCelehoZadania
fi

if [ "$ACTION" = "2" ]; then
    zobrazenieKoduServera
fi

if [ "$ACTION" = "3" ]; then
    preloz
fi

if [ "$ACTION" = "4" ]; then
    dokumentacia
fi

if [ "$ACTION" = "5" ]; then
    echo "Spustanie servera:"
    echo "Zadajte port pre server [doporucene 46745]:"
    #read PORT
    echo "Zadajte adresar servera:"
    #read ADRESAR

    ./Server echo "$PORT" "$ADRESAR"
fi

if [ "$ACTION" = "6" ]; then
    break
fi
done


echo "--------------------======KONIEC SEMESTRALNEJ PRACE======--------------------"
