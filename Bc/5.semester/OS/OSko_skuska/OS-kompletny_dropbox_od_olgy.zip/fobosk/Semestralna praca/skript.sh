#!/bin/bash
function poziadavka {
    echo '[BASH]: Skladam poziadavku'
}

echo '[BASH]: Poziadavka na server'
echo $1  #GET
echo '[KLIENT]: Poziadavka'
#premenna ktora obsahuje poziadavku na subor
echo $2
echo '[BASH]: Adresar servera'
echo $3

#osetrenie ci sa nasiahlo mimo adreser servera
#parsovanie adresara a suboru
SUBOR=${PAR2##*/}
echo $SUBOR
ADRESARSERVERA=''
ADRESAR='/home/fobosk/Dropbox/FRI/5. semester/OS/FoBoSK/Semestralna praca' #ten potom dodame ako parameter


if [ "$ADRESARSERVER" == "$ADRESAR" ];
then
    echo '[BASH]: Adresare sa zhoduju'
    poziadavka
else 
    echo '[BASH]: Adresare sa nezhoduju'
fi

  
