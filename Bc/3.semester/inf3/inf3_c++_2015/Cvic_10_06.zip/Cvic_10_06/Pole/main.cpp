#include "Klient.h"
#include "CompositeLogger.h"

//ILogger *Log = new StreamLogger("c:\\temp\\pole.log");
ILogger *Log = new CompositeLogger();

int main()
{
	try
	{
		Log->log(INFO, "Start programu ...");
		Klient k;
		Log->log(INFO, "KONIEC PROGRAMU");
	}
	catch (...)
	{
		cout << "NEZNAMA CHYBA!!!" << endl;
	}
	return 0;
}