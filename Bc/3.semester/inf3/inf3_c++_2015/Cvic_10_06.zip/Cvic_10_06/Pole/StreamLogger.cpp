#include <ctime>
#include <iostream>

#include "StreamLogger.h"

void StreamLogger::writelog(const char * level, const char * text)
{
	time_t cas(time(nullptr));
	char *scas = ctime(&cas);
	scas[strlen(scas) - 1] = '\0';
	if (aFLog)
		*aFLog << level << " [" << scas << "]: " << text << endl;
	else
		cout << level << " [" << scas << "]: " << text << endl;
}

StreamLogger::StreamLogger(const char * menosuboru)
	:aFLog(menosuboru && *menosuboru ?
		new ofstream(menosuboru, ios_base::app | ios_base::out) : nullptr)
{
}

StreamLogger::~StreamLogger()
{
	delete aFLog;
}

void StreamLogger::log(eLogLevel level, const char * text)
{
	switch (level)
	{
	case INFO:
		writelog("INFO   ", text);
		break;
	case WARNING:
		writelog("WARNING", text);
		break;
	case ERROR:
		writelog("* ERROR", text);
		break;
#ifdef _DEBUG
	case DEBUG:
		writelog("DEBUG  ", text);
		break;
#endif
	}
}
