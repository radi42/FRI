#include "Klient.h"
#include "ILogger.h"

Klient::Klient()
	: aPole(new Pole<double>(-4, 10, 1.1)),
	aDolnyIndex(-100),
	aHornyIndex(200)
{
	Log->log(DEBUG, "Start konstruktora Klient");
	bool ok(true);
	do {
		try
		{
			Log->log(DEBUG, "Nastavenie prvku s indexom -4 na hodnotu 10.2");
			(*aPole)[-4] = 10.2;
			Log->log(DEBUG, "Nastavenie prvku s najvyssim indexom na hodnotu prvku s najnizsim indexom");
			(*aPole)[aHornyIndex] = (*aPole)[aDolnyIndex];
			Log->log(DEBUG, "Vypis prvkov pola");
			aPole->vypis();
			ok = false;
		}
		catch (VynimkaDolnyIndex &ex)
		{
			aDolnyIndex = ex.index();
			Log->log(ERROR, ex.oznam().c_str());
		}
		catch (VynimkaHornyIndex &ex)
		{
			aHornyIndex = ex.index();
			Log->log(ERROR, ex.oznam().c_str());
		}
		catch (VynimkaIndex &ex)
		{
			Log->log(ERROR, ex.oznam().c_str());
		}
	} while (ok);
	Log->log(DEBUG, "Koniec konstruktora Klient");
}


Klient::~Klient()
{
	Log->log(DEBUG, "Dealokacia pola");
	delete aPole;
}
