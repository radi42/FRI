#pragma once
#include <string>

using namespace std;

class VynimkaIndex
{
private:
	string aOznam;
	int aIndex;
public:

	VynimkaIndex(const char *oznam, int index)
		: aOznam(oznam), aIndex(index)
	{
	}
	virtual ~VynimkaIndex() {}

	string oznam() { return aOznam; }
	int index() { return aIndex; }
};

class VynimkaDolnyIndex : public VynimkaIndex
{
public:
	VynimkaDolnyIndex(int index)
		:VynimkaIndex("Dolny index mimo hranicu!", index)
	{}
};

class VynimkaHornyIndex : public VynimkaIndex
{
public:
	VynimkaHornyIndex(int index)
		:VynimkaIndex("Horny index mimo hranicu!", index)
	{}
};

