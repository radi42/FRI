#include "CompositeLogger.h"

CompositeLogger::CompositeLogger()
	: sLogger(new StreamLogger("c:\\temp\\pole.log")),
	cLogger(new StreamLogger(""))
{
}

CompositeLogger::~CompositeLogger()
{
	delete sLogger;
	delete cLogger;
}

void CompositeLogger::log(eLogLevel level, const char * text)
{
	if (cLogger)
		cLogger->log(level, text);
	if (sLogger)
		sLogger->log(level, text);
}
