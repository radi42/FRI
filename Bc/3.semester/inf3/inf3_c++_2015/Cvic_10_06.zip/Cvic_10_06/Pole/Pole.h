#pragma once
#include <iostream>
#include "VynimkaIndex.h"

template <class T>
class Pole
{
private:
	int aDolnyIndex;
	unsigned aRozsah;
	T *aData;
	void copy(const Pole &zdroj);
	void zmaz();
public:
	Pole(int dolnyindex, unsigned rozsah, T initval);
	Pole(const Pole &zdroj);
	Pole<T> &operator =(const Pole &zdroj);
	~Pole();
	T &operator [](int index);

	void vypis();
};

template<class T>
inline void Pole<T>::copy(const Pole & zdroj)
{
	aDolnyIndex = zdroj.aDolnyIndex;
	aRozsah = zdroj.aRozsah;
	aData = nullptr;
	if (aRozsah > 0)
	{
		aData = new T[aRozsah];
		for (unsigned i = 0; i < aRozsah; i++)
			aData[i] = zdroj.aData[i];
	}
}

template<class T>
inline void Pole<T>::zmaz()
{
	delete[] aData;
	aRozsah = 0;
	aData = nullptr;
}

template<class T>
Pole<T>::Pole(int dolnyindex, unsigned rozsah, T initval)
	: aDolnyIndex(dolnyindex),
	aRozsah(rozsah),
	aData(rozsah > 0 ? new T[rozsah] : nullptr)
{
	for (unsigned i = 0; i < aRozsah; i++)
		aData[i] = initval;
}

template<class T>
inline Pole<T>::Pole(const Pole & zdroj)
{
	copy(zdroj);
}

template<class T>
inline Pole<T>& Pole<T>::operator=(const Pole & zdroj)
{
	if (this != &zdroj)
	{
		zmaz();
		copy(zdroj);
	}
	return *this;
}

template<class T>
Pole<T>::~Pole()
{
	zmaz();
}

template<class T>
inline T & Pole<T>::operator[](int index)
{
	if (aData)
	{
		if (index < aDolnyIndex)
			throw VynimkaDolnyIndex(aDolnyIndex);
		int hornyindex = aDolnyIndex + aRozsah - 1;
		if (index > hornyindex)
			throw VynimkaHornyIndex(hornyindex);
		return aData[index - aDolnyIndex];
	}
	throw VynimkaIndex("Prazdne pole", -1);
}

template<class T>
void Pole<T>::vypis()
{
	for (unsigned i = 0;i < aRozsah;i++)
		cout << aData[i] << endl;
	cout << endl;
}
