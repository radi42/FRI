#pragma once

namespace cvstup
{
	unsigned citaj();
}

namespace cppvstup
{
	unsigned citaj();
}