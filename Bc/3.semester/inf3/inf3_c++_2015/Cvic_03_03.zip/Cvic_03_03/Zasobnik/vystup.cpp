#include <iostream>
#include "vystup.h"

using namespace std;

#ifdef _DEBUG
void vypis(unsigned cislo)
{
	cout << cislo << endl;
}
#else
void vypis(unsigned cislo)
{
}
#endif