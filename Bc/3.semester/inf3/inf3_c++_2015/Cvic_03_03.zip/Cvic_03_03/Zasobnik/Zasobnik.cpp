#include <cstdlib>
#include "Zasobnik.h"
#include "vstup.h"
#include "vystup.h"

using namespace cppvstup;

bool push(Zasobnik &zasobnik, unsigned cislo)
{
	if (cislo > NEPLATNA_HODNOTA)
	{
		zasobnik.sp = new Zasobnik::Uzol(cislo, zasobnik.sp);
		if (zasobnik.sp != NULL)
		{
			zasobnik.pocet++;
			return true;
		}
	}
	return false;
}

unsigned pop(Zasobnik &zasobnik)
{
	if (zasobnik.pocet > 0)
	{
		unsigned pomcislo = zasobnik.sp->data;
		Zasobnik::Uzol *pomuzol = zasobnik.sp->dalsi;
		delete zasobnik.sp;
		zasobnik.sp = pomuzol;
		zasobnik.pocet--;
		return pomcislo;
	}
	return NEPLATNA_HODNOTA;
}

unsigned peek(Zasobnik &zasobnik)
{
	if (zasobnik.pocet > 0)
		return zasobnik.sp->data;
	return NEPLATNA_HODNOTA;
}

void nacitaj(Zasobnik &zasobnik)
{
	unsigned cislo = citaj();
	while (cislo != NEPLATNA_HODNOTA)
	{
		push(zasobnik, cislo);
		cislo = citaj();
	}
}

void init(Zasobnik &zasobnik)
{
	zasobnik.sp = NULL;
	zasobnik.pocet = 0;
}

void zrus(Zasobnik &zasobnik)
{
	while (zasobnik.pocet)
		vypis(pop(zasobnik));
}

void insert(Zasobnik &cielzasobnik, Zasobnik::Uzol *uzol)
{
	if (uzol->dalsi != NULL)
		insert(cielzasobnik, uzol->dalsi);
	push(cielzasobnik, uzol->data);
}

void kopiruj(Zasobnik &cielzasobnik, Zasobnik &zdrojzasobnik)
{
	if (cielzasobnik.pocet > 0)
		zrus(cielzasobnik);
	if (zdrojzasobnik.pocet > 0)
	{
		insert(cielzasobnik, zdrojzasobnik.sp);
	}
}

