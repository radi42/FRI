#pragma once

void vypis(unsigned cislo);