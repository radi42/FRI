#pragma once

const unsigned NEPLATNA_HODNOTA = 0;

struct Zasobnik
{
	struct Uzol
	{
		unsigned int data;
		Uzol *dalsi;
		Zasobnik::Uzol(unsigned cislo, Uzol *uzol)
		{
			data = cislo;
			dalsi = uzol;
		}
	} *sp;
	unsigned pocet;
};

bool push(Zasobnik &zasobnik, unsigned cislo);
unsigned pop(Zasobnik &zasobnik);
unsigned peek(Zasobnik &zasobnik);

void nacitaj(Zasobnik &zasobnik);
void kopiruj(Zasobnik &cielzasobnik, Zasobnik &zdrojzasobnik);

void init(Zasobnik &zasobnik);
void zrus(Zasobnik &zasobnik);