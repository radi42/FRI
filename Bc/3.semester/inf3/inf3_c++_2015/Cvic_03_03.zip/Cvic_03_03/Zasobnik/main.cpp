#define STARTTESTY

#include <iostream>

#ifdef STARTTESTY
#include "testy.h"
#endif

int main()
{
	bool ok = true;
#ifdef STARTTESTY
	ok = runtesty();
#endif
	if (ok == true)
		;
	else
	{
		std::cout << "CHYBA! NEPRESLI TESTY!" << std::endl;
		return 1;
	}
	return 0;
}