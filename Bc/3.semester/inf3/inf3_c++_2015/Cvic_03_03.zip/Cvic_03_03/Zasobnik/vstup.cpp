#include <cstdio>
#include <iostream>
#include "vstup.h"

namespace cvstup
{
	unsigned citaj()
	{
		unsigned cislo;
		scanf("%u", &cislo);
		return cislo;
	}
}

namespace cppvstup
{
	unsigned citaj()
	{
		unsigned cislo;
		std::cin >> cislo;
		return cislo;
	}
}