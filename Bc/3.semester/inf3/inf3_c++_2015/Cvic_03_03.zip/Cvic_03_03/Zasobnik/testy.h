#pragma once

bool runtesty();