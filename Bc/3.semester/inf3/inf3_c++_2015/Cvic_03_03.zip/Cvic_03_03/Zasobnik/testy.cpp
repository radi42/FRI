#include "testy.h"
#include "Zasobnik.h"

bool runtesty()
{
	Zasobnik z1;

	init(z1);
	unsigned cislo = pop(z1);
	if (cislo != NEPLATNA_HODNOTA)
		return false;

	//push(z1, 1);
	//push(z1, 2);
	//push(z1, 3);

	//cislo = pop(z1);
	//if (cislo != 3)
	//	return false;

	nacitaj(z1);

	Zasobnik z2;
	init(z2);

	kopiruj(z2, z1);

	zrus(z2);
	zrus(z1);
	cislo = pop(z1);
	if (cislo != NEPLATNA_HODNOTA)
		return false;

	return true;
}