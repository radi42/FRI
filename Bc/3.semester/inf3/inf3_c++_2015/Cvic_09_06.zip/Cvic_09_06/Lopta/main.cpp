#include "HraLopta.h"

int main(int argc, char *argv[])
{
	HraLopta().start();
	return 0;
}

