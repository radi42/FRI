#pragma once
#include "IEngine.h"
#include "ISystem.h"
#include "IObjekt.h"

class Engine : public IEngine
{
private:
	ISystem *aHraciaPlocha;
	IObjekt *aObjekt;
	int aSkore;

	void zobrazSkore();
	void aktualizuj();
	void spracujvstup(int x, int y);
public:
	Engine(IObjekt *objekt, ISystem *plocha);
	~Engine();

	// Inherited via IEngine
	virtual void start() override;
};

