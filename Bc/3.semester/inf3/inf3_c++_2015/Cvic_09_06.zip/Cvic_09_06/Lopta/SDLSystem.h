#pragma once
#include "ISystem.h"

struct SDL_Surface;

class SDLSystem : public ISystem
{
private:
	static int aCitac;
	SDL_Surface *aPlocha;
	SDLSystem(SDL_Surface *plocha)
		: aPlocha(plocha)
	{
		aCitac++;
	}
public:
	SDLSystem(int sirka, int vyska);
	~SDLSystem();

	// Inherited via ISystem
	virtual int sirka() override;
	virtual int vyska() override;
	virtual ISystem * citajBMP(const char * menosuboru) override;
	virtual void zobraz(ISystem & objekt, int x, int y) override;
	virtual void uvolni(ISystem * objekt) override;
	virtual bool vstup(int & x, int & y) override;
	virtual void zobrazdata(const char * data) override;
	virtual int dajCas() override;

	// Inherited via ISystem
	virtual void * plocha() override;

	// Inherited via ISystem
	virtual void zmaz() override;
	virtual void update() override;
};

