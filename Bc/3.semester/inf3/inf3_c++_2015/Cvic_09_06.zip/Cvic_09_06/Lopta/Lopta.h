#pragma once
#include "PohyblivyObjekt.h"
#include "ISystem.h"

class Lopta : public PohyblivyObjekt
{
private:
	ISystem *aHraciaPlocha;
	ISystem *aLopta;
public:
	Lopta(ISystem *hraciaPlocha);
	~Lopta();

	// Inherited via PohyblivyObjekt
	virtual void zobrazsa() override;
	virtual int dajBody() override;
};

