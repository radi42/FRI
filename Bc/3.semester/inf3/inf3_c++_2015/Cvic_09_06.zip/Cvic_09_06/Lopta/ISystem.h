#pragma once
class ISystem
{
public:
	virtual int sirka() = 0;
	virtual int vyska() = 0;
	virtual ISystem *citajBMP(const char *menosuboru) = 0;
	virtual void zobraz(ISystem &objekt, int x, int y) = 0;
	virtual void uvolni(ISystem *objekt) = 0;
	virtual bool vstup(int &x, int &y) = 0;
	virtual void zobrazdata(const char *data) = 0;
	virtual int dajCas() = 0;
	virtual void *plocha() = 0;
	virtual void zmaz() = 0;
	virtual void update() = 0; 

	virtual ~ISystem() {	};
};

