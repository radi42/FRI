#include <cstdlib>
#include "PohyblivyObjekt.h"

const int DELTA = 6;
const int INTERVAL = 5;

int PohyblivyObjekt::generuj(int minval, int maxval)
{
	if (minval == maxval)
		maxval++;
	if (maxval < minval)
	{
		int c = minval;
		minval = maxval;
		maxval = c;
	}
	return rand() % (maxval - minval) + minval;
}

PohyblivyObjekt::PohyblivyObjekt(int sirkaPlocha, int vyskaPlocha, int sirka, int vyska)
	: aSirkaPlocha(sirkaPlocha), aVyskaPlocha(vyskaPlocha), aSirka(sirka), aVyska(vyska),
	aCas(0), aInterval(0), aDeltaX(0), aDeltaY(0), aX(0), aY(0)
{
}

PohyblivyObjekt::~PohyblivyObjekt()
{
}

bool PohyblivyObjekt::aktualizujsa(int cas)
{
	if ((cas - aCas) >= aInterval)
	{
		aX += aDeltaX;
		if (aX<0 || (aX + aSirka)>aSirkaPlocha)
		{
			aDeltaX = -aDeltaX;
			aX += aDeltaX;
		}
		aY += aDeltaY;
		if (aY<0 || (aY + aVyska)>aVyskaPlocha)
		{
			aDeltaY = -aDeltaY;
			aY += aDeltaY;
		}
		aCas = cas;
		return true;
	}
	return false;
}

int PohyblivyObjekt::dajBody()
{
	return 0;
}

bool PohyblivyObjekt::zasah(int x, int y)
{
	bool ret = x >= aX && x <= (aX + aSirka) && y > aY && y < (aY + aVyska);
	if (ret)
		reset();
	return ret;
}

void PohyblivyObjekt::reset()
{
	aX = generuj(0, aSirkaPlocha - aSirka);
	aY = generuj(0, aVyskaPlocha - aVyska);
	aDeltaX = generuj(-DELTA / 2, DELTA / 2);
	aDeltaY = generuj(-DELTA / 2, DELTA / 2);
	aInterval = generuj(INTERVAL, 4 * INTERVAL);
}
