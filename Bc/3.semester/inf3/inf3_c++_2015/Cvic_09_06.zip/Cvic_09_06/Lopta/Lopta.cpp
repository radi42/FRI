#include "Lopta.h"

Lopta::Lopta(ISystem * hraciaPlocha)
	: PohyblivyObjekt(hraciaPlocha ? hraciaPlocha->sirka() : 0, hraciaPlocha ? hraciaPlocha->vyska() : 0),
	aHraciaPlocha(hraciaPlocha)
{
	if (aHraciaPlocha)
		aLopta = aHraciaPlocha->citajBMP("ball.bmp");
	if (aLopta)
	{
		aSirka = aLopta->sirka();
		aVyska = aLopta->vyska();
		reset();
	}
}

Lopta::~Lopta()
{
	if (aHraciaPlocha)
		aHraciaPlocha->uvolni(aLopta);
}

void Lopta::zobrazsa()
{
	if (aHraciaPlocha)
		aHraciaPlocha->zobraz(*aLopta, aX, aY);
}

int Lopta::dajBody()
{
	return 1;
}
