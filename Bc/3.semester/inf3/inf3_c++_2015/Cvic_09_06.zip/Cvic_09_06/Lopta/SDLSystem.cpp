#include "SDLSystem.h"
#include "SDL.h"

int SDLSystem::aCitac(0);

SDLSystem::SDLSystem(int sirka, int vyska)
{
	if (!aCitac)
		SDL_Init(SDL_INIT_EVERYTHING);
	aCitac++;
	aPlocha = SDL_SetVideoMode(sirka, vyska, 32, SDL_SWSURFACE);
}

SDLSystem::~SDLSystem()
{
	aCitac--;
	if (!aCitac)
		SDL_Quit();
	SDL_FreeSurface(aPlocha);
}

int SDLSystem::sirka()
{
	return aPlocha ? aPlocha->w : 0;
}

int SDLSystem::vyska()
{
	return aPlocha ? aPlocha->h : 0;
}

ISystem * SDLSystem::citajBMP(const char * menosuboru)
{
	SDL_Surface *obrazok = SDL_LoadBMP(menosuboru);
	return obrazok ? new SDLSystem(obrazok) : NULL;
}

void SDLSystem::zobraz(ISystem & objekt, int x, int y)
{
	SDL_Surface *obrazok = (SDL_Surface *)objekt.plocha();

	SDL_Rect ciel;
	ciel.w = objekt.sirka();
	ciel.h = objekt.vyska();
	ciel.x = x;
	ciel.y = y;
	SDL_BlitSurface(obrazok, NULL, aPlocha, &ciel);
}

void SDLSystem::uvolni(ISystem * objekt)
{
	SDL_FreeSurface((SDL_Surface *)objekt->plocha());
}

bool SDLSystem::vstup(int & x, int & y)
{
	x = -1;
	SDL_Event event;
	while (SDL_PollEvent(&event))
	{
		switch (event.type)
		{
		case SDL_KEYDOWN:
			if (event.key.keysym.sym == SDLK_ESCAPE)
				return false;
			break;
		case SDL_MOUSEBUTTONDOWN:
			if (event.button.button == SDL_BUTTON_LEFT)
			{
				x = event.button.x;
				y = event.button.y;
			}
			break;
		case SDL_QUIT:
			return false;
		}
	}
	return true;
}

void SDLSystem::zobrazdata(const char * data)
{
	SDL_WM_SetCaption(data, NULL);
}

int SDLSystem::dajCas()
{
	return SDL_GetTicks();
}

void * SDLSystem::plocha()
{
	return aPlocha;
}

void SDLSystem::zmaz()
{
	SDL_FillRect(aPlocha, NULL, SDL_MapRGB(aPlocha->format, 0, 0, 255));
}

void SDLSystem::update()
{
	SDL_UpdateRect(aPlocha, 0, 0, 0, 0);
}
