#include <iostream>
#include "Vystup.h"

using namespace std;

void VerticalVystup::zobraz(string data)
{
	cout << data << endl;
}

void HorizontalVystup::zobraz(string data)
{
	cout << data;
}
