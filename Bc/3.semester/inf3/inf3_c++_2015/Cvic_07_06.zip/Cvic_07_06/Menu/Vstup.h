#pragma once
#include "IVstup.h"
class Vstup : public IVstup
{
public:
	virtual char getVstup() override;
};

