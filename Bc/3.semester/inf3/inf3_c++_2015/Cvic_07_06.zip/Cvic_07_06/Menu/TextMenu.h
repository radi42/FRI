#pragma once
#include "IReceiver.h"
#include "IVystup.h"
#include "ICommand.h"
#include "IVstup.h"

class TextMenu
{
private:
	unsigned aPocet;
	IVystup &aVystup;
	ICommand **aPrikazy;
	IVstup &aVstup;

	unsigned aAktualnyPocet;
	bool addPrikaz(ICommand *prikaz);
	void skopirujPrikazy(const TextMenu &zdroj);
	void zobraz();
	bool dajVstup();
public:
	TextMenu(unsigned pocet, IVystup &vystup, IVstup &vstup);
	TextMenu(const TextMenu &zdroj);
	TextMenu &operator =(const TextMenu &zdroj);
	~TextMenu();

	void start();
	bool addPrikaz(const char *text, int id = ID_NONE, char hotkey = '\0', IReceiver *receiver = NULL);
	bool addKoniecPrikaz(IReceiver *receiver = NULL);
	bool addHSeparator();
	bool addVSeparator();
};

