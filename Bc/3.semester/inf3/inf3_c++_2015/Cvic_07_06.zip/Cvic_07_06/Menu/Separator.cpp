#include "Separator.h"

ICommand * VSeparator::clone()
{
	return new VSeparator(*this);
}

ICommand * HSeparator::clone()
{
	return new HSeparator(*this);
}
