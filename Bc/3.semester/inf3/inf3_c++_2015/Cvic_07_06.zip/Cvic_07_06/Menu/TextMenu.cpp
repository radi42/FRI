#include "TextMenu.h"
#include "TextCommand.h"
#include "KoniecCommand.h"
#include "Separator.h"

TextMenu::TextMenu(unsigned pocet, IVystup & vystup, IVstup & vstup)
	: aPocet(pocet), aVystup(vystup), aVstup(vstup),
	aPrikazy(aPocet > 0 ? new ICommand *[aPocet] : NULL),
	aAktualnyPocet(0)
{
	for (int i = 0;i < aPocet;i++)
		aPrikazy[i] = NULL;
}

TextMenu::TextMenu(const TextMenu & zdroj)
	: aPocet(zdroj.aPocet), aVystup(zdroj.aVystup), aVstup(zdroj.aVstup),
	aPrikazy(aPocet > 0 ? new ICommand *[aPocet] : NULL),
	aAktualnyPocet(zdroj.aAktualnyPocet)
{
	skopirujPrikazy(zdroj);
}

TextMenu & TextMenu::operator=(const TextMenu & zdroj)
{
	if (this != &zdroj)
	{
		TextMenu::~TextMenu();
		aPocet = zdroj.aPocet;
		aVystup = zdroj.aVystup;
		aVstup = zdroj.aVstup;
		aPrikazy = aPocet > 0 ? new ICommand *[aPocet] : NULL;
		aAktualnyPocet = zdroj.aAktualnyPocet;
		skopirujPrikazy(zdroj);
	}
	return *this;
}

TextMenu::~TextMenu()
{
	for (int i = 0;i < aAktualnyPocet;i++)
		delete aPrikazy[i];
	delete[] aPrikazy;
}

bool TextMenu::addPrikaz(ICommand * prikaz)
{
	if (aPrikazy && aAktualnyPocet < aPocet)
	{
		aPrikazy[aAktualnyPocet++] = prikaz;
		return true;
	}
	return false;
}

void TextMenu::skopirujPrikazy(const TextMenu & zdroj)
{
	for (int i = 0;i < aPocet;i++)
	{
		if (zdroj.aPrikazy[i])
			aPrikazy[i] = zdroj.aPrikazy[i]->clone();
		else
			aPrikazy[i] = NULL;
	}
}

void TextMenu::zobraz()
{
	for (int i = 0;i < aAktualnyPocet;i++)
		aPrikazy[i]->zobraz();
}

bool TextMenu::dajVstup()
{
	char vstup = aVstup.getVstup();
	for (int i = 0;i < aAktualnyPocet;i++)
	{
		if (aPrikazy[i]->jeHotKey(vstup))
			return aPrikazy[i]->execute();
	}
	return true;
}


void TextMenu::start()
{
	do {
		zobraz();
	} while (dajVstup());
}

bool TextMenu::addPrikaz(const char * text, int id, char hotkey, IReceiver * receiver)
{
	if (text && *text)
		return addPrikaz(new TextCommand(text, aVystup, id, hotkey, receiver));
	return false;
}

bool TextMenu::addKoniecPrikaz(IReceiver * receiver)
{
	return addPrikaz(new KoniecCommand(aVystup, receiver));
}

bool TextMenu::addHSeparator()
{
	return addPrikaz(new HSeparator(aVystup));
}

bool TextMenu::addVSeparator()
{
	return addPrikaz(new VSeparator(aVystup));
}
