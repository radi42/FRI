#pragma once

void zrebovanie(int pocetzrebov);
