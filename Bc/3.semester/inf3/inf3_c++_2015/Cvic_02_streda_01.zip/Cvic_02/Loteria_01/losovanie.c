#include <stdlib.h>
#include <string.h>
#include <time.h>

#include "losovanie.h"
#include "data.h"

void vymen(int a, int b);

void zrebuj(int pocetmiest)
{
	srand((unsigned)time(NULL));
	int maxpocet = (pocetmiest<0 || pocetmiest>POCET_ZREBOV) ?
		POCET_ZREBOV : pocetmiest;
	for (int i = 0;i < maxpocet; i++)
	{
		int index = rand() % (POCET_ZREBOV - i) + i;
		vymen(index, i);
	}
}

void vymen(int a, int b)
{
	struct zreb c;
	c.cislo = zreby[a].cislo;
	strcpy(c.majitel, zreby[a].majitel);

	zreby[a].cislo = zreby[b].cislo;
	strcpy(zreby[a].majitel, zreby[b].majitel);

	zreby[b].cislo = c.cislo;
	strcpy(zreby[b].majitel, c.majitel);
}