#define START_TESTY

#ifdef START_TESTY
#include "testy.h"
#endif

#include <stdio.h>
#include "StavkovaKancelaria.h"

int main()
{
	int ok = 1;
#ifdef START_TESTY
	ok = testy();
#endif
	if (ok == 1)
		zrebovanie(10); // normalny start programu
	else
		printf("CHYBA PROGRAMU. NEPRESLI TESTY!!!\n");
	return 0;
}