#pragma once

void vypis(int pocetVylosovanych);
