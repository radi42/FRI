#include <stdio.h>

#include "vystup.h"
#include "data.h"

void vypis(int pocetVylosovanych)
{
	printf("VYSLEDOK LOSOVANIA\n---------------------\n\n");

	for (int i = 0;i < pocetVylosovanych && i < POCET_ZREBOV;i++)
		printf("%2d.miesto: %4d\t%s\n", i + 1, zreby[i].cislo, zreby[i].majitel);
}