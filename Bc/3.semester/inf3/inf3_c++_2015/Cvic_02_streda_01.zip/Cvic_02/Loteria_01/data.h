#pragma once

#define DLZKA_MENA 11
#define POCET_ZREBOV 10

#ifdef WIN32
	typedef int MINT;
#else
	typedef short MINT;
#endif

struct zreb
{
	MINT cislo;
	char majitel[DLZKA_MENA];
};

extern struct zreb zreby[POCET_ZREBOV];