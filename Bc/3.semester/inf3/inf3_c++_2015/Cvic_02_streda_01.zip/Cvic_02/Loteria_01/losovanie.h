#pragma once

void zrebuj(int pocetmiest);
