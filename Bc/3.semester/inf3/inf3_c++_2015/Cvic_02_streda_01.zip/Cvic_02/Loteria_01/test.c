#include <stdio.h>
#include "vstup.h"
#include "vystup.h"
#include "data.h"

int testy()
{
	pripravZreby();
	vypis(POCET_ZREBOV);
	int index;
	for (int j = 0;j < 11;j++)
	{
		for (int i = 0;i < POCET_ZREBOV; i++)
		{
			index = j % (POCET_ZREBOV - i) + i;
			printf("j=%d: %d\n", j, index);
		}
	}
	return 1;
}