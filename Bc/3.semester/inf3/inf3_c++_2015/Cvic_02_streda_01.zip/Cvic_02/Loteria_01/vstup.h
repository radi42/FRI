#pragma once

void pripravZreby();

