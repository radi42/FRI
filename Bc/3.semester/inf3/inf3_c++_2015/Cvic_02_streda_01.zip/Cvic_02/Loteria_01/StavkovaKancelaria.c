#include "StavkovaKancelaria.h"
#include "vstup.h"
#include "vystup.h"
#include "losovanie.h"

void zrebovanie(int pocetzrebov)
{
	pripravZreby();
	zrebuj(pocetzrebov);
	vypis(pocetzrebov);
}