#include <string.h>
#include "vstup.h"
#include "data.h"

void pripravZreby()
{
	char pom[2] = " ";

	for (int i = 0;i < POCET_ZREBOV;i++)
	{
		pom[0] = 'A' + i;
		zreby[i].cislo = i + 1;
		strcpy(zreby[i].majitel, pom);
	}
}