#include <iostream>

#include "vystup.h"
#include "data.h"

//using namespace std;

void vypis(int pocetVylosovanych)
{
	std::cout <<
		"VYSLEDOK LOSOVANIA" <<
		std::endl <<
		"---------------------" << std::endl << std::endl;
	for (int i = 0;i < pocetVylosovanych && i < POCET_ZREBOV;i++)
		std::cout <<  i + 1 << ".miesto: " << "\t" <<
		zreby[i].cislo << "\t" <<
		zreby[i].majitel << std::endl;
}