#pragma once

const int DLZKA_MENA = 11;
const int POCET_ZREBOV = 10;

#ifdef WIN32
typedef int MINT;
#else
typedef short MINT;
#endif

struct zreb
{
	MINT cislo;
	char majitel[DLZKA_MENA];
};

extern zreb zreby[POCET_ZREBOV];