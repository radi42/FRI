#pragma once
#include "TextMenu.h"

class HMenu : public TextMenu
{
private:
	IVystup *aVystup;
public:
	HMenu(int startid, IVstup &vstup, IReceiver *receiver, unsigned pocetprikazov, ...);
	~HMenu();
};

