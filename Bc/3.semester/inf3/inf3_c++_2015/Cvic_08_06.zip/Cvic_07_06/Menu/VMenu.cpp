#include <cstdarg>

#include "VMenu.h"
#include "Vystup.h"

VMenu::VMenu(int startid, IVstup & vstup, IReceiver * receiver, unsigned pocetprikazov, ...)
	: TextMenu(pocetprikazov + 2, *(aVystup = new VerticalVystup), vstup)
{
	va_list argptr;
	va_start(argptr, pocetprikazov);

	unsigned i(0);
	while (i < pocetprikazov)
	{
		char * text = va_arg(argptr, char *);
		spracujAddPrikaz(text, startid + i, receiver);
		i++;
	}
	addVSeparator();
	addKoniecPrikaz(receiver);
	va_end(argptr);
}

VMenu::~VMenu()
{
	delete aVystup;
}
