#pragma once
#include "IVystup.h"

class VerticalVystup :	public IVystup
{
public:
	virtual void zobraz(string data) override;
};

class HorizontalVystup : public IVystup
{
public:
	virtual void zobraz(string data) override;
};

