#pragma once
#include <string>
#include "ICommand.h"
#include "IVystup.h"
#include "IReceiver.h"

using namespace std;
class TextCommand : public ICommand
{
private:
	int aId;
	string aText;
	char aHotKey;
	IVystup &aVystup;
	IReceiver *aReceiver;
public:
	TextCommand(const char *text, IVystup &vystup,
		int id = ID_NONE, char hotkey='\0', IReceiver *receiver = NULL);

	// Inherited via ICommand
	virtual bool execute() override;
	virtual void zobraz() override;
	virtual bool jeHotKey(char key) override;
	virtual ICommand * clone() override;
};

