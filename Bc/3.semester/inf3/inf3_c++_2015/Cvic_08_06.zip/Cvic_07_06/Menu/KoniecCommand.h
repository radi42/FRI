#pragma once
#include "TextCommand.h"
class KoniecCommand : public TextCommand
{
public:
	KoniecCommand(IVystup &vystup, IReceiver *receiver = NULL);
	virtual bool execute() override;
	virtual ICommand * clone() override;
};

