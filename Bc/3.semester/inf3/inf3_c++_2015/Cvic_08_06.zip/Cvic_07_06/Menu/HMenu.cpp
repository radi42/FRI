#include <cstdarg>

#include "HMenu.h"
#include "Vystup.h"

HMenu::HMenu(int startid, IVstup & vstup, IReceiver * receiver, unsigned pocetprikazov, ...)
	: TextMenu(pocetprikazov * 2 + 1, *(aVystup = new HorizontalVystup), vstup)
{
	va_list argptr;
	va_start(argptr, pocetprikazov);

	unsigned i(0);
	while (i < pocetprikazov)
	{
		char * text = va_arg(argptr, char *);
		string sprikaz(text);
		int pozicia = sprikaz.find('#');
		if (pozicia >= 0)
		{
			IReceiver * recs = va_arg(argptr, IReceiver *);
			spracujAddPrikaz(text, startid + i, recs, '#');
		}
		else
			spracujAddPrikaz(text, startid + i, receiver);
		addHSeparator();
		i++;
	}
	addKoniecPrikaz(receiver);
	va_end(argptr);
}

HMenu::~HMenu()
{
	delete aVystup;
}
