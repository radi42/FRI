#include <conio.h>
#include "Vstup.h"

char Vstup::getVstup()
{
	return _getch();
}
