#pragma once
#include "TextMenu.h"

class VMenu : public TextMenu
{
private:
	IVystup *aVystup;
public:
	VMenu(int startid, IVstup &vstup, IReceiver *receiver, unsigned pocetprikazov, ...);
	~VMenu();
};

