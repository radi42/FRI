#include "Aplikacia.h"

int main()
{
	Aplikacia::start();
	return 0;
}