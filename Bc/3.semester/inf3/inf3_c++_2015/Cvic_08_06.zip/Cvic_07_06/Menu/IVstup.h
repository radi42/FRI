#pragma once
class IVstup
{
public:
	virtual char getVstup() = 0;
};

