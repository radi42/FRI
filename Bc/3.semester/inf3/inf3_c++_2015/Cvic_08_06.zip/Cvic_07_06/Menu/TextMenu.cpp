#include "TextMenu.h"
#include "TextCommand.h"
#include "KoniecCommand.h"
#include "Separator.h"

TextMenu::TextMenu(unsigned pocet, IVystup & vystup, IVstup & vstup)
	: aPocet(pocet), aVystup(vystup), aVstup(vstup),
	aPrikazy(aPocet > 0 ? new ICommand *[aPocet] : NULL),
	aAktualnyPocet(0)
{
	for (unsigned i = 0;i < aPocet;i++)
		aPrikazy[i] = NULL;
}

TextMenu::TextMenu(const TextMenu & zdroj)
	: aPocet(zdroj.aPocet), aVystup(zdroj.aVystup), aVstup(zdroj.aVstup),
	aPrikazy(aPocet > 0 ? new ICommand *[aPocet] : NULL),
	aAktualnyPocet(zdroj.aAktualnyPocet)
{
	skopirujPrikazy(zdroj);
}

TextMenu & TextMenu::operator=(const TextMenu & zdroj)
{
	if (this != &zdroj)
	{
		TextMenu::~TextMenu();
		aPocet = zdroj.aPocet;
		aVystup = zdroj.aVystup;
		aVstup = zdroj.aVstup;
		aPrikazy = aPocet > 0 ? new ICommand *[aPocet] : NULL;
		aAktualnyPocet = zdroj.aAktualnyPocet;
		skopirujPrikazy(zdroj);
	}
	return *this;
}

TextMenu::~TextMenu()
{
	for (unsigned i = 0;i < aAktualnyPocet;i++)
		delete aPrikazy[i];
	delete[] aPrikazy;
}

bool TextMenu::addPrikaz(ICommand * prikaz)
{
	if (aPrikazy && aAktualnyPocet < aPocet)
	{
		aPrikazy[aAktualnyPocet++] = prikaz;
		return true;
	}
	return false;
}

void TextMenu::skopirujPrikazy(const TextMenu & zdroj)
{
	for (unsigned i = 0;i < aPocet;i++)
	{
		if (zdroj.aPrikazy[i])
			aPrikazy[i] = zdroj.aPrikazy[i]->clone();
		else
			aPrikazy[i] = NULL;
	}
}

void TextMenu::zobraz()
{
	for (unsigned i = 0;i < aAktualnyPocet;i++)
		aPrikazy[i]->zobraz();
	aVystup.zobraz(string("\n\n"));
}

bool TextMenu::dajVstup()
{
	char vstup = aVstup.getVstup();
	for (unsigned i = 0;i < aAktualnyPocet;i++)
	{
		if (aPrikazy[i]->jeHotKey(vstup))
			return aPrikazy[i]->execute();
	}
	return true;
}


void TextMenu::start()
{
	do {
		zobraz();
	} while (dajVstup());
}

bool TextMenu::addPrikaz(const char * text, int id, char hotkey, IReceiver * receiver)
{
	if (text && *text)
		return addPrikaz(new TextCommand(text, aVystup, id, hotkey, receiver));
	return false;
}

bool TextMenu::spracujAddPrikaz(const char * text, int id, IReceiver * receiver, char znak)
{
	if (text && *text)
	{
		string sprikaz(text);
		int pozicia = sprikaz.find(znak);
		if (pozicia >= 0)
		{
			sprikaz = sprikaz.substr(0, pozicia) +
				"[" +
				sprikaz.substr(pozicia + 1, 1) +
				"]" +
				sprikaz.substr(pozicia + 2, sprikaz.length() - pozicia - 2);
		}
		return addPrikaz(sprikaz.c_str(), id, text[pozicia + 1], receiver);
	}
	return false;
}

bool TextMenu::addKoniecPrikaz(IReceiver * receiver)
{
	return addPrikaz(new KoniecCommand(aVystup, receiver));
}

bool TextMenu::addHSeparator()
{
	return addPrikaz(new HSeparator(aVystup));
}

bool TextMenu::addVSeparator()
{
	return addPrikaz(new VSeparator(aVystup));
}

void TextMenu::action(int id)
{
	start();
}
