#include <cctype>
#include "Sifrator.h"
#include "Funkcie.h"
#include "Vystup.h"
#include "Koder.h"
#include "Vstup.h"

void Sifrator::init(char cinnost, const char * heslo, const char * vstupsubor, bool konzola, const char * vystupsubor)
{
	aCinnost = tolower(cinnost);
	aCinnost = (aCinnost != 's' && aCinnost != 'd' && aCinnost != 'h') ? 'h' : aCinnost;

	aHeslo = KopirujRetazec(heslo);
	if (!(aHeslo && *aHeslo))
		aCinnost = 'h';

	aVstupSubor = KopirujRetazec(vstupsubor);
	if (!(aVstupSubor && *aVstupSubor))
		aCinnost = 'h';

	aKonzola = konzola;
	aVystupSubor = KopirujRetazec(vystupsubor);
	if (!(aVystupSubor && *aVystupSubor))
		aKonzola = true;
}

void Sifrator::zmaz()
{
	delete[] aVystupSubor;
	delete[] aVstupSubor;
	delete[] aHeslo;
}

Sifrator::Sifrator(char cinnost, const char *heslo, const char *vstupsubor, bool konzola, const char *vystupsubor)
{
	init(cinnost, heslo, vstupsubor, konzola, vystupsubor);
}

Sifrator::Sifrator(const Sifrator & zdroj)
{
	init(zdroj.aCinnost, zdroj.aHeslo, zdroj.aVstupSubor, zdroj.aKonzola, zdroj.aVystupSubor);
}

Sifrator & Sifrator::operator=(const Sifrator & zdroj)
{
	if (this != &zdroj)
	{
		zmaz();
		init(zdroj.aCinnost, zdroj.aHeslo, zdroj.aVstupSubor, zdroj.aKonzola, zdroj.aVystupSubor);
	}
	return *this;
}


Sifrator::~Sifrator()
{
	zmaz();
}

void Sifrator::start()
{
	if (aCinnost == 'h')
		vypisHelp();
	else
	{
		unsigned char *zdrojtext = Vstup(aVstupSubor).citaj();
		if (zdrojtext)
		{
			unsigned char *cieltext = (aCinnost == 's') ? Koder().koduj((unsigned char *)aHeslo, zdrojtext)
				: Koder().dekoduj((unsigned char *)aHeslo, zdrojtext);
			if (cieltext)
			{
				Vystup(aVystupSubor).zapis(cieltext);
				//Vystup ciel(aVystupSubor);
				//ciel.zapis(cieltext);
				delete[] cieltext;
			}
			delete[] zdrojtext;
		}
		else
			vypisHelp();
	}
}

void Sifrator::vypisHelp()
{
	Vystup konzola("");
	konzola.zapis((unsigned char *)
		"sifrator CINNOST HESLO VSTUP_SUBOR [TYP_VYSTUPU VYSTUP_SUBOR]\n"
		"   CINNOST:\n"
		"      s...sifrovanie\n"
		"      d...desifrovanie\n"
		"      h...help\n"
		"   TYP_VYSTUPU:\n"
		"      s...subor\n"
		"      c...konzola\n\n");
}
