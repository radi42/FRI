//#define STARTTESTY
#include <iostream>
using namespace std;

#include "Sifrator.h"

#ifdef STARTTESTY
#include "Test.h"
#endif

int main(int argc, char *argv[])
{
	bool ok{ true };

#ifdef STARTTESTY
	Test testy;
	ok = testy.run();
#endif
	if (ok)
	{
		// Aktivacia programu
		char cinnost('h');
		char *heslo(NULL);
		char *vstupsubor(NULL);
		bool konzola(true);
		char *vystupsubor(NULL);
		if (argc > 1)
			cinnost = argv[1][0];
		if (argc > 2)
			heslo = argv[2];
		if (argc > 3)
			vstupsubor = argv[3];
		if (argc > 4)
			konzola = argv[4][0] == 's' ? false : true;
		if (argc > 5)
			vystupsubor = argv[5];
		Sifrator(cinnost, heslo, vstupsubor, konzola, vystupsubor).start();
	}
	else
	{
		cout << "CHYBA! NEPRESLI TESTY!" << endl;
		return 1;
	}
	return 0;
}