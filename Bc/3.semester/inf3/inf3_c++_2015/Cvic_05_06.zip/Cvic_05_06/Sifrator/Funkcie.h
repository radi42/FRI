#pragma once

char  *KopirujRetazec(const char *zdrojretazec);