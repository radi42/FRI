#pragma once
class Vstup
{
private:
	char *aMenoSuboru;
	unsigned dajDlzkaSuboru();
public:
	Vstup(const char *menoSuboru);
	Vstup(const Vstup &zdroj);
	Vstup &operator =(const Vstup &zdroj);

	~Vstup();

	unsigned char *citaj();
};

