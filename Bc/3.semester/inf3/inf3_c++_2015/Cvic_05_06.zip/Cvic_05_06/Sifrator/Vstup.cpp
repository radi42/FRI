#include <cstdio>
#include <cstring>
#include "Vstup.h"
#include "Funkcie.h"

Vstup::Vstup(const char *menoSuboru)
{
	aMenoSuboru = KopirujRetazec(menoSuboru);
}

Vstup::Vstup(const Vstup & zdroj)
{
	aMenoSuboru = KopirujRetazec(zdroj.aMenoSuboru);
}

Vstup & Vstup::operator=(const Vstup & zdroj)
{
	if (this != &zdroj)
	{
		delete[] aMenoSuboru;
		aMenoSuboru = KopirujRetazec(zdroj.aMenoSuboru);
	}
	return *this;
}

Vstup::~Vstup()
{
	delete[] aMenoSuboru;
}

unsigned char * Vstup::citaj()
{
	if (aMenoSuboru)
	{
		int dlzka = dajDlzkaSuboru();
		if (dlzka > 0)
		{
			unsigned char *text = new unsigned char[dlzka + 1];
			if (text)
			{
				FILE *f = fopen(aMenoSuboru, "rb");
				if (f)
				{
					fread(text, dlzka, 1, f);
					text[dlzka] = '\0';
					fclose(f);
					return text;
				}
			}
		}
	}
	return NULL;
}

unsigned Vstup::dajDlzkaSuboru()
{
	unsigned int dlzka(0);
	if (aMenoSuboru)
	{
		FILE *f = fopen(aMenoSuboru, "rb");
		if (f)
		{
			fseek(f, 0, SEEK_END);
			dlzka = ftell(f);
			fclose(f);
		}
	}
	return dlzka;
}

