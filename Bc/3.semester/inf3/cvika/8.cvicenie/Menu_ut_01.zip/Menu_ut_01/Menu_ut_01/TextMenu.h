#pragma once
#include "ICommand.h"
#include "IVystup.h"
#include "IVstup.h"


class TextMenu
{
private:
	ICommand **aPrikazy;
	unsigned int aPocet;
	IVstup &aVstup;
	IVystup &aVystup;

public:
	TextMenu(unsigned pocet, IVstup &vstup, IVystup &vystup);
	~TextMenu();
};

