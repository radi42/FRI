#include "TextMenu.h"


TextMenu::TextMenu(unsigned pocet, IVstup &vstup, IVystup &vystup)
: aPocet(pocet), aVstup(vstup), aVystup(vystup),
aPrikazy(pocet > 0 ? new ICommand *[pocet] : NULL)
{
	for (int i = 0; i < aPocet; i++)
		aPrikazy[i] = NULL;
}


TextMenu::~TextMenu()
{
}
