#include <iostream>
#include "HorizontalnyVystup.h"


void HorizontalnyVystup::zobraz(string &text)
{
	cout << text;
}
