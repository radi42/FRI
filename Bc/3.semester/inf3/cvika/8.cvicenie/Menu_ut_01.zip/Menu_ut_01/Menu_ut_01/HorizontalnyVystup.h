#pragma once
#include "IVystup.h"

class HorizontalnyVystup : public IVystup
{
public:
	virtual void zobraz(string &text);
};

