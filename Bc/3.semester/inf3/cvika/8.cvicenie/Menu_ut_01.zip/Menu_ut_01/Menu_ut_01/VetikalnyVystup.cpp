#include <iostream>
#include "VetikalnyVystup.h"


void VetikalnyVystup::zobraz(string &text)
{
	cout << text << endl;
}
