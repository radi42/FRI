#pragma once
class IVstup
{
public:

	virtual char dajVstup() = 0;
};

