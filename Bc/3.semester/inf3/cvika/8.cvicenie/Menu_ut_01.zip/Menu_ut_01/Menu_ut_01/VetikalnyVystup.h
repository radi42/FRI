#pragma once
#include "IVystup.h"
class VetikalnyVystup :
	public IVystup
{
public:
	virtual void zobraz(string &text);
};

