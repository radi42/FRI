#pragma once

int lengthFile(const char *menosuboru);

char *copyString(const char *zdrojtext);