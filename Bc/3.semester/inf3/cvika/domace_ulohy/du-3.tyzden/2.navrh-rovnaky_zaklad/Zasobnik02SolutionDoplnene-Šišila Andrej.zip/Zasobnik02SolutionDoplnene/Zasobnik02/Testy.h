#pragma once
#include "Zasobnik.h"

bool runtesty(Zasobnik *zasobnik);