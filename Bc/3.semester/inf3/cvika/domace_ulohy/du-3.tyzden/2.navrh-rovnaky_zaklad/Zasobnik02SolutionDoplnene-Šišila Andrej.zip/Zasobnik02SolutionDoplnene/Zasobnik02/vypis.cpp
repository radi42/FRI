#include <cstdio>

#include "vystup.h"

void vypis(int cislo)
{
	printf("%d\n", cislo);
}