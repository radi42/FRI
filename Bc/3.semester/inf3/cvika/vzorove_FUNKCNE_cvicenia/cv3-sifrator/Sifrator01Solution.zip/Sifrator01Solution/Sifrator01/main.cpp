#define TESTY

#ifdef TESTY
#include "Test.h"
#endif

int main()
{
	Test t;
	t.run();
	return 0;
}