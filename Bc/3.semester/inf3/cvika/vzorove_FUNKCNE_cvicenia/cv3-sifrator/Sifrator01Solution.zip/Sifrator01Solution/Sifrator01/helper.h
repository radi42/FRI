#pragma once

int dlzkaSuboru(const char *menoSuboru);