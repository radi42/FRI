# include "Koder.h"
#include "Test.h"

int main()
{
	Test test;
	test.RunTest();
	return 0;
}