#include "Koder.h"
#include "Test.h"

int main(void)
{
	Test test;
	test.runTest();

	return 0;
}