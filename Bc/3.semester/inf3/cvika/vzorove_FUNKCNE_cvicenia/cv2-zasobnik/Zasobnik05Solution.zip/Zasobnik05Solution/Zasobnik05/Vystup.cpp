#include <iostream>
#include "Vystup.h"

using namespace std;

void vypis(unsigned int cislo)
{
	cout << cislo << endl;
}