#pragma once

bool runtesty();
