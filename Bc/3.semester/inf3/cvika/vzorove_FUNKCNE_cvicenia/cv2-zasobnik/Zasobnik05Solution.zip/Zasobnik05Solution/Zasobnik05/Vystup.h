#pragma once

void vypis(unsigned int cislo);