#pragma once
#include "Zasobnik.h"

bool runtest(Zasobnik *zasobnik);