#pragma once

void vypis(const char *text);
