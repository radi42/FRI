#include <cstdio>

#include "vystup.h"

void vypis(const char *text)
{
	printf("%s", text);
}