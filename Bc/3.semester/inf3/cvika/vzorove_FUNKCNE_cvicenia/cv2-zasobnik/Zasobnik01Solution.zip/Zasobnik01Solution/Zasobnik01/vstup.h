#pragma once

namespace cvstup
{
	int vstup();
}

namespace cppvstup
{
	int vstup();
}