#pragma once

void vypis(unsigned int pocetNaVypis);
