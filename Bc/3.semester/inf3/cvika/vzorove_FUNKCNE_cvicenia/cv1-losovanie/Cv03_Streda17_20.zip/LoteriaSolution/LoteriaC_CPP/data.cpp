#include "data.h"

zreb zreby[10];