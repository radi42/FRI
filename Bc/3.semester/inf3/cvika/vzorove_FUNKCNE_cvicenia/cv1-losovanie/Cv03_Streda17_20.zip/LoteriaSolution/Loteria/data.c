#include "data.h"

struct zreb zreby[10];