#pragma once

void zrebuj(unsigned int pocet);