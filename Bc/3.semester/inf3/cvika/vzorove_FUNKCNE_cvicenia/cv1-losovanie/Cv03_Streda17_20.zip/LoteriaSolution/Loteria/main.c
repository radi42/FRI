#include "stavkKanc.h"

int main()
{
	losovanie(3);
	return 0;
}