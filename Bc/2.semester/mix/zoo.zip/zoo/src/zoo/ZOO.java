package zoo;

import lib.*;
/**
 * <h2>Trieda Zoo</h2>
 * Instancia typu Zoo ma manazera, zvierata a vozidla.
 * Je kompoziciou tychto objektov. 
 * 
 * @author bene 
 * @version 16.3.2012
 */
public class ZOO
{
    //===================================================== Atributy instancie ==
    private Osoba manazer;
    private Zverinec zverinecZOO;               // zoznam zvierat v ZOO
    private Kamion pracVozidlo;                 // Pracovne vozidlo
    //=========================================================== Konstruktory ==
    /**
     * Konstruktor s nastavenim atributov
     * @param manager
     * @param kapacitaZverinca
     */
    public ZOO(Osoba manager, int kapacitaZverinca) {
        this.manazer  = manager;
        this.zverinecZOO = new Zverinec(kapacitaZverinca);
        this.pracVozidlo = null;
    }

    public ZOO() {
        this(null, 50);
        setManazer(new Osoba("Jan", "Novak", 
                             new Datum(26, 3, 1970)));
    }

    //==================================================== Metody instancie ==
    public Osoba getManazer() { return manazer; }
    public void setManazer(Osoba manazer) { this.manazer = manazer; }
    public Zverinec getZverinecZOO() { return zverinecZOO; }
    public Kamion getPracVozidlo() { return pracVozidlo; }


    public void vytvorKamion() {
        Osoba man = new Osoba("Peter", "Hrasko", new Datum(5, 7, 1975));
        this.pracVozidlo = new Kamion(man, 1500);
    }

    /**
     * Naloženie živočícha na vozidlo
     * @param ziv
     * @return
     */
    public boolean nalozZivocicha(Prepravitelny ziv) {
        return pracVozidlo.nalozZivocicha(ziv);
    }

    public String info() {
        String str = "*** Zoologická záhrada ****\n";
        str += "Manazer: " + manazer + "\n--------\n";
        str += "Zverinec:\n" + zverinecZOO + "\n--------\n";
        
        return str;
    }

    @Override
    public String toString(){
        String vozidlo = pracVozidlo == null ? "vozidlo nie je pristavené"
                                             : "vozidlo je pristavené";
        return "Manazer: " + manazer + "\n--------\n" + zverinecZOO
            + "\n--------\n" + vozidlo;
    }

}

