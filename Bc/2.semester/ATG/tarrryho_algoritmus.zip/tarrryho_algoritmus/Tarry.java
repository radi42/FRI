
/**
 * ATG., uloha 3:
 * Zadaj graf v subore, z klavesnice zadaj riadiaci vrchol, program vypise
 * Tarryho sled a ci je suvisly
 * 
 * graf.txt:
 * 1. pocetVrcholov
 * 3. pocetHran
 * 4. Vrchol1 Vrchol2 Vrchol2 Vrchol5... // 2 vrcholy=1hrana
 * 
 */

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;

class Hrana {
    public int v1;
    public int v2;
    public boolean prvyPrichod = false;
    public boolean jedenSmer = false;
    public boolean druhySmer = false;

    public Hrana(int v1, int v2) {this.v1 = v1; this.v2 = v2;}
}

public class Tarry {

    public static int pocetVrcholov;
    // index 0 => vrchol 1, true => vrchol pouzity
    public static boolean[] vrcholy;

    public static int pocetHran;
    public static Hrana[] hrany;

    public static int riadiaciVrchol;

    public static void nacitajGraf() throws FileNotFoundException {
        FileReader fr = new FileReader("graf.txt");
        Scanner sc = new Scanner(fr);

        pocetVrcholov = sc.nextInt();
        vrcholy = new boolean[pocetVrcholov];
        for (int i=0; i<pocetVrcholov; i++) {
            vrcholy[i] = false;
        }

        pocetHran = sc.nextInt();
        hrany = new Hrana[pocetHran];
        for (int i=0; i<pocetHran; i++) {
            hrany[i] = new Hrana(sc.nextInt(), sc.nextInt());
        }

        sc.close();

        sc = new Scanner(System.in);
        System.out.print("zadaj riadiaci vrchol: ");
        riadiaciVrchol = sc.nextInt();
        if (riadiaciVrchol > pocetVrcholov | riadiaciVrchol<0) System.exit(1);

    }

    public static void main(String[] args) throws FileNotFoundException {
        nacitajGraf();

        System.out.print(riadiaciVrchol + ", ");

        boolean koniec = false;
        while (!koniec) {
            for (int i=0; i<pocetHran; i++) {
                if (hrany[i].v1 == riadiaciVrchol | hrany[i].v2 == riadiaciVrchol) {
                    if (hrany[i].jedenSmer | hrany[i].druhySmer) {
                        riadiaciVrchol = hrany[i].v2;
                        if (vrcholy[riadiaciVrchol - 1] == false) {
                            vrcholy[riadiaciVrchol - 1] = true;
                            hrany[i].prvyPrichod = true;
                        }
                        System.out.print(riadiaciVrchol + ", ");
                        break;
                    }
                    else koniec = true;
                }
            }
        }
    }
}
