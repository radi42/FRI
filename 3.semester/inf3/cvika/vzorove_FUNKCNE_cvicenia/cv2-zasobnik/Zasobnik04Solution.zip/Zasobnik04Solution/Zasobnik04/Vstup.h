#pragma once

namespace cvstup
{
	unsigned int vstup();
}

namespace cppvstup
{
	unsigned int vstup();
}

