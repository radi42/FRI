#pragma once

bool runtest();