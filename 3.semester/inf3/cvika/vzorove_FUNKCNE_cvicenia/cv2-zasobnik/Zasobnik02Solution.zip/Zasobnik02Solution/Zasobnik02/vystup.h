#pragma once

void vypis(int cislo);