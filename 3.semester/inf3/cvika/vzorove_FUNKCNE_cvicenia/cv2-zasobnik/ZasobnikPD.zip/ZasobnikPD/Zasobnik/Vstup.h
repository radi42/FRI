#pragma once

namespace cppvstup
{
	int vstup(const char *oznam);
}

namespace cvstup
{
	int vstup(const char *oznam);
}
