#pragma once

void zrebuj(int pocetVyhernychZrebov);