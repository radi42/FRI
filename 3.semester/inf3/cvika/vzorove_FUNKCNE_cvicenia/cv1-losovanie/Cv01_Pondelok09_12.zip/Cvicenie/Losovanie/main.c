#include "StavkovaKancelaria.h"

int main()
{
	printf("C-verzia\n--------\n");
	losovanie(10);
	return 0;
}