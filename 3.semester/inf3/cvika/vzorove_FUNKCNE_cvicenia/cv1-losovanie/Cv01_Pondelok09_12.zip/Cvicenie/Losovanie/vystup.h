#pragma once

void vypis(int pocet);
