#include "data.h"

struct zreb vyherneZreby[10];