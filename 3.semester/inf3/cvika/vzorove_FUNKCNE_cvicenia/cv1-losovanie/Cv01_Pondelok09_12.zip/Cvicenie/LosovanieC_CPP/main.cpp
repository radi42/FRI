#include "StavkovaKancelaria.h"

int main()
{
	losovanie(10);
	return 0;
}