#include "data.h"

zreb vyherneZreby[10];