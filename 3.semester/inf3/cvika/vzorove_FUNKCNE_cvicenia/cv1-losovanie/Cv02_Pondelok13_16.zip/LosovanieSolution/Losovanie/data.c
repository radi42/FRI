#include "data.h"

struct zreb zreby[POCET_ZREBOV];
