#pragma once

void losuj(int pocet);