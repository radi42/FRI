#include "stavkovaKanc.h"

int main()
{
	losuj(6);
	return 0;
}