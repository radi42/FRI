#include "data.h"

zreb zreby[POCET_ZREBOV];
