#include "stavkovaKanc.h"

int main()
{
	losuj(3);
	return 0;
}