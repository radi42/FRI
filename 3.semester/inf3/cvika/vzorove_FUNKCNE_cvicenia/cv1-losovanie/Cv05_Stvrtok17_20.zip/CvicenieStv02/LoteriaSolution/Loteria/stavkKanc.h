#pragma once

void losovanie(int pocet);