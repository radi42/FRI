#pragma once

void vypis(int pocetVyzrebovanych);