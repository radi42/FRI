#include "stavkKanc.h"

int main()
{
	losovanie(5);
	return 0;
}