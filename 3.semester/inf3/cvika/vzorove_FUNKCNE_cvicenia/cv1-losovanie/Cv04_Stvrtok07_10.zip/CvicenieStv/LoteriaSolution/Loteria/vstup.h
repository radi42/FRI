#pragma once

void pripravZreby();