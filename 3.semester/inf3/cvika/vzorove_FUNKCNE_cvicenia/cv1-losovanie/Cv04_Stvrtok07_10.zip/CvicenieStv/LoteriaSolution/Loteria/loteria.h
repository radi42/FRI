#pragma once

void zrebuj(int pocet);