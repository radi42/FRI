#pragma once

void losovanie();
