#include "tipos.h"

int main()
{
	losovanie();
	return 0;
}