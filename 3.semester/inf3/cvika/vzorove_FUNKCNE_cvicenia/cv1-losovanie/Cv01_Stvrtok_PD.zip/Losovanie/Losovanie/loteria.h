#pragma once

void zrebuj(int pocetMiest);
