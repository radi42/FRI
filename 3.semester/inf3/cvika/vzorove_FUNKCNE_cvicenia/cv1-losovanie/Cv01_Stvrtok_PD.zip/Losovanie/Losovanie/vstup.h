#pragma once
#include "data.h"

void pripravZreby();
