#pragma once

void losovanie();