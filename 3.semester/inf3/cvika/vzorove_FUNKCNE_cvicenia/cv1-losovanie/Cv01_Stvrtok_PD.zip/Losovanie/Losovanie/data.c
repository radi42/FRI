#include "data.h"

struct zreb vyherneZreby[10];
//zreb tah[10];