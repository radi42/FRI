#pragma once

#define POCET_ZREBOV 10

struct zreb
{
	int cislo;
	char majitel[21];
};

//typedef struct 
//{
//	int cislo;
//	char majitel[21];
//} zreb;
//
extern struct zreb vyherneZreby[POCET_ZREBOV];
//extern zreb tah[10];
