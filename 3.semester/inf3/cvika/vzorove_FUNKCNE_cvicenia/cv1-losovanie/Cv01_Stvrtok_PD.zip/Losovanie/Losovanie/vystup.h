#pragma once

void vypis(int maxPoradie);