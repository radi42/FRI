#include "Koder.h"
#include "Test.h"

int main()
{
	Test test;
	test.runTest();
	return 0;
}