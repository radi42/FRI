#include "Test.h"

int main()
{
	Test t;
	t.run();
	return 0;
}