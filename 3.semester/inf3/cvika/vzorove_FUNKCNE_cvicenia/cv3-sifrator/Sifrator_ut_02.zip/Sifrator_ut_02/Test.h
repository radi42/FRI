#pragma once
#include "Koder.h"

class Test
{
public:

	Test()
	{
	}

	~Test()
	{
	}

	bool runTest()
	{
	}
};

