clc;
clear all;
amplitudaPre1= 1;
amplitudaPre0 =0;
pocet=10;
bitoveSlovo=zeros(1,pocet); %vytvorenie slova plneho nul
for i = 1:pocet             %naplnenie bitoveho slova nahodnymi znakmi{0,1}
   pom=randi(2);
   bitoveSlovo(i)= mod(pom,2);
end;
vyslednySignal=zeros(pocet,100);%vytvorenie pola signalu plneho nul
for k = 1:pocet             % cyklus vytvara dany po�et signalovych zmien 
fs = 44100;
t=linspace(k*2*pi,(k*2+2)*pi,100);
c=bitoveSlovo(k);
if c==1                     % if ur�ujuci �o sa sprav� s 1 a 0
    signal=amplitudaPre1*sin(t+k*2*pi);
else
    signal=amplitudaPre0*sin(t+k*2*pi);
end
vyslednySignal(k,1:100)=signal;
end; 
sucet=zeros(1,100*pocet);   
for i = 1:pocet             %cyklus prelo�� signal z dvojrozmerneho pola na jednorozmerne
    for j = 1:100
        sucet(1,i*100-100+j) = vyslednySignal(i,j);
    end;
end;

% teraz vypisovanie signalu a vodiacich �iar

t2=linspace(1,100*pocet,pocet+1);
for k = 1:10 
    plot(t2,k/1000,'r');
    hold on
    plot(t2,-k/1000,'r');
    hold on
end;
t=linspace(1,100*pocet,1000*pocet);
plot(t,0,'black');
hold on
plot(sucet);
hold on
sound(sucet,fs,16);

%zapisanie signalu do zvukoveho suboru
audiowrite('C:\novy\zvuk_amplituda.flac',sucet,fs);
