/* 
 * File:   main.c
 * Author: cyrec
 *
 * Created on Pondelok, 2016, máj 9, 8:55
 */

#include <stdio.h>
#include <stdlib.h>

struct FrontItem {
    struct FrontItem * Next;
    void * Data;
};

void enqueue (struct FrontItem * top, void * data) {
    
}

void dequeue (struct FrontItem * top) {
    
}

/*
 * 
 */
int main(int argc, char** argv) {

    return (EXIT_SUCCESS);
}

