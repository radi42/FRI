﻿using System;

namespace krypto
{
	public enum CipherType
	{
		Monoalphabetic,
		Polyalphabetic
	}
}

