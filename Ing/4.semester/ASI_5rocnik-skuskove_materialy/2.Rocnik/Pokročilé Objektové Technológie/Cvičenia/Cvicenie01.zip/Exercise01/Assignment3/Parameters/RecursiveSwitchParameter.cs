﻿namespace Assignment3.Parameters
{
    /// <summary>
    /// Reprezentuje prepinac parametra pre rekurzivne prehliadanie.
    /// </summary>
    class RecursiveSwitchParameter : IParameter
    {
        /// <summary>
        /// Konstanta parametra.
        /// </summary>
        public const string Parameter = @"\r";

        /// <summary>
        /// Urcuje, ci bol parameter pouzity (predany programu).
        /// </summary>
        public bool WasUsed { get; set; }

        /// <summary>
        /// Maximalna uroven vnorenia.
        /// </summary>
        public int MaxLevel { get; set; }

        /// <summary>
        /// Konstruktor.
        /// </summary>
        public RecursiveSwitchParameter()
        {
            WasUsed = false;
            MaxLevel = int.MaxValue; // Konstanta najvacsieho celeho mozneho cisla (2 147 483 647)
        }
    }
}
