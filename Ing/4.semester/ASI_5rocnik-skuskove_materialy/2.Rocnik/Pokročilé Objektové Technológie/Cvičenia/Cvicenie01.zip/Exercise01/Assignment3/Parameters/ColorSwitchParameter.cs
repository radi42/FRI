﻿using System;

namespace Assignment3.Parameters
{
    /// <summary>
    /// Reprezentuje prepinac parametra pre zobrazenie suborov modrou farbou.
    /// </summary>
    class ColorSwitchParameter : IParameter
    {
        /// <summary>
        /// Konstanta parametra.
        /// </summary>
        public const string Parameter = @"\c";

        /// <summary>
        /// Konstanta pre prednastavenu farbu.
        /// </summary>
        public const ConsoleColor Color = ConsoleColor.Blue;

        /// <summary>
        /// Urcuje, ci bol parameter pouzity (predany programu).
        /// </summary>
        public bool WasUsed { get; set; }

        /// <summary>
        /// Konstruktor.
        /// </summary>
        public ColorSwitchParameter()
        {
            WasUsed = false;
        }
    }
}
