﻿using System;
using System.Text;

namespace Assignment1
{
    class Program
    {
        static void Main(string[] args)
        {
            // Zadanie c. 1.0
            Console.WriteLine("Zadanie 1.0:");
            foreach (string arg in args)
            {
                Console.WriteLine(arg);
            }

            // Zadanie c. 1.1
            Console.WriteLine("\nZadanie 1.1:");
            Array.Sort(args);
            foreach (string arg in args)
            {
                Console.WriteLine(arg);
            }

            // Zadanie c. 1.2
            Console.WriteLine("\nZadanie 1.2:");
            int idx = 1;
            foreach (string arg in args)
            {
                //Console.WriteLine(idx + ". " + arg);  
                // alebo lepsie napisane cez formatovaci retazec:
                Console.WriteLine("{0}. {1}", idx, arg);
                idx++;
            }

            // Zadanie c. 1.3
            Console.WriteLine("\nZadanie 1.3:");
            string str = string.Empty;
            foreach (string arg in args)
            {
                str += arg;
            }
            Console.WriteLine(str);

            // Zadanie c. 1.3 - cez StringBuilder
            Console.WriteLine("\nZadanie 1.3 - cez StringBuilder:");
            StringBuilder sb = new StringBuilder();
            foreach (string arg in args)
            {
                sb.Append(arg);
            }
            Console.WriteLine(sb);

            // Zadanie c. 1.4
            Console.WriteLine("\nZadanie 1.4:");
            foreach (string arg in args)
            {
                Console.WriteLine(arg.Length + " " + arg);
                /* alebo Console.WriteLine(
                           "{0} {1}", arg.Length, arg); */
            }

            Console.ReadLine();
        }
    }
}
