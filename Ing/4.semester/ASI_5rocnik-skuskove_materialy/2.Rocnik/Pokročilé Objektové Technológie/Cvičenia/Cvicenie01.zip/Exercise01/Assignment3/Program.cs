﻿namespace Assignment3
{
    /// <summary>
    /// Zdrojovy kod je podrobne okomentovany. Pouzil som dokumentacne XML komentare (tri lomky za sebou). 
    /// Tieto je mozne neskor exportovat, avsak hlavne maju zmysel pre tvorbu helpu (IntelliSense ich dokaze 
    /// zobrazit, takze vdaka tejto funkcionalite sa mozeme lepsie orientavat v takto okomentovanych 
    /// datovych typoch a metodach v zdrojovych kodoch). Pre ich generovanie do XML suboru musite nastavit
    /// prepinac v kazdom jednom "XML documentation file" v nastaveniach projektu (prave tlacidlo na projekt, 
    /// potom vyberieme v kontextovom menu polozku Properties, v zobrazenom okne nastaveni zvolime druhu 
    /// zalozku Build a tam v casti Output zaciarkneme zasrktavacie policka "ML documentation file".
    /// </summary>
    class Program
    {
        static void Main(string[] args)
        {
            // Vytvorime instanciu (objekt) triedy ListDirectoriesFiles
            var listDirFiles = new ListDirectoriesFiles();
            
            // Zavolame metodu ParseParameters(), cim spracujeme vsetky argumenty
            listDirFiles.ParseParameters(args);
            
            // Po spracovani vypiseme vsetky priecinky a subory podla nastavenych parametrov
            listDirFiles.ShowDirectoriesAndFiles();
        }
    }
}
