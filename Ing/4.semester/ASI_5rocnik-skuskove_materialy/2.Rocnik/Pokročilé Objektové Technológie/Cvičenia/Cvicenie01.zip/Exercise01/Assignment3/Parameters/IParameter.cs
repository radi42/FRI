﻿namespace Assignment3.Parameters
{
    interface IParameter
    {
        /// <summary>
        /// Urcuje, ci bol parameter pouzity (predany programu).
        /// </summary>
        bool WasUsed { get; set; }
    }
}
