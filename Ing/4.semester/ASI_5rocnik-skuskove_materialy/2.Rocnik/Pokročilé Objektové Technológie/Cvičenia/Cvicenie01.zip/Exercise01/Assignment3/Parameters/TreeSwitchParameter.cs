﻿namespace Assignment3.Parameters
{
    /// <summary>
    /// Reprezentuje prepinac parametra pre zobrazenie stromovej struktury.
    /// </summary>
    class TreeSwitchParameter : IParameter
    {
        /// <summary>
        /// Konstanta parametra.
        /// </summary>
        public const string Parameter = @"\t";

        /// <summary>
        /// Konstanta pre prednastaveny pocet medzier.
        /// </summary>
        public const int DefaultSpaceCount = 2;

        /// <summary>
        /// Urcuje, ci bol parameter pouzity (predany programu).
        /// </summary>
        public bool WasUsed { get; set; }

        /// <summary>
        /// Pocet medzier.
        /// </summary>
        public int SpaceCount { get; set; }

        /// <summary>
        /// Konstruktor.
        /// </summary>
        public TreeSwitchParameter()
        {
            WasUsed = false;
            SpaceCount = DefaultSpaceCount;
        }

        /// <summary>
        /// Vytvori retazec zlozeny z medzier o pocte urcenom vlastnostou SpaceCount.
        /// </summary>
        /// <returns>Retazec medzier.</returns>
        public string GetSpacesString()
        {
            if (WasUsed)
                return new string(' ', SpaceCount);
            else
                return string.Empty;
        }
    }
}
