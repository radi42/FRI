﻿using System;
using System.Globalization;

namespace PersonCreator
{
    class Program
    {
        static void Main()
        {
            // Vytvorenie objektu Person pomocou bezparametrickeho konstruktora
            var jano = new Person();
            jano.FirstName = "Ján";
            jano.LastName = "Mrkvička";
            jano.Gender = Gender.Male;
            jano.Birthday = new DateTime(1985, 12, 31);

            // Vytvorenie objektu Person pomocou bezparametrickeho konstruktora s inicializaciou vlastnosti
            var jano2 = new Person
            {
                FirstName = "Ján",
                LastName = "Mrkvička",
                Gender = Gender.Male,
                Birthday = DateTime.Parse("31.12.1985", new CultureInfo("sk")) // Ak budeme potrebovat ziskat cas z retazce, musime zavolat metodu Parse alebo ParseExact
            };

            // Vytvorenie objektu Person pomocou parametrickeho konstruktora
            var jano3 = new Person("Ján", "Mrkvička", new DateTime(1985, 12, 31), Gender.Male);

            // Vytvorenie pomocou parametrickeho konstruktora s objektovym inicializatorom - inicializacia vlastnosti objektu
            var fero = new Person("František", "Mrkvička", null) { Birthday = new DateTime(2000, 1, 1) };
            
            // Vypisanie, pouziva nas prekryty ToString()
            Console.WriteLine("jano: " + jano);
            Console.WriteLine("jano2: " + jano2);
            Console.WriteLine("jano3: " + jano3);
            Console.WriteLine("fero: " + fero);
            Console.WriteLine();

            var compResult = jano.CompareTo(fero);
            Console.WriteLine("jano.CompareTo(fero): {0} (Jano {1} Fero)", compResult, compResult > 0 ? ">" : (compResult < 0 ? "<" : "==")); // 1
            Console.WriteLine("jano.Equals(fero): {0}", jano.Equals(fero)); // False
            Console.WriteLine("jano.Equals(jano2): {0}", jano.Equals(jano2)); // True. Keby nemame vlastnu implementaciu prekrytej metody Equals(), vracalo by to False (pretoze by sa porovnavali odkazy - referencie).
            Console.WriteLine();

            Console.WriteLine("jano[0]: {0}", jano[0]);
            Console.WriteLine("jano[2]: {0}", jano[2]);
            //Console.WriteLine("jano[3]: {0}", jano[3]); // Vyhodi vynimku
            Console.WriteLine("jano[\"Age\"]: {0}", jano["Age"]);

            jano[1] = "Baklazan";
            Console.WriteLine("jano[1] = {0}", jano[1]);
            Console.WriteLine("jano: {0}", jano);
            Console.WriteLine();

            // Vygenerujeme 10 osob
            var persons = GeneratePersons(10);

            // Vypiseme vygenerovane osoby
            Console.WriteLine("Vygenerovane osoby:");
            foreach (var person in persons)
            {
                Console.WriteLine(person);
            }
            Console.WriteLine();

            // Utriedime a vypiseme
            Array.Sort(persons);
            Console.WriteLine("Zotriedene osoby:");
            foreach (var person in persons)
            {
                Console.WriteLine(person);
            }
            Console.WriteLine();

            // Zmeny pohlavi - class, struct, struct ref, struct out
            Console.WriteLine("Zmeny pohlavi (testy predavania parametrov cez ref, out):");
            var sPersonClass = new SimplePersonClass("Ján", "Mrkvička", new DateTime(1985, 12, 31), Gender.Male);
            Console.Write("class {0}", sPersonClass);
            ChangeGender(sPersonClass);
            Console.WriteLine(" -> ChangeGender() -> {0}", sPersonClass.Gender);

            var sPersonStruct = new SimplePersonStruct("Ján", "Mrkvička", new DateTime(1985, 12, 31), Gender.Male);
            Console.Write("struct {0}", sPersonStruct);
            ChangeGender(sPersonStruct);
            Console.WriteLine(" -> ChangeGender() -> {0}", sPersonStruct.Gender);

            var sPersonStructRef = new SimplePersonStruct("Ján", "Mrkvička", new DateTime(1985, 12, 31), Gender.Male);
            Console.Write("struct {0}", sPersonStructRef);
            ChangeGenderStructRef(ref sPersonStructRef);
            Console.WriteLine(" -> ChangeGender(ref) -> {0}", sPersonStructRef.Gender);
            
            var sPersonStructOut = new SimplePersonStruct("Ján", "Mrkvička", new DateTime(1985, 12, 31), Gender.Male);
            Console.Write("struct {0}", sPersonStructOut);
            ChangeGenderStructOut(out sPersonStructOut);
            Console.WriteLine(" -> ChangeGender(out) -> {0}", sPersonStructOut.Gender);
            
            Console.ReadLine();
        }

        public static void ChangeGender(SimplePersonClass person)
        {
            if (person.Gender == Gender.Female)
                person.Gender = Gender.Male;
            else if (person.Gender == Gender.Male)
                person.Gender = Gender.Female;
        }

        public static void ChangeGender(SimplePersonStruct person)
        {
            if (person.Gender == Gender.Female)
                person.Gender = Gender.Male;
            else if (person.Gender == Gender.Male)
                person.Gender = Gender.Female;
        }

        public static void ChangeGenderStructRef(ref SimplePersonStruct person)
        {
            if (person.Gender == Gender.Female)
                person.Gender = Gender.Male;
            else if (person.Gender == Gender.Male)
                person.Gender = Gender.Female;
        }

        public static void ChangeGenderStructOut(out SimplePersonStruct person)
        {
            // Vsimnite si, ze v strukture nie je definovany bezparametricky konstruktor
            // a napriek tomu ho mozeme vyuzit
            person = new SimplePersonStruct();

            if (person.Gender == Gender.Female)
                person.Gender = Gender.Male;
            else if (person.Gender == Gender.Male)
                person.Gender = Gender.Female;
        }
        
        public static Person[] GeneratePersons(int count)
        {
            // Ukazka rozne deklarovanych poli
            string[] maleFirstNames = new string[] { "Ján", "Alexander", "Adam", "Juraj", "Štefan" }; 
            string[] maleLastNames = new[] { "Nový", "Malý", "Veľký", "Chudý", "Vysoký", "Bohatý" };
            string[] femaleFirstNames = { "Silvia", "Františka", "Michaela", "Barbora", "Eva" };
            var femaleLastNames = new[] { "Nová", "Malá", "Veľká", "Chudá", "Vysoká", "Bohatá", "Krásna" };

            // Nahodny generator
            var random = new Random();

            // Vygenerujeme osoby
            var result = new Person[count];
            for (int i = 0; i < count; i++)
            {
                string firstName, lastName;
                Gender gender;
                int age = random.Next(0, 121); // Vek od nula po 120 rokov
                var birthday = DateTime.Now.AddYears(-age);

                if (random.Next(2) == 0)
                {
                    gender = Gender.Male;
                    firstName = maleFirstNames[random.Next(maleFirstNames.Length)];
                    lastName = maleLastNames[random.Next(maleLastNames.Length)];
                }
                else
                {
                    gender = Gender.Female;
                    firstName = femaleFirstNames[random.Next(femaleFirstNames.Length)];
                    lastName = femaleLastNames[random.Next(femaleLastNames.Length)];
                }

                result[i] = new Person(firstName, lastName, birthday, gender);
            }

            return result;
        }
    }
}
