﻿using System;
using System.Globalization;

namespace PersonCreator
{
    /// <summary>
    /// Trieda Osoba. 
    /// Trieda moze mat 2 pristupove modifikatory: 
    ///  - internal (implicitne, t.j. ak sa neuvedie ziadny) - je verejny v ramci zostavenia (assembly), 
    ///    sukromny mimo neho (ine zostavenie nema k triede pristup, nie je ho vidno)
    ///  - public - verejny, mozno potom triedu pouzivat nielen v tomto zostaveni, 
    ///    ale aj mimo neho (v inych zostaveniach - projektoch). 
    /// Ak by sme mali vnutornu (nested) triedu v triede, ma viac nez 2 pristupove modifikatory.
    /// </summary>
    public class Person : IComparable, IComparable<Person>
    {
        /// <summary>
        /// Meno. // Priklad datoveho clena (field). Ak sa pristupovy modifikator neuvedie, implicitne je private. 
        /// Ine pristupove modifikatory okrem private: protected, public, internal, protected internal.  
        /// </summary>
        private string _firstName;

        /// <summary>
        /// Meno.  // Priklad klasickej full property, zapuzdruje datovy clen <see cref="_firstName"/>. 
        /// Umozni automaticky zmenit nazov, ak pouzijeme premenovanie pomocou refaktoringu.
        /// Mozeme vynechat get alebo set, pripadne zmenit pristupovy modifikator pre get alebo set
        /// cast (napr. private set { _firstName = value } sposobi, ze do vlastnosti bude mozne zapisat
        /// iba z vnutra triedy). 
        /// </summary>
        public string FirstName
        {
            get { return _firstName; }
            set { _firstName = value; }
        }
        
        /// <summary>
        /// Priezvisko. // Priklad automatickej (auto) property
        /// </summary>
        public string LastName { get; set; }

        /// <summary>
        /// Datum narodenia.
        /// Ak by sme zapisali "Birthday { get; private set; }", bude Birthday z vonku len na citanie,
        /// zapisovat by sa mohlo len z vnutra - vyskusajte si.
        /// Ak pridame za typ DateTime otaznik (mozne iba pre hodnotove typy), jedna sa o typ Nullable,
        /// pomocou ktoreho moze hodnotovy typ nadobudat null hodnoty.
        /// </summary>
        public DateTime? Birthday { get; set; } // Je to ako by sme napisali toto: public Nullable<DateTime> Birthday { get; set; }

        /// <summary>
        /// Vek, vypocitavany z <see cref="Birthday"/> a aktualneho casu. // Vlastnost iba na citanie (read-only)
        /// V C# 6.0 je mozne nasledujucu readonly vlastnost jednoduchsie nahradit za lambda vyraz: 
        /// public int Age => (int) ((DateTime.Now - Birthday).TotalDays / 365);
        /// </summary>
        public int Age
        {
            get
            {
                if (Birthday == null)
                    return 0;

                return (int)((DateTime.Now - Birthday.Value).TotalDays / 365);

                // Alebo lepsie - najdene cez google "c# how to calculate age" - zdroj: http://stackoverflow.com/questions/9/how-do-i-calculate-someones-age-in-c
                //var today = DateTime.Today;
                //var age = today.Year - Birthday.Year;
                //if (Birthday > today.AddYears(-age))
                //    age--;

            } // Iba getter, setter sme odstranili
        }

        /// <summary>
        /// Pohlavie. // V C# 6.0 mozete inicializovat vlastnosti takto:
        /// </summary>
        public Gender Gender { get; set; }

        /// <summary>
        /// Vytvori objekt typu <see cref="Person"/>. // Bezparametricky konstruktor.
        /// </summary>
        public Person()
        {
        }

        /// <summary>
        /// Vytvori objekt typu <see cref="Person"/>. // Parametricky konstruktor.
        /// </summary>
        /// <param name="firstName">Meno.</param>
        /// <param name="lastName">Priezvisko.</param>
        /// <param name="birthday">Datum narodenia.</param>
        /// <param name="gender">Pohlavie.</param>
        public Person(string firstName, string lastName, DateTime? birthday, Gender gender = Gender.Unknown)
        {
            FirstName = firstName;
            LastName = lastName;
            Birthday = birthday;
            Gender = gender;
        }

        /// <summary>
        /// Vrati retazec v tvare Meno Priezvisko (Vek).
        /// </summary>
        /// <returns>Retazec v tvare Meno Priezvisko (Vek).</returns>
        public override string ToString()
        {
            //return string.Format("{0} {1} ({2})", FirstName, LastName, Age);
            return $"{FirstName} {LastName} ({Age})"; // C# 6.0
        }

        protected bool Equals(Person other)
        {
            return string.Equals(FirstName, other.FirstName) &&
                   string.Equals(LastName, other.LastName) &&
                   Birthday.Equals(other.Birthday);
        }

        // Equals sme si prekryli, pretoze ho chceme pouzit na porovnavanie pomocou hodnot objektu. 
        // Ak by sme ho neprekryli, objekty porovnava na zaklade referencii (odkazov).
        public override bool Equals(object obj)
        {
            if (ReferenceEquals(null, obj)) return false;
            if (ReferenceEquals(this, obj)) return true;
            if (obj.GetType() != GetType()) return false;
            return Equals((Person)obj);
        }

        // S Equals je nutne prekryvat aj GetHashcode, dolezity je pre mnohe triedy, 
        // ktore pracuju s hashom, napr. v Dictionary<K, T>
        public override int GetHashCode()
        {
            unchecked
            {
                int hashCode = (FirstName != null ? FirstName.GetHashCode() : 0);
                hashCode = (hashCode * 397) ^ (LastName != null ? LastName.GetHashCode() : 0);
                hashCode = (hashCode * 397) ^ Birthday.GetHashCode();
                return hashCode;
            }
        }
        
        /// <summary>
        /// Porovnava aktualny objekt s inym objektom daneho typu. Ak <paramref name="obj"/> nie je objekt typu <see cref="Person"/>, vyhodi vynimku. 
        /// // Vsimnite si, toto je explicitna definicia metody CompareTo() negenerickeho rozhrania IComparable.
        /// </summary>
        /// <param name="obj">Objekt typu <see cref="Person"/>.</param>
        /// <returns>Vracia bud cislo &lt; 0, ak objekt je mensi nez <paramref name="obj"/>. Nulu, ak sa objekty rovnaju.
        /// Ak je objekt vacsi nez <paramref name="obj"/>, vrati cislo &gt; 0.</returns>
        /// <exception cref="ArgumentException">Vyhodi vynimku, ak parameter <paramref name="obj"/> nie je typu <see cref="Person"/>.</exception> 
        int IComparable.CompareTo(object obj)
        {
            if (obj == null) 
                return 1;

            var other = obj as Person;
            if (other != null)
                return CompareTo(other);
            
            throw new ArgumentException("Object is not a Person.");
        }

        /// <summary>
        /// Porovnava aktualny objekt s inym objektom daneho typu.
        /// // Vsimnite si, toto je implicitna definicia metody CompareTo() generickeho rozhrania IComparable(T).
        /// </summary>
        /// <param name="other">Objekt typu <see cref="Person"/>.</param>
        /// <returns>Vracia bud cislo &lt; 0, ak objekt je mensi nez <paramref name="other"/>. Nulu, ak sa objekty rovnaju.
        /// Ak je objekt vacsi nez <paramref name="other"/>, vrati cislo &gt; 0.</returns>
        public int CompareTo(Person other)
        {
            if (other == null) 
                return 1;

            //return Age.CompareTo(other.Age);

            var result = string.Compare(LastName, other.LastName, StringComparison.InvariantCulture);
            if (result != 0)
                return result;

            result = string.Compare(FirstName, other.FirstName, StringComparison.InvariantCulture);
            if (result != 0)
                return result;

            // Kedze Birthday sme zmenili za nullable typ (DateTime?), pouzijeme null coalescing operator (??),
            // ten vracia hodnotu vyrazu vlavo pred nim, ak je vyraz rozny ako null. Ak je rovny null, vracia hodnotu vpravo od operatora
            // Birthday ?? DateTime.MinValue sa da prepisat pomocou ternarneho operator takto: 
            // Birthday != null ? Birthday : DateTime.MinValue
            // -1 kvoli zmene znamienka, aby sa porovnavalo od najmladsieho po najstarsieho
            result = DateTime.Compare(Birthday ?? DateTime.MinValue, other.Birthday ?? DateTime.MinValue) * -1; 
            return result;
        }

        /// <summary>
        /// Priklad indexera. V tejto triede velmi nema zmysel, no pre ukazku si ho vyskusajme. 
        /// </summary>
        /// <param name="index">0 spristupni <see cref="FirstName"/>, 1 spristupni <see cref="LastName"/> a 2 <see cref="Age"/>.</param>
        /// <returns>Retazec podla daneho indexu.</returns>
        /// <exception cref="IndexOutOfRangeException">Vyhodi, ak je index rozny ako 0, 1 a 2. :)</exception>
        /// <exception cref="InvalidOperationException">Vyhodi pri pokuse zmenit <see cref="Age"/>.</exception>
        public string this[int index]
        {
            get // getter - vracia hodnoty
            {
                switch (index)
                {
                    case 0:
                        return FirstName;
                    case 1:
                        return LastName;
                    case 2:
                        return Age.ToString(CultureInfo.InvariantCulture);
                    default:
                        throw new IndexOutOfRangeException("index");
                }
            } 
            set // setter - nastavuje hodnoty cez klucove slovo value
            {
                switch (index)
                {
                    case 0:
                        FirstName = value;
                        break;
                    case 1:
                        LastName = value;
                        break;
                    case 2:
                        throw new InvalidOperationException("Age cannot be changed.") ;
                    default:
                        throw new IndexOutOfRangeException("index");
                }
            }
        }

        /// <summary>
        /// Priklad dalsieho indexera - funguje tu overloading. V tejto triede velmi nema zmysel, no pre ukazku si ho vyskusajme. 
        /// </summary>
        /// <param name="name">FirstName spristupni <see cref="FirstName"/>, LastName spristupni <see cref="LastName"/> a Age <see cref="Age"/>.</param>
        /// <returns>Retazec podla daneho indexu.</returns>
        /// <exception cref="IndexOutOfRangeException">Vyhodi, ak je index rozny ako FirstName, LastName alebo Age. :)</exception>
        /// <exception cref="InvalidOperationException">Vyhodi pri pokuse zmenit <see cref="Age"/>.</exception>
        public string this[string name]
        {
            get // getter - vracia hodnoty
            {
                switch (name)
                {
                    case "FirstName":
                        return FirstName;
                    case "LastName":
                        return LastName;
                    case "Age":
                        return Age.ToString(CultureInfo.InvariantCulture);
                    default:
                        throw new IndexOutOfRangeException("index");
                }
            }
            set // setter - nastavuje hodnoty cez klucove slovo value
            {
                switch (name)
                {
                    case "FirstName":
                        FirstName = value;
                        break;
                    case "LastName":
                        LastName = value;
                        break;
                    case "Age":
                        throw new InvalidOperationException("Age cannot be changed.");
                    default:
                        throw new IndexOutOfRangeException("index");
                }
            }
        }
    }
}
