﻿namespace PersonCreator
{
    /// <summary>
    /// Pohlavie.
    /// </summary>
    public enum Gender
    {
        /// <summary>
        /// Nezname.
        /// </summary>
        Unknown,

        /// <summary>
        /// Muz.
        /// </summary>
        Male,

        /// <summary>
        /// Zena.
        /// </summary>
        Female,
    }
}
