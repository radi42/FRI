﻿using System;

namespace PersonCreator
{
    /// <summary>
    /// Struktura jednoduchej osoby.
    /// </summary>
    public struct SimplePersonStruct
    {
        /// <summary>
        /// Meno.
        /// </summary>
        public string FirstName { get; set; }

        /// <summary>
        /// Priezvisko.
        /// </summary>
        public string LastName { get; set; }

        /// <summary>
        /// Datum narodenia.
        /// </summary>
        public DateTime Birthday { get; set; }

        /// <summary>
        /// Vek.
        /// </summary>
        public int Age => (int)((DateTime.Now - Birthday).TotalDays / 365);

        /// <summary>
        /// Pohlavie.
        /// </summary>
        public Gender Gender { get; set; }

        public SimplePersonStruct(string firstName, string lastName, DateTime birthday, Gender gender)
        {
            FirstName = firstName;
            LastName = lastName;
            Birthday = birthday;
            Gender = gender;
        }

        public override string ToString()
        {
            return $"{FirstName} {LastName} ({Age}), {Gender}";
        }
    }
}
