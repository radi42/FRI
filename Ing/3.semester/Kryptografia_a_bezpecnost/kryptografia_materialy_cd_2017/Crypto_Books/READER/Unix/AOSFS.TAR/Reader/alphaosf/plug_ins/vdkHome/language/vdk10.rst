$control: 1
descriptor:
{
  data-table:	rsf
    /offset      = 0
    /num-records = 431
    /priority    = MEDIUM
  {
    varwidth:	E0 rsv
      /offset = 0
      /max-file-size = 0xFFF0
    fixwidth:	E0_SZ 2 signed-integer
    fixwidth:	E0_OF 2 unsigned-integer
  }
  data-table:	rsf
    /offset      = 1724
    /num-records = 164
    /priority    = MEDIUM
  {
    varwidth:	E1 rsv
      /offset = 14981
      /max-file-size = 0xFFF0
    fixwidth:	E1_SZ 2 signed-integer
    fixwidth:	E1_OF 2 unsigned-integer
  }
  data-table:	rsf
    /offset      = 2380
    /num-records = 206
    /priority    = MEDIUM
  {
    varwidth:	E2 rsv
      /offset = 19816
      /max-file-size = 0xFFF0
    fixwidth:	E2_SZ 2 signed-integer
    fixwidth:	E2_OF 2 unsigned-integer
  }
  data-table:	rsf
    /offset      = 3204
    /num-records = 213
    /priority    = MEDIUM
  {
    varwidth:	E3 rsv
      /offset = 27401
      /max-file-size = 0xFFF0
    fixwidth:	E3_SZ 2 signed-integer
    fixwidth:	E3_OF 2 unsigned-integer
  }
  data-table:	rsf
    /offset      = 4056
    /num-records = 112
    /priority    = MEDIUM
  {
    varwidth:	E4 rsv
      /offset = 34574
      /max-file-size = 0xFFF0
    fixwidth:	E4_SZ 2 signed-integer
    fixwidth:	E4_OF 2 unsigned-integer
  }
  data-table:	rsf
    /offset      = 4504
    /num-records = 159
    /priority    = MEDIUM
  {
    varwidth:	E5 rsv
      /offset = 37328
      /max-file-size = 0xFFF0
    fixwidth:	E5_SZ 2 signed-integer
    fixwidth:	E5_OF 2 unsigned-integer
  }
  data-table:	rsf
    /offset      = 5140
    /num-records = 245
    /priority    = MEDIUM
  {
    varwidth:	M0 rsv
      /offset = 42753
      /max-file-size = 0xFFF0
    fixwidth:	M0_SZ 2 signed-integer
    fixwidth:	M0_OF 2 unsigned-integer
  }
  data-table:	rsf
    /offset      = 6120
    /num-records = 59
    /priority    = MEDIUM
  {
    varwidth:	M1 rsv
      /offset = 46482
      /max-file-size = 0xFFF0
    fixwidth:	M1_SZ 2 signed-integer
    fixwidth:	M1_OF 2 unsigned-integer
  }
  data-table:	rsf
    /offset      = 6356
    /num-records = 145
    /priority    = MEDIUM
  {
    varwidth:	M2 rsv
      /offset = 46744
      /max-file-size = 0xFFF0
    fixwidth:	M2_SZ 2 signed-integer
    fixwidth:	M2_OF 2 unsigned-integer
  }
}
$$
