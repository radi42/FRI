$control: 1
descriptor:
{
  data-table:	rsf
    /offset      = 0
    /num-records = 557
    /priority    = MEDIUM
  {
    varwidth:	E0 rsv
      /offset = 0
      /max-file-size = 0xFFF0
    fixwidth:	E0_SZ 2 signed-integer
    fixwidth:	E0_OF 2 unsigned-integer
  }
  data-table:	rsf
    /offset      = 2228
    /num-records = 167
    /priority    = MEDIUM
  {
    varwidth:	E1 rsv
      /offset = 19285
      /max-file-size = 0xFFF0
    fixwidth:	E1_SZ 2 signed-integer
    fixwidth:	E1_OF 2 unsigned-integer
  }
  data-table:	rsf
    /offset      = 2896
    /num-records = 232
    /priority    = MEDIUM
  {
    varwidth:	E2 rsv
      /offset = 24409
      /max-file-size = 0xFFF0
    fixwidth:	E2_SZ 2 signed-integer
    fixwidth:	E2_OF 2 unsigned-integer
  }
  data-table:	rsf
    /offset      = 3824
    /num-records = 175
    /priority    = MEDIUM
  {
    varwidth:	E3 rsv
      /offset = 33167
      /max-file-size = 0xFFF0
    fixwidth:	E3_SZ 2 signed-integer
    fixwidth:	E3_OF 2 unsigned-integer
  }
  data-table:	rsf
    /offset      = 4524
    /num-records = 261
    /priority    = MEDIUM
  {
    varwidth:	M0 rsv
      /offset = 39180
      /max-file-size = 0xFFF0
    fixwidth:	M0_SZ 2 signed-integer
    fixwidth:	M0_OF 2 unsigned-integer
  }
  data-table:	rsf
    /offset      = 5568
    /num-records = 64
    /priority    = MEDIUM
  {
    varwidth:	M1 rsv
      /offset = 43782
      /max-file-size = 0xFFF0
    fixwidth:	M1_SZ 2 signed-integer
    fixwidth:	M1_OF 2 unsigned-integer
  }
  data-table:	rsf
    /offset      = 5824
    /num-records = 182
    /priority    = MEDIUM
  {
    varwidth:	M2 rsv
      /offset = 44257
      /max-file-size = 0xFFF0
    fixwidth:	M2_SZ 2 signed-integer
    fixwidth:	M2_OF 2 unsigned-integer
  }
}
$$
