plati iba harok s nazvom "Seriovo-Paralelna schema-final"
zvysne dva boli iba testovacie
zlte bunky reprezentuju vrchnu vetvu, oranzovo-hnede spodnu vetvu paralelneho zapojenia systemu