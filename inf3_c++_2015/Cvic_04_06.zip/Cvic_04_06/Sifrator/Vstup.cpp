#include <cstdio>
#include <cstring>
#include "Vstup.h"


Vstup::Vstup(const char *menoSuboru)
{
	aMenoSuboru = NULL;
	if (menoSuboru && *menoSuboru)
	{
		int dlzka = strlen(menoSuboru);
		aMenoSuboru = new char[dlzka + 1];
		strcpy(aMenoSuboru, menoSuboru);
	}
}

Vstup::~Vstup()
{
	delete[] aMenoSuboru;
}

unsigned char * Vstup::citaj()
{
	if (aMenoSuboru)
	{
		int dlzka = dajDlzkaSuboru();
		if (dlzka > 0)
		{
			unsigned char *text = new unsigned char[dlzka + 1];
			if (text)
			{
				FILE *f = fopen(aMenoSuboru, "rb");
				if (f)
				{
					fread(text, dlzka, 1, f);
					text[dlzka] = '\0';
					fclose(f);
					return text;
				}
			}
		}
	}
	return nullptr;
}

unsigned Vstup::dajDlzkaSuboru()
{
	unsigned int dlzka(0);
	if (aMenoSuboru)
	{
		FILE *f = fopen(aMenoSuboru, "rb");
		if (f)
		{
			fseek(f, 0, SEEK_END);
			dlzka = ftell(f);
			fclose(f);
		}
	}
	return dlzka;
}

