#pragma once
#include "Koder.h"
#include "Test.h"
#include "Vstup.h"

class Test
{
public:
	// Testy kodera
	bool run()
	{
		Koder k;
		Vstup v("Test.h");
		unsigned char *srctext = v.citaj();
		unsigned char *zasifrtext = k.koduj((unsigned char *)"vt", srctext);
		
		delete[] zasifrtext;
		delete[] srctext;
		return true;
	}
};

