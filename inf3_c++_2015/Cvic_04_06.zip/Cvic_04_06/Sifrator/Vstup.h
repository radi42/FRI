#pragma once
class Vstup
{
private:
	char *aMenoSuboru;
	unsigned dajDlzkaSuboru();
public:
	Vstup(const char *menoSuboru);
	~Vstup();

	unsigned char *citaj();
};

