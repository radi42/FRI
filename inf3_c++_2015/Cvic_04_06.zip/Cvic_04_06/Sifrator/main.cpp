#define STARTTESTY
#include <iostream>
using namespace std;

#ifdef STARTTESTY
#include "Test.h"
#endif

int main(int argc, char *argv[])
{
	bool ok{ true };

#ifdef STARTTESTY
	Test testy;
	ok = testy.run();
#endif
	if (ok)
		;
	else
	{
		cout << "CHYBA! NEPRESLI TESTY!" << endl;
		return 1;
	}
	return 0;
}