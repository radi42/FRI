#include <cstdlib>
#include <cstring>
#include <cstdio>
#include "Koder.h"
#include "Heslo.h"


void Koder::zakodujTabulku(const unsigned char * heslo)
{
	unsigned int nasada = dajNasadu(heslo);
	srand(nasada);
	for (int i = 0;i < DLZKA_TABULKY;i++)
	{
		int index = rand() % (DLZKA_TABULKY - i);
		vymen(aKodTabulka[index], aKodTabulka[DLZKA_TABULKY - i - 1]);
	}
}

unsigned int Koder::dajNasadu(const unsigned char * heslo)
{
	//Heslo h(heslo);
	//return h.dajNasadu();
	return Heslo(heslo).dajNasadu();
}

void Koder::vymen(unsigned char * a, unsigned char * b)
{
	if (a != NULL && b != NULL)
	{
		unsigned char c(*a);
		*a = *b;
		*b = c;
	}
}

void Koder::vymen(unsigned char & a, unsigned char & b)
{
	unsigned char c(a);
	a = b;
	b = c;
}

Koder::Koder()
{
	for (int i = 0; i < DLZKA_TABULKY; i++)
		aKodTabulka[i] = i;
}


Koder::~Koder()
{
}

unsigned char * Koder::koduj(const unsigned char * heslo, const unsigned char * text)
{
	unsigned char *rettext = NULL;
	if (heslo && text && *text)
	{
		zakodujTabulku(heslo);
		int dlzka = strlen((char *)text);
		unsigned char *zakodovanyText = new unsigned char[dlzka];
		if (zakodovanyText)
		{
			for (int i = 0;i < dlzka;i++)
				zakodovanyText[i] = aKodTabulka[text[i]];
			unsigned char *zasifrovanyText = new unsigned char[3 * dlzka + 1];
			if (zasifrovanyText)
			{
				unsigned char *px = zasifrovanyText;
				for (int i = 0; i < dlzka; i++)
				{
					char pombuf[4];
					sprintf(pombuf, "%03u", zakodovanyText[i]);
					memmove(px, pombuf, 3);
					px += 3;
				}
				*px = '\0';
				rettext = zasifrovanyText;
			}
			delete[] zakodovanyText;
		}
	}
	return rettext;
}
