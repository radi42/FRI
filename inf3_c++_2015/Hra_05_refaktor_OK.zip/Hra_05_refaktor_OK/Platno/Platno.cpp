#include "Platno.h"
#include "SDL.h"

Platno::Platno(SDL_Surface * surface) :
	aSurface(surface),
	aObrazok(true)
{
}

Platno::Platno(int sirka, int vyska) :
	aObrazok(false)
{
	// incializacia
	SDL_Init(SDL_INIT_EVERYTHING);
	aSurface = SDL_SetVideoMode(sirka, vyska, 32, SDL_SWSURFACE);
	if (aSurface == NULL)
	{
		fprintf(stderr, "Problem: %s\n", SDL_GetError());
		return;
	}
}

Platno::~Platno()
{
	// upratanie
	if (aSurface)
		SDL_FreeSurface(aSurface);
	if (!aObrazok)
		SDL_Quit();
}

IPlatno * Platno::citajBMP(const char * cestaObrazok)
{
	SDL_Surface *obrazok = SDL_LoadBMP(cestaObrazok);
	if (obrazok)
		return new Platno(obrazok);
	return NULL;
}

void Platno::kresli(IPlatno * obrazok, int x, int y, int w, int h)
{
	SDL_Rect rectObrazok = { 0, 0, w, h };
	SDL_Rect rectCiel = { x, y, 0, 0 };
	SDL_Surface *obrazok_surf = (SDL_Surface *)obrazok->dajPlochu();
	SDL_BlitSurface(obrazok_surf, &rectObrazok, aSurface, &rectCiel);

}

void Platno::kresli(int x, int y, int w, int h)
{
	int farbaIhriska = SDL_MapRGB(aSurface->format, 0, 127, 0);
	SDL_Rect rect;
	rect.x = x;
	rect.y = y;
	rect.w = w;
	rect.h = h;
	SDL_FillRect(aSurface, &rect, farbaIhriska);
}

void * Platno::dajPlochu()
{
	return aSurface;
}

int Platno::cas()
{
	return SDL_GetTicks();
}

bool Platno::vstup(int & x, int & y)
{
	x = -1;
	SDL_Event event;
	while (SDL_PollEvent(&event))
	{
		switch (event.type)
		{
		case SDL_KEYDOWN:
			if (event.key.keysym.sym == SDLK_ESCAPE)
				return false;
		case SDL_MOUSEBUTTONDOWN:
			if (event.button.button == SDL_BUTTON_LEFT)
			{
				x = event.button.x;
				y = event.button.y;
			}
			break;
		case SDL_QUIT:
			return false;
		}
	}
	return true;
}

void Platno::vymaz()
{
	int farbaScreen = SDL_MapRGB(aSurface->format, 0, 0, 127);
	SDL_FillRect(aSurface, NULL, farbaScreen);
}

void Platno::update()
{
	SDL_UpdateRect(aSurface, 0, 0, 0, 0);
}

void Platno::zobrazBody(const char * info)
{
	SDL_WM_SetCaption(info, NULL);
}
