#pragma once
#include "IPlatno.h"

//#include "SDL.h"
//SDL.h tu nemoze byt include, lebo toto h-acko sa includuje do projektu Hra a tam nie je SDL zname.
// include je presunute do cpp suboru a tu sa 
//miesto toho pre potrebu SDL_Surface spravi jeho forward

struct SDL_Surface;

class Platno : public IPlatno
{
private:
	SDL_Surface *aSurface;
	bool aObrazok; // pre zistenie, ci je to platno pre obrazok (pre destruktor)

public:
	Platno(SDL_Surface *surface);
	Platno(int sirka, int vyska);
	~Platno();

	// Inherited via IPlatno
	virtual IPlatno * citajBMP(const char * cestaObrazok) override;
	//kresli 4-uholnik vyplneny obrazkom
	virtual void kresli(IPlatno * obrazok, int x, int y, int w, int h) override;
	//kresli 4-uholnik vyplneny farbou
	virtual void kresli(int x, int y, int w, int h) override;

	virtual void * dajPlochu() override;
	virtual int cas() override;

	virtual bool vstup(int & x, int & y) override;
	virtual void vymaz() override;
	virtual void update() override;

	// Inherited via IPlatno
	virtual void zobrazBody(const char * info) override;
};

