#pragma once
class IPlatno
{
public:

	IPlatno()
	{
	}

	virtual ~IPlatno()
	{
	}

	virtual IPlatno *citajBMP(const char *cestaObrazok) = 0;
	virtual void kresli(IPlatno *obrazok, int x, int y, int w, int h) = 0;
	virtual void kresli(int x, int y, int w, int h) = 0;
	virtual void *dajPlochu() = 0;
	virtual int cas() = 0;
	
	virtual bool vstup(int &x, int &y) = 0;
	virtual void vymaz() = 0;
	virtual void update() = 0;
	virtual void zobrazBody(const char *info) = 0;
};

