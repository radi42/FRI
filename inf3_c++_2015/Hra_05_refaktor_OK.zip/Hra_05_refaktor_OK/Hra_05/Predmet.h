#pragma once
#include "Vykreslovac.h"
#include <IPlatno.h>

class Predmet :	public Vykreslovac
{
private:
	int aDeltaX, aDeltaY;
	IPlatno *aPlatno;
	IPlatno *aObrazok;

public:
	Predmet(IPlatno *platno, int xplocha, int yplocha, int wplocha, int hplocha,
		int w, int h, const char *cestaObrazok);
	~Predmet();

	// Inherited via Vykreslovac
	virtual void vykresliSa() override;
	virtual bool zasah(int x, int y) override;

	void pohniSa(int xplocha, int yplocha, int wplocha, int hplocha);
	static int generujNahodneCislo(int minValue, int maxValue);
};

