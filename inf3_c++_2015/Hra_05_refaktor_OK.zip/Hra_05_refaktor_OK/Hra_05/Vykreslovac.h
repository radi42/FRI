#pragma once

class Vykreslovac
{
protected:
	int aX, aY, aW, aH;

public:
	Vykreslovac(int x, int y, int w, int h);
	virtual ~Vykreslovac();

	virtual void vykresliSa() = 0;
	virtual bool zasah(int x, int y) = 0;
	virtual void pohniSa(int xplocha=0, int yplocha=0, int wplocha=0, int hplocha=0) = 0;
};

