#include <cstdlib>
#include <ctime>
#include "Predmet.h"

const int MAXDELTA = 10;

Predmet::Predmet(IPlatno *platno, int xplocha, int yplocha, int wplocha, int hplocha,
	int w, int h, const char * cestaObrazok) :
	Vykreslovac(0, 0, w, h),
	aPlatno(platno)
{
	srand(unsigned(time(NULL)));
	//aObrazok = SDL_LoadBMP(cestaObrazok);
	if (aPlatno)
		aObrazok = aPlatno->citajBMP(cestaObrazok);
	if (aObrazok)
	{
		aX = generujNahodneCislo(xplocha, xplocha + wplocha - aW);
		aY = generujNahodneCislo(yplocha, yplocha + hplocha - aH);
		aDeltaX = generujNahodneCislo(1, MAXDELTA) - MAXDELTA / 2;
		aDeltaY = generujNahodneCislo(1, MAXDELTA) - MAXDELTA / 2;
	}
}

Predmet::~Predmet()
{
	delete aObrazok;
}

void Predmet::vykresliSa()
{
	if (aPlatno)
		aPlatno->kresli(aObrazok, aX, aY, aW, aH);
}

bool Predmet::zasah(int x, int y)
{
	return aX <= x && x <= aX + aW && aY <= y && y <= aY + aH;
}

void Predmet::pohniSa(int xplocha, int yplocha, int wplocha, int hplocha)
{
	aX += aDeltaX;
	aY += aDeltaY;
	if (aX <= xplocha || aX >= xplocha + wplocha - aW)
	{
		aDeltaX = -aDeltaX;
		aX += aDeltaX;
	}
	if (aY <= yplocha || aY >= yplocha + hplocha - aH)
	{
		aDeltaY = -aDeltaY;
		aY += aDeltaY;
	}
}

int Predmet::generujNahodneCislo(int minValue, int maxValue)
{
	return rand() % (maxValue - minValue) + minValue;
}
