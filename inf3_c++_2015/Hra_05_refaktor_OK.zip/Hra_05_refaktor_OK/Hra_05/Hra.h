#pragma once
#include "Vykreslovac.h"
#include <IPlatno.h>

class Hra
{
private:
	IPlatno *aScreen;
	Vykreslovac *aIhrisko;
	int aBody;

	void run();
	void zobrazBody();

	void spracujVstup(int x, int y);
	int aktualizujOkno(int t1);

public:
	Hra(void);
	~Hra();
	int cas();
	void start();
	bool vstup(int &x, int &y);
};

