#include <cstdlib>
#include "Ihrisko.h"

Ihrisko::Ihrisko(IPlatno *platno, int x, int y, int w, int h) :
	Vykreslovac(x, y, w, h),
	aPlatno(platno),
	aPredmet(aPlatno ? new Predmet(aPlatno, aX, aY, aW, aH, 65, 65, "ball.bmp") : NULL)
{
}

Ihrisko::~Ihrisko()
{
	if (aPredmet)
		delete aPredmet;
}

void Ihrisko::vykresliSa()
{
	if (aPlatno)
		aPlatno->kresli(aX, aY, aW, aH);
	aPredmet->vykresliSa();

}

bool Ihrisko::zasah(int x, int y)
{
	if (aPredmet->zasah(x, y))
	{
		delete aPredmet;
		aPredmet = new Predmet(aPlatno, aX, aY, aW, aH, 65, 65, "ball.bmp");
		if (aPredmet)
			return true;
	}
	return false;
}

void Ihrisko::pohniSa(int xplocha, int yplocha, int wplocha, int hplocha)
{
	aPredmet->pohniSa(aX, aY, aW, aH);
}
