#pragma once
#include "Vykreslovac.h"
#include "Predmet.h"
#include <IPlatno.h>

class Ihrisko : public Vykreslovac
{
private:
	IPlatno *aPlatno;
	Predmet *aPredmet;

public:
	Ihrisko(IPlatno *platno, int x, int y, int w, int h);
	~Ihrisko();


	// Inherited via Vykreslovac
	virtual void vykresliSa() override;
	virtual bool zasah(int x, int y) override;

	virtual void pohniSa(int xplocha=0, int yplocha=0, int wplocha=0, int hplocha=0) override;

};

