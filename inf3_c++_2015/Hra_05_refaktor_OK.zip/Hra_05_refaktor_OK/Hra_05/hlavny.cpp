#include "Hra.h"

int main(int argc, char* argv[])
{
	Hra hra;
	hra.start();
	return 0;
}