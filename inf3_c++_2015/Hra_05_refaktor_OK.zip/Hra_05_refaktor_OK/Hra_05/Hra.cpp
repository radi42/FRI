#include <sstream>
#include "Hra.h"
#include "Ihrisko.h"
#include "Platno.h"

const int INTERVAL = 10;

Hra::Hra() :
	aScreen(new Platno(800, 600)),
	aIhrisko(aScreen ? new Ihrisko(aScreen, 10, 10, 700, 500) : NULL),
	aBody(0)
{
}

Hra::~Hra()
{
	delete aIhrisko;
	delete aScreen;
}

void Hra::start()
{
	// beh hry
	if (aScreen)
		run();
}

void Hra::run()
{
	int t1 = cas();
	int x(-1), y(-1);
	zobrazBody();
	while (vstup(x, y))
	{
		spracujVstup(x, y);
		t1 = aktualizujOkno(t1);
	}
}

void Hra::zobrazBody()
{
	std::ostringstream buffer;
	buffer << "Pocet bodov: " << aBody;
	if (aScreen)
		aScreen->zobrazBody(buffer.str().c_str());
}

int Hra::cas()
{
	return aScreen ? aScreen->cas() : 0;
}

bool Hra::vstup(int & x, int & y)
{
	return aScreen ? aScreen->vstup(x, y) : false;
}

void Hra::spracujVstup(int x, int y)
{
	if (x != -1)
	{
		if (aIhrisko->zasah(x, y))
			aBody++;
		else
			aBody--;
		zobrazBody();
	}
}

int Hra::aktualizujOkno(int t1)
{
	int t2 = cas();
	if (t2 - t1 > INTERVAL)
	{
		aIhrisko->pohniSa();
		t1 = t2;
	}
	aScreen->vymaz();
	aIhrisko->vykresliSa();
	aScreen->update();
	return t1;
}
