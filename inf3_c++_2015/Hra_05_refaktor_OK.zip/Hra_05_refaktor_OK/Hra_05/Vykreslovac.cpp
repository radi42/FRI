#include "Vykreslovac.h"

Vykreslovac::Vykreslovac(int x, int y, int w, int h):
	aX(x), aY(y), aW(w), aH(h)
{
}

Vykreslovac::~Vykreslovac()
{
}
