#pragma once
#include "data.h"

MUINT vypis(MUINT pocetzrebov);