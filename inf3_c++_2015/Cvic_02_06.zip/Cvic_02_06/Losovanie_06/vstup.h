#pragma once

void initZreby();