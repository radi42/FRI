#include <stdlib.h>
#include <time.h>
#include <string.h>

#include "losovanie.h"

void vymen(int a, int b);
void vymen1(int a, int b);

void losuj(MUINT pocetzrebov)
{
	srand((unsigned)time(0));
	for (MUINT i = 0;i < pocetzrebov && i < POCET_ZREBOV;i++)
	{
		MUINT index = rand() % (POCET_ZREBOV - i) + i;
		vymen1(index, i);
	}
}

void vymen(int a, int b)
{
	struct Zreb c;
	c.cislo = zreby[a].cislo;
	strcpy(c.majitel, zreby[a].majitel);

	zreby[a].cislo = zreby[b].cislo;
	strcpy(zreby[a].majitel, zreby[b].majitel);

	zreby[b].cislo = c.cislo;
	strcpy(zreby[b].majitel, c.majitel);
}

void vymen1(int a, int b)
{
	struct Zreb c;
	memmove(&c, &zreby[a], sizeof(c));
	memmove(&zreby[a], &zreby[b], sizeof(c));
	memmove(&zreby[b], &c, sizeof(c));
}