#include "data.h"

struct Zreb zreby[POCET_ZREBOV];