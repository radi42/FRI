#pragma once
#include "data.h"

void tah(MUINT pocetzrebov);