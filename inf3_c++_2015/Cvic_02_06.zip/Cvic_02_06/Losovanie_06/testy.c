#include <stdio.h>
#include "testy.h"
#include "data.h"
#include "vstup.h"
#include "vystup.h"

int testuj()
{
	int vysledok = 1;
	initZreby();
	for (int j = 0;j < 10;j++)
	{
		for (MUINT i = 0;i < POCET_ZREBOV;i++)
		{
			MUINT index = j % (POCET_ZREBOV - i) + i;
			printf("j: %d - index: %d\n", j, index);
		}
	}
	for (MUINT i = 0; i < POCET_ZREBOV; i++)
	{
		if (zreby[i].cislo != (i + 1))
		{
			vysledok = 0;
			break;
		}
		if (zreby[i].majitel[0] != ('A' + i))
		{
			vysledok = 0;
			break;
		}
	}
	vypis(POCET_ZREBOV);
	return vysledok;
}
