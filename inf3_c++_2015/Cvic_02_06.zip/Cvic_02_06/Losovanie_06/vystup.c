#include <stdio.h>
#include "vystup.h"

MUINT vypis(MUINT pocetzrebov)
{
	MUINT citac = 0;

	printf("\nVYSLEDOK LOSOVANIA\n----------------------------------\n");
	for (MUINT i = 0;i < pocetzrebov && i < POCET_ZREBOV;i++)
	{
		printf("%3u.miesto:\t%3u %s\n",
			i + 1,
			zreby[i].cislo,
			zreby[i].majitel);
		citac++;
	}
	return citac;
}