#include <string.h>
#include "vstup.h"
#include "data.h"

void initZreby()
{
	for (int i = 0;i < POCET_ZREBOV;i++)
	{
		zreby[i].cislo = i + 1;
		zreby[i].majitel[0] = 'A' + i;
		zreby[i].majitel[1] = 0;
	}
	//int i = 0;
	//zreby[i].cislo = i + 1;
	//strcpy(zreby[i++].majitel, "A");
	//zreby[i].cislo = i + 1;
	//strcpy(zreby[i++].majitel, "B");
	//zreby[i].cislo = i + 1;
	//strcpy(zreby[i++].majitel, "C");

	//zreby[0].cislo = 1;
	//strcpy(zreby[0].majitel,"A");
	//zreby[1].cislo = 2;
	//strcpy(zreby[1].majitel, "B");
	//zreby[2].cislo = 3;
	//strcpy(zreby[2].majitel, "C");
}