#pragma once
#include "data.h"

void losuj(MUINT pocetzrebov);