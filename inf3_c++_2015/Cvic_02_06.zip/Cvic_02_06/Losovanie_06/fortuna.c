#include "fortuna.h"
#include "vstup.h"
#include "vystup.h"
#include "losovanie.h"

void tah(MUINT pocetzrebov)
{
	initZreby();
	losuj(pocetzrebov);
	vypis(pocetzrebov);
}