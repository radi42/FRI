//#define START_TESTY

#include <stdio.h>
#include <stdlib.h>

#include "fortuna.h"

#ifdef START_TESTY
	#include "testy.h"
#endif

int main(int argc, char *argv[])
{
	int ok = 1;
#ifdef START_TESTY
	ok = testuj();
#endif
	if (ok == 1)
	{
		MUINT pocetlosov = POCET_ZREBOV;
		if (argc > 1)
			pocetlosov = atoi(argv[1]);
		tah(pocetlosov); // Normalny start programu
	}
	else
		printf("CHYBA!!! NEPRESLI TESTY!!!\n");
	return 0;
}