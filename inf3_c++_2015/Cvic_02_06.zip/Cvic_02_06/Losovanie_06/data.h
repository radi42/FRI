#pragma once

#define POCET_ZREBOV 10
#define DLZKA_MENA  11

#ifdef WIN32
	typedef unsigned int MUINT;
#else
	typedef unsigned short MUINT;
#endif

struct Zreb
{
	MUINT cislo;
	char majitel[DLZKA_MENA];
};

extern struct Zreb zreby[POCET_ZREBOV];
